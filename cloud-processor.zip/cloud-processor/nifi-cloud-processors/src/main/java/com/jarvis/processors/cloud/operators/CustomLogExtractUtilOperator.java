package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.LogAnalyticUtilInfo;
import com.jarvis.processors.cloud.data.IData;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import org.apache.commons.math3.util.Precision;

// Operator to parse logs and extract tenant job information from the logs
public class CustomLogExtractUtilOperator extends CustomOperator {

    LogAnalyticUtilInfo m_waterMarkEntry;

    public CustomLogExtractUtilOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntry = new LogAnalyticUtilInfo();
        m_waterMarkEntry.setWatermarkMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                map(v -> {
                    String[] extractedTokens = v.toString().split(":=");
                    String srcCluster = extractedTokens[2];
                    String device = extractedTokens[3].split(" ")[0];
                    int util = Integer.parseInt(
                            extractedTokens[4].trim().replace("%=>1",""));
                    return new LogAnalyticUtilInfo(srcCluster.trim(), device,
                            Precision.round((float) util, -1), 1);
                }).
                subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        m_waterMarkEntry.resetQueueTime();
                        m_waterMarkEntry.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                        m_recentEpochEndTime = System.currentTimeMillis();
                        m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                        m_nextQueue.putWaterMark(m_waterMarkEntry);

                        JarvisLogger.info("[CustomLogExtractUtilOperator.onComplete] LP Solver op id: " + m_opId
                                + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            data.resetQueueTime();
                            m_numOutRecords[0]++;
                            m_nextQueue.put(data);
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}


//package com.jarvis.processors.cloud.old;
//
//import com.jarvis.processors.cloud.JarvisLogger;
//import com.jarvis.processors.cloud.controlproxy.IControlProxy;
//import io.reactivex.Observer;
//import io.reactivex.disposables.Disposable;
//
//public class CustomMapOperator extends CustomOperator {
//
//    PingMeshKryoWithTime m_waterMarkEntryWithTime;
//    PingMeshKryoWithTime m_subEpochMarkerWithTime;
//    double m_reductionRatio;
//
//    public void setNextQueue(IControlProxy queue) {
//        // No-op since final operator
//        m_nextQueue = queue;
//    }
//
//    public void setDataflow() {
//        Long[] processStart = {0L};
//        Long startDataflowBuild = System.currentTimeMillis();
//        m_subject = io.reactivex.subjects.PublishSubject.create();
//        m_subject.
////                doOnNext(v -> {
////                    processStart[0] = System.currentTimeMillis();
////                }).
//        map(v -> {
////                    Thread.sleep(0, 500000000);
//    Thread.sleep(1);
//    return v;
//}).
////                doOnNext(v -> {
////                    m_totalProcessingTime += (System.currentTimeMillis() - processStart[0]);
////                }).
//        subscribe(
//        new Observer<IData>() {
//            @Override
//            public void onSubscribe(Disposable d) {}
//
//            @Override
//            public void onComplete() {
//                if(!m_subEpochComplete.get()) {
//                    m_waterMarkEntryWithTime.resetQueueTime();
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] created watermark: " +
//                            m_waterMarkSeqNum.get());
//                    m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
//                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
//                } else {
//                    m_nextQueue.put(m_subEpochMarkerWithTime);
//                    m_subEpochComplete.set(false);
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] subepoch marker set");
//                }
//            }
//
//            @Override
//            public void onError(Throwable throwable) {
//            }
//
//            @Override
//            public void onNext(IData data) {
//                try {
//                    data.resetQueueTime();
//                    m_nextQueue.put(data);
//                    m_numOutRecords[0]++;
//                } catch (Exception e) {
//                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
//                }
//            }
//
//        }
//);
//
//        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
//    }
//}
//

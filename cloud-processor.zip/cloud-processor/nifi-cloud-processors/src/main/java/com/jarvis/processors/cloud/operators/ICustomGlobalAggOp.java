package com.jarvis.processors.cloud.operators;


import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

// Interface for global aggregation operator at the end of processing all query instances
public interface ICustomGlobalAggOp {
    // Sets the next queue for downstream operator processing
    void setNextQueue(IControlProxy queue);

    // Processes input data item, one at a time
    void onNext(IData data);

    // Invoked when epoch completes, to aggregate all data in the epoch
    void onComplete();
}

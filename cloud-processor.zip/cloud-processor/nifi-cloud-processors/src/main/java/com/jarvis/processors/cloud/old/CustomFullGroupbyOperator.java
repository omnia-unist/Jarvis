//package com.jarvis.processors.cloud.old;
//
//import com.jarvis.processors.cloud.JarvisLogger;
//import io.reactivex.Observer;
//import io.reactivex.disposables.Disposable;
//
//public class CustomFullGroupbyOperator extends CustomOperator {
//    SrcClusterStatsKryo m_waterMarkEntryWithTime;
//    SrcClusterStatsKryo m_subEpochMarkerWithTime;
//
//    public CustomFullGroupbyOperator(int opId, ControllerQueue currentQueue) {
//        super(opId, currentQueue, 1);
//        m_waterMarkEntryWithTime = new SrcClusterStatsKryo();
//        m_waterMarkEntryWithTime.setSrcCluster(Integer.MIN_VALUE);
//
//        m_subEpochMarkerWithTime = new SrcClusterStatsKryo();
//        m_subEpochMarkerWithTime.setSrcCluster(Integer.MAX_VALUE);
//    }
//
//    public CustomFullGroupbyOperator(int opId, ControllerQueueWithoutAdapt currentQueue) {
//        super(opId, currentQueue, 1);
//        m_waterMarkEntryWithTime = new SrcClusterStatsKryo();
//        m_waterMarkEntryWithTime.setSrcCluster(Integer.MIN_VALUE);
//
//        m_subEpochMarkerWithTime = new SrcClusterStatsKryo();
//        m_subEpochMarkerWithTime.setSrcCluster(Integer.MAX_VALUE);
//    }
//
//    public void setDataflow() {
//
//        JarvisLogger.debug("[Kotlin debug] " + Thread.currentThread().getName());
//
//        Long[] processStart = {0L};
//        Long startDataflowBuild = System.currentTimeMillis();
//        m_subject = io.reactivex.subjects.PublishSubject.create();
//        m_subject.
////                doOnNext(v -> {
////                    processStart[0] = System.currentTimeMillis();
//////                    System.out.println("Getting a record: " + v.getKey());
////                }).
//        groupBy(v -> v.getKey()).
//                flatMapSingle(grps -> {
//                    return grps.toList().map(grpList -> {
//                        int max = 0, min = Integer.MAX_VALUE, count=0;
//                        float avg = 0;
//                        for (IData data :
//                                grpList) {
//                            int value = data.getValue();
//                            if(value > max) {
//                                max = value;
//                            }
//
//                            if(value < min) {
//                                min = value;
//                            }
//
//                            avg += value;
//                            count++;
//                        }
//
//                        SrcClusterStatsKryo srcClusterStatsKryo = new SrcClusterStatsKryo();
//                        srcClusterStatsKryo.setSrcCluster((int) grps.getKey());
//                        srcClusterStatsKryo.setAvgRtt(avg/(float)count);
//                        srcClusterStatsKryo.setMinRtt(min);
//                        srcClusterStatsKryo.setMaxRtt(max);
////                        System.out.println("SrcCLusterKryo: " + grps.getKey());
//                        return srcClusterStatsKryo;
//                    });
//                }).
////                doOnNext(v -> {
////                    m_totalProcessingTime += (System.currentTimeMillis() - processStart[0]);
////                }).
//        subscribe(
//        new Observer<IData>() {
//            @Override
//            public void onSubscribe(Disposable d) {}
//
//            @Override
//            public void onComplete() {
//                if(!m_subEpochComplete.get()) {
//                    m_waterMarkEntryWithTime.resetQueueTime();
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] created watermark: " +
//                            m_waterMarkSeqNum.get());
//                    m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
//                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
//                    long epochDuration = System.currentTimeMillis() - m_startEpoch;
//                    JarvisLogger.debug("[CustomFullGroupbyOperator.setDataflow] Thread ID is: " +
//                            Thread.currentThread().getId() + ", epoch duration is: " +
//                            epochDuration);
//                } else {
//                    m_nextQueue.put(m_subEpochMarkerWithTime);
//                    m_subEpochComplete.set(false);
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] subepoch marker set");
//                }
//
//
//            }
//
//            @Override
//            public void onError(Throwable throwable) {
//            }
//
//            @Override
//            public void onNext(IData data) {
//                try {
//                    data.resetQueueTime();
//                    m_nextQueue.put(data);
//                    m_numOutRecords[0]++;
//                } catch (Exception e) {
//                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
//                }
//            }
//
//        }
//);
//
//        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
//    }
//
//    public Integer[] getOutputRecCount() {
//        return m_numOutRecords;
//    }
//
//    public void setNextQueue(IQueue queue) {
//        // No-op since final operator
//        m_nextQueue = queue;
//    }
//}
//

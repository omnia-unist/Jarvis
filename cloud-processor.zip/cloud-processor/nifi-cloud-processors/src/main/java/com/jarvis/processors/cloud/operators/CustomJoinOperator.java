package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.IpTorMapping;
import com.jarvis.processors.cloud.data.JoinResult;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.Random;

// Implements join operator for used in T2TProbe query
public class CustomJoinOperator extends CustomOperator {
    Integer[] m_numOutRecords = {0};
    PingMeshKryoWithTime m_dummyRecord;
    IData[] m_staticRightTable;
    IData m_mismatchMarker;
    IData m_waterMarkWithTime;

    Random random = new Random();

    public  CustomJoinOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        createStaticTable();
        m_mismatchMarker = new JoinResult();
        m_mismatchMarker.setJoinMismatchMarker();

        m_waterMarkWithTime = new JoinResult();
        m_waterMarkWithTime.setWatermarkMarker();
    }

    private void createStaticTable() {
        int joinTableSize = Config.JOIN_TABLE_SIZE;
        m_staticRightTable = new IpTorMapping[joinTableSize];
        for(int i = 0; i < joinTableSize; i++) {
            m_staticRightTable[i] = new IpTorMapping();
            m_staticRightTable[i].setJoinKey(Config.JOIN_KEY_START + i);
            m_staticRightTable[i].setJoinValue(Config.JOIN_KEY_START * 2 + i);
        }
    }

    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        Observable<IData> right = Observable.
                fromArray(m_staticRightTable);
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
        join(right,
        aLong -> Observable.never(),
        aLong -> Observable.never(),
        (l, r) -> {
            if(l.getJoinKey().equals(r.getJoinKey())) {
                return new JoinResult(l.getJoinValue(), r.getJoinValue());
            } else {
                return m_mismatchMarker;
            }
        }).
        subscribe(
            new Observer<IData>() {
                @Override
                public void onSubscribe(Disposable d) {}

                @Override
                public void onComplete() {
                    m_waterMarkWithTime.resetQueueTime();
                    m_waterMarkWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                    m_nextQueue.putWaterMark(m_waterMarkWithTime);
                    m_recentEpochEndTime = System.currentTimeMillis();
                    m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                    JarvisLogger.info("[CustomJoinOperator.setDataflow] Thread ID is: " +
                            Thread.currentThread().getId() + ", epoch duration is " +
                            m_recentEpochDuration);
                    JarvisLogger.debug("OnComplete occurred");
                }

                @Override
                public void onError(Throwable throwable) {
                }

                @Override
                public void onNext(IData data) {
                    try {
                        if(!data.isJoinMismatchMarker()) {
                            JarvisLogger.debug(data.toString());
                            data.resetQueueTime();
                            m_nextQueue.put(data);
                            m_numOutRecords[0]++;
                        }
                    } catch (Exception e) {
                        JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                    }
                }

            }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }
}

package com.jarvis.processors.cloud.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

// Interface to store data items for each of the datasets used in the evaluated queries on stream processor side
public interface IData {
    // Gets the current payload in bytes for network transfer
    int getPayloadInBytes();

    // Gets the queued time for data item
    long getQueueTime();

    // Gets the underlying entity for this data item, e.g. PingMesh item which is wrapped to include queueing metadata
    IData getEntity();

    // Sets the underlying entity for this data item
    void setEntity(IData data);

    // Checks if data item is watermark
    boolean isWaterMark();

    // Writes data item to Kryo object for network transfer
    void writeSelfToKryo(Kryo kryo, Output output);

    // Resets data item queueing time
    void resetQueueTime();

    // Gets data item seq number
    int getSeqNum();

    // Sets dataitem seq number
    void setSeqNum(int seqNum);

    // Gets the grouping key for aggregation, if its an integer
    Integer getGroupingKey();

    // Sets the value for grouping key
    void setGroupingKey(int key);

    // Gets the grouping value for aggregation
    Integer getGroupingValue();

    // Set data item as watermark
    void setWatermarkMarker();

    // Sets data item join key
    void setJoinKey(int key);

    // Gets data item join key
    Integer getJoinKey();

    // Sets join value for data item
    void setJoinValue(int value);

    // Gets join value for data item
    Integer getJoinValue();

    // Indicates if join predicate is satisfied
    boolean isJoinMismatchMarker();

    // Set data item to indicate join predicate not satisfied
    void setJoinMismatchMarker();

    // Gets the value for filter predicate
    Integer getFilterPredVal();

    // Get the key for grouping as a string (e.g. to obtain word count)
    String getWordKey();

    // Gets count of underlying data items represented by this object (useful in aggregation)
    int getCount();

    // Get max aggregation value stored in this data item
    float getMaxValue();

    // Get min aggregation value stored in this data item
    float getMinValue();

    // Convert the string representation of data item in lower case
    void convertToLowerCase();

    // Gets the grouping key for aggregation, if its a string
    String getGroupingKey(boolean all);
}
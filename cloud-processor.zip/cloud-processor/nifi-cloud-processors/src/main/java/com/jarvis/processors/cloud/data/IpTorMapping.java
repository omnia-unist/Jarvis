package com.jarvis.processors.cloud.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.data.IData;

// Stores mapping from IP address to ToR ID for T2TProbe query
public class IpTorMapping implements IData {
    int m_seq_num;

    // server IP address
    int m_ip;

    // ToR ID
    int m_torId;
    int m_count;

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for IpTor mapping class");
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for IpTor mapping class");
    }

    public float getMaxValue() {
        // No op
        throw new UnsupportedOperationException("IpTorMapping doesn't have max value");
    }

    public float getMinValue() {
        // No op
        throw new UnsupportedOperationException("IpTorMapping doesn't have min value");
    }

    public int getCount() {
        return m_count;
    }

    public int getSeqNum() {
        return m_seq_num;
    }

    public void setSeqNum(int seqNum) {
        m_seq_num = seqNum;
    }

    public String toString() {
        return m_seq_num + "," + m_ip + "," + m_torId + "\n";
    }

    public int getPayloadInBytes() {
        return 3 * Config.SIZE_OF_INT;
    }

    public boolean isJoinMismatchMarker() {
        return (m_ip==Integer.MAX_VALUE);
    }

    public void setJoinMismatchMarker() {
        m_ip = Integer.MAX_VALUE;
    }

    public void setJoinValue(int value) {
        m_torId = value;
    }

    public Integer getJoinValue() {
        return m_torId;
    }

    public boolean isWaterMark() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot be watermark");
    }

    public Integer getGroupingKey() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping key");
    }

    public Integer getGroupingValue() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping value");
    }

    public void setWatermarkMarker() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot be watermark");
    }

    public void setGroupingKey(int key) {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping key");
    }


    public Integer getJoinKey() {
        return m_ip;
    }

    public void setJoinKey(int key) {
        m_ip = key;
    }

    public long getQueueTime() { return -1; }
    public void resetQueueTime() {}
    public IData getEntity() { return null; }
    public void setEntity(IData data) {}

    public void writeSelfToKryo(Kryo kryo, Output output) {
        // No-op
    }

    public Integer getFilterPredVal() {
        throw new UnsupportedOperationException("IpTorMappping is not used in filter operator");
    }

    public String getWordKey() {
        throw new UnsupportedOperationException("Not supported for numeric data");
    }
}


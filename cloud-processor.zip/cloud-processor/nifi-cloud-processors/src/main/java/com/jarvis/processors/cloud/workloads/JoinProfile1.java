package com.jarvis.processors.cloud.workloads;

import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.*;
import com.jarvis.processors.cloud.data.*;
import com.jarvis.processors.cloud.operators.CustomJoinOperator;
import com.jarvis.processors.cloud.operators.CustomOperator;

// Implements join operator for profiling
public class JoinProfile1 extends Workload {

    public JoinProfile1() {
        super();
        if(Config.JOIN_TABLE_SIZE == 0) {
            throw new UnsupportedOperationException("Join table size is 0 for Join profiling workload");
        }

        classesToRegister = new IData[1];
        classesToRegister[0] = new JoinResult();

        m_numOperators = 1;

        m_dummyWatermarkMarkerType = "PingMeshKryo";
        setQueuesAndRuntime();

        for(int i = 0; i < Config.QUERY_REPLICATION_FACTOR; i++) {
            m_customOperators[0][i] = new CustomJoinOperator(0, m_firstCp[i]);
            m_customOperators[0][i].setNextQueue(m_finalCp);
        }
    }
}

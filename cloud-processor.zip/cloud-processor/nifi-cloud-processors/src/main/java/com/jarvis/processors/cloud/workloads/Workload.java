package com.jarvis.processors.cloud.workloads;

import com.esotericsoftware.kryo.Kryo;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.*;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.operators.*;

import static com.jarvis.processors.cloud.MyProcessor.MY_RELATIONSHIP;
import static com.jarvis.processors.cloud.MyProcessor.MY_RELATIONSHIP_1;

// Abstract class to implement each of the query workloads
public abstract class Workload {
    // Number of query operators
    int m_numOperators;

    // CustomOperator instance for each operator
    CustomOperator[][] m_customOperators;

    ICustomGlobalAggOp m_aggOperator;

    // Per-operator thread, 2D matrix with each row for a query instance
    Thread[][] m_operatorThreads;

    // List of internal control proxies, 2D matrix with each row for a query instance
    IControlProxy[][] m_internalCps;

    // Dummy watermark type to generate watermarks
    String m_dummyWatermarkMarkerType;

    // Final control proxy to send output to NiFi processor output
    IControlProxy m_finalCp;

    // First control proxy, with each element corresponding to a query instance
    IControlProxy[] m_firstCp;

    // Aggregate control proxy for aggregating results across query instances
    AggregateControlProxy m_aggCp;

    // Data types to register for the workload
    IData[] classesToRegister;

    public Workload() {
        m_aggOperator = null;
        m_aggCp = null;
    }

    // Starts workload after initializing workload object and parameters
    public void beginWorkload() {
        for (int i = 0; i < m_numOperators; i++) {
            for(int j = 0; j < Config.QUERY_REPLICATION_FACTOR; j++) {
                m_operatorThreads[i][j] = new Thread(m_customOperators[i][j]);
                m_operatorThreads[i][j].start();
            }
        }
    }

    // Sets the queues and Jarvis runtime to execute the workload
    // Argument contains the post stateful op flag for final and internal CPs
    protected void setQueuesAndRuntime() {
        m_customOperators = new CustomOperator[m_numOperators][Config.QUERY_REPLICATION_FACTOR];
        m_operatorThreads = new Thread[m_numOperators][Config.QUERY_REPLICATION_FACTOR];
        m_internalCps = new IControlProxy[m_numOperators-1][Config.QUERY_REPLICATION_FACTOR];
        m_firstCp = new FirstControlProxy[Config.QUERY_REPLICATION_FACTOR];
        m_finalCp = new FinalControlProxy(classesToRegister, MY_RELATIONSHIP);
        for(int i = 0; i < Config.QUERY_REPLICATION_FACTOR; i++) {
            for(int j = 0; j < m_internalCps.length; j++) {
                m_internalCps[j][i] = new ControlProxy((j * Config.QUERY_REPLICATION_FACTOR) + i + 1);
            }

            m_firstCp[i] = new FirstControlProxy(m_finalCp);
        }

    }

    // Gets the watermark data type for first control proxy
    public String getFirstCpWatermarkType() {
        return m_dummyWatermarkMarkerType;
    }

    // Gets first control proxies
    public IControlProxy[] getFirstCps() {
        return m_firstCp;
    }

    // Gets the final control proxy
    public IControlProxy getFinalCp() {
        return m_finalCp;
    }

    // Gets the internal control proxies for all query instances
    public IControlProxy[][] getInternalCps() {
        return m_internalCps;
    }

}

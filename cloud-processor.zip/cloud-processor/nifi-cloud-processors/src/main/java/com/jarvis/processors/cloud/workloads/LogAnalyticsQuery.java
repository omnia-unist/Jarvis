package com.jarvis.processors.cloud.workloads;


import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.AggregateControlProxy;
import com.jarvis.processors.cloud.data.*;
import com.jarvis.processors.cloud.operators.*;

// Implements LogAnalytics query
public class LogAnalyticsQuery extends Workload {

    public LogAnalyticsQuery() {
        super();

        classesToRegister = new IData[3];
        classesToRegister[0] = new WordCountEntity();
        classesToRegister[1] = new LogAnalyticUtilInfo();
        classesToRegister[2] = new LogAnalyticUtilHistCount();
        m_numOperators = 3;

        m_dummyWatermarkMarkerType = "WordCountEntity";
        setQueuesAndRuntime();
        m_aggOperator = new CustomLogAnalyticGlobalAggOperator(m_numOperators * Config.QUERY_REPLICATION_FACTOR);
        m_aggCp = new AggregateControlProxy(Config.QUERY_REPLICATION_FACTOR + 1,
                m_aggOperator);
        m_aggOperator.setNextQueue(m_finalCp);

        // Instantiate all the query instances
        for (int j = 0; j < Config.QUERY_REPLICATION_FACTOR; j++) {
            m_customOperators[0][j] = new CustomLogAnalyticFilterOperator(j, m_firstCp[j]);
            m_customOperators[0][j].setNextQueue(m_internalCps[0][j]);

            int extractOpIdx = Config.QUERY_REPLICATION_FACTOR + j;
            m_customOperators[1][j] = new CustomLogExtractUtilOperator(extractOpIdx,
                    m_internalCps[0][j]);
            m_customOperators[1][j].setNextQueue(m_internalCps[1][j]);

            int dnnGrpByIdx = (Config.QUERY_REPLICATION_FACTOR * 2) + j;
            m_customOperators[2][j] = new CustomLogAnalyticsGroupby(dnnGrpByIdx,
                    m_internalCps[1][j]);
            m_customOperators[2][j].setNextQueue(m_aggCp);
        }
    }
}
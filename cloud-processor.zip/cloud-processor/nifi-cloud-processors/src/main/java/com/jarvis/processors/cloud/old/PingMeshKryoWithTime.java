//package com.jarvis.processors.cloud.old;
//
//import com.esotericsoftware.kryo.Kryo;
//import com.esotericsoftware.kryo.io.Output;
//import com.jarvis.processors.cloud.old.IData;
//import com.jarvis.processors.cloud.old.PingMeshKryo;
//
//public class PingMeshKryoWithTime implements IData {
//    private PingMeshKryo m_data;
//    private long timeQueued;
//
////    public PingMeshKryoWithTime(PingMeshKryo data) {
////        m_data = data;
////        timeQueued = System.currentTimeMillis();
////    }
//
//    public void setTimeQueued() {
//        timeQueued = System.currentTimeMillis();
//    }
//
//    public int getSeqNum() {
//        return getEntity().getSeqNum();
//    }
//
//    public void setSeqNum(int seqNum) {
//        getEntity().setSeqNum(seqNum);
//    }
//
//    public void setEntity(IData data) {
//        m_data = (PingMeshKryo) data;
//        resetQueueTime();
//    }
//
//    public int getFilterPredVal() { return getEntity().getFilterPredVal(); }
//
//    public IData getEntity() {
//        return m_data;
//    }
//
//    public int getPayloadInBytes() {
//        return getEntity().getPayloadInBytes();
//    }
//
//    public long getQueueTime() {
//        return (System.currentTimeMillis() - timeQueued);
//    }
//
//    public void resetQueueTime() {
//        timeQueued = System.currentTimeMillis();
//    }
//
//    public boolean isWaterMark() {
//        return this.getEntity().isWaterMark();
//    }
//
//    public boolean isSubEpochMarker() {
//        return this.getEntity().isSubEpochMarker();
//    }
//
//    public void writeSelfToKryo(Kryo kryo, Output output) {
//        kryo.writeObject(output, (PingMeshKryo) this.getEntity());
//    }
//
//    public int getKey() {
//        return getEntity().getKey();
//    }
//
//    public int getValue() {
//        return getEntity().getValue();
//    }
//
//    public int getHotKey() { return getEntity().getHotKey(); }
//}
package com.jarvis.processors.cloud.workloads;

import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.AggregateControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import com.jarvis.processors.cloud.data.SrcClusterStatsKryo;
import com.jarvis.processors.cloud.operators.*;

// Implements S2SProbe query on stream processor
public class PingMeshQuery1 extends Workload {

    public PingMeshQuery1() {
        super();

        classesToRegister = new IData[3];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();
        classesToRegister[2] = new SrcClusterStatsKryo();

        m_numOperators = 2;
        m_dummyWatermarkMarkerType = "PingMeshKryo";
        setQueuesAndRuntime();
        m_aggOperator = new CustomGlobalAggOperator(m_numOperators * Config.QUERY_REPLICATION_FACTOR);
        m_aggCp = new AggregateControlProxy(Config.QUERY_REPLICATION_FACTOR + 1,
                m_aggOperator);
        m_aggOperator.setNextQueue(m_finalCp);

        // Instantiate query instances
        for (int j = 0; j < Config.QUERY_REPLICATION_FACTOR; j++) {
            m_customOperators[0][j] = new CustomFilterOperator(j, m_firstCp[j]);
            m_customOperators[0][j].setNextQueue(m_internalCps[0][j]);

            int groupingIdx = Config.QUERY_REPLICATION_FACTOR + j;
            m_customOperators[1][j] = new CustomFullGroupbyOperator(groupingIdx,
                    m_internalCps[0][j]);
            m_customOperators[1][j].setNextQueue(m_aggCp);
        }
    }
}

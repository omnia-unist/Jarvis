package com.jarvis.processors.cloud;

import org.apache.nifi.logging.ComponentLog;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;

// Reads input config file and stores all config information
public class Config {
    public static String DEBUG_MODE;
    public static int JOIN_TABLE_SIZE;
    public static int JOIN_KEY_START;
    public static boolean IS_TEST_PHASE;
    public static String WORKLOAD;
    public static final int SIZE_OF_INT = 4;
    public static final int SIZE_OF_FLOAT = 4;
    public static Boolean FILTER_OUT_ANOMALY;
    public static int QUERY_REPLICATION_FACTOR;
    public static int NUM_EDGES;
    public static boolean ENABLE_GLOBAL_AGG;

    public static void loadConfig(ComponentLog logger, String configFilePath) {
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(configFilePath))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONObject configObj = (JSONObject) ((JSONArray) obj).get(0);

            JSONObject configValues = (JSONObject) configObj.get("configValues");
            DEBUG_MODE = (String) configValues.get("debugMode");
            logger.debug("[Config.loadConfig] debug mode is " + DEBUG_MODE);
            String joinTableSizeAsStr = (String) configValues.get("joinTableSize");
            JOIN_TABLE_SIZE = Integer.parseInt(joinTableSizeAsStr);
            logger.debug("[Config.loadConfig] join table size is " + JOIN_TABLE_SIZE);
            String joinKeyStartAsStr = (String) configValues.get("joinKeyStart");
            JOIN_KEY_START = Integer.parseInt(joinKeyStartAsStr);
            logger.debug("[Config.loadConfig] join key start is " + JOIN_KEY_START);
            String isTestPhase = (String) configValues.get("isTestPhase");
            IS_TEST_PHASE = isTestPhase.equals("yes") ? true : false;
            logger.debug("[Config.loadConfig] is test phase? " + IS_TEST_PHASE);

            String filterOutAnomaly = ((String) configValues.get("filterOutAnomaly")).toLowerCase();
            if(filterOutAnomaly.equals("none")) {
                FILTER_OUT_ANOMALY = null;
            } else {
                if(filterOutAnomaly.equals("true")) {
                    FILTER_OUT_ANOMALY = true;
                } else {
                    FILTER_OUT_ANOMALY = false;
                }
            }

            WORKLOAD = (String) configValues.get("workload");
            logger.debug("[Config.loadConfig] workload is " + WORKLOAD);

            QUERY_REPLICATION_FACTOR = Integer.parseInt((String) configValues.get("queryReplicationFactor"));
            logger.debug("[Config.loadConfig] Query replication factor is " + QUERY_REPLICATION_FACTOR);

            NUM_EDGES = Integer.parseInt((String) configValues.get("numEdges"));
            logger.debug("[Config.loadConfig] Number of edges is " + NUM_EDGES);

            ENABLE_GLOBAL_AGG = Boolean.parseBoolean((String) configValues.get("enableGlobalAgg"));
            if(ENABLE_GLOBAL_AGG) {
                logger.debug("[Config.loadConfig] Global agg enabled");
            } else {
                logger.debug("[Config.loadConfig] Global agg is not enabled");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

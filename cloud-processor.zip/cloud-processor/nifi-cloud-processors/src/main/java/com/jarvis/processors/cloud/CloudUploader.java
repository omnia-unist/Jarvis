package com.jarvis.processors.cloud;

import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.ProcessSession;
import org.apache.nifi.processor.Relationship;
import org.apache.nifi.processor.io.OutputStreamCallback;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicReference;

// Class to collect data and serialize it, sending to NiFi final output link on the stream processor side
public class CloudUploader {

    Relationship m_MYRELATIONSHIP;
    public CloudUploader(Relationship MY_RELATIONSHIP) {
        m_MYRELATIONSHIP = MY_RELATIONSHIP;
    }

    // Sends the accumulated final query output to NiFi output link
    public void sendToCloud(int opId, byte[] windowContent) {
        ProcessSession session;
        synchronized (MyProcessor.m_sessionFactoryLock) {
            session = MyProcessor.m_sessionFactory.createSession();
        }

        try {
            // Write out to flowfiles
            JarvisLogger.debug("[CloudUploader.sendToCloud] The size of network queue is " +
                    windowContent.length);
            if (windowContent.length > 0) {
                final AtomicReference<FlowFile> flowFile = new AtomicReference<>(session.create());
                flowFile.set(session.write(flowFile.get(), new OutputStreamCallback() {
                    @Override
                    public void process(OutputStream outNetwork) throws IOException {
                        outNetwork.write(windowContent);
                    }
                }));

                session.transfer(flowFile.get(), m_MYRELATIONSHIP);
            }

            session.commit();
        } catch (Exception ex) {
            session.rollback();
        }
    }
}
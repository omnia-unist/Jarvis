/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jarvis.processors.cloud;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.KryoException;
import com.esotericsoftware.kryo.io.Input;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.*;
import com.jarvis.processors.cloud.operators.*;
import com.jarvis.processors.cloud.workloads.*;
import org.apache.nifi.annotation.behavior.ReadsAttribute;
import org.apache.nifi.annotation.behavior.ReadsAttributes;
import org.apache.nifi.annotation.behavior.WritesAttribute;
import org.apache.nifi.annotation.behavior.WritesAttributes;
import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.SeeAlso;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.annotation.lifecycle.OnScheduled;
import org.apache.nifi.components.PropertyDescriptor;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.*;
import org.apache.nifi.processor.exception.ProcessException;
import org.apache.nifi.processor.io.InputStreamCallback;
import org.apache.nifi.processor.util.StandardValidators;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Entry point for NiFi to execute the Jarvis system on stream processor side
@Tags({"example"})
@CapabilityDescription("Provide a description")
@SeeAlso({})
@ReadsAttributes({@ReadsAttribute(attribute="", description="")})
@WritesAttributes({@WritesAttribute(attribute="", description="")})
public class MyProcessor extends AbstractSessionFactoryProcessor {

    public static final PropertyDescriptor MY_PROPERTY = new PropertyDescriptor
            .Builder().name("MY_PROPERTY")
            .displayName("My property")
            .description("Example Property")
            .required(true)
            .addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
            .build();

    // NiFi dataflow connector to send final query output on stream processor
    public static final Relationship MY_RELATIONSHIP = new Relationship.Builder()
            .name("MY_RELATIONSHIP")
            .description("Example relationship")
            .build();

    // [Deprecated] Seconnd NiFi dataflow connector
    public static final Relationship MY_RELATIONSHIP_1 = new Relationship.Builder()
            .name("MY_RELATIONSHIP_1")
            .description("Example relationship 1")
            .build();

    private List<PropertyDescriptor> descriptors;

    private Set<Relationship> relationships;

    IControlProxy[][] m_internalCps;
    IControlProxy m_finalCp;

    // List of first control proxies (for multiple queries)
    IControlProxy[] m_firstCp;

    // Workload to replicate for each query instance
    Workload m_workload;
    Hashtable<Integer, Integer> m_latestEpochSeen;

    public static Object m_sessionFactoryLock;
    private Object m_syncEpochsLock;
    public static ProcessSessionFactory m_sessionFactory;

    CustomOperator[] m_operators;

    // Flag to indicate if NiFi processor initialized with Jarvis code
    private AtomicBoolean m_processorInitialized = new AtomicBoolean(false);

    // Stores the latest watermark sequence number sent to query
    private AtomicInteger m_latestWatermarkSeqNum = new AtomicInteger(0);

    @Override
    protected void init(final ProcessorInitializationContext context) {
        final List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();
        descriptors.add(MY_PROPERTY);
        this.descriptors = Collections.unmodifiableList(descriptors);

        final Set<Relationship> relationships = new HashSet<Relationship>();
        relationships.add(MY_RELATIONSHIP);
        relationships.add(MY_RELATIONSHIP_1);
        this.relationships = Collections.unmodifiableSet(relationships);
        // TODO: need to shutdown executor service
    }

    @Override
    public Set<Relationship> getRelationships() {
        return this.relationships;
    }

    @Override
    public final List<PropertyDescriptor> getSupportedPropertyDescriptors() {
        return descriptors;
    }

    @OnScheduled
    public void onScheduled(final ProcessContext context) {
        initializeFromConfig(context.getProperty(MY_PROPERTY).getValue());
    }

    // Read config and initialize workload/first control proxies
    private void initializeFromConfig(String configFilePath) {
        if(!m_processorInitialized.get()) {
            Config.loadConfig(getLogger(), configFilePath);
            JarvisLogger.initialize(getLogger());

            m_syncEpochsLock = new Object();
            m_sessionFactoryLock = new Object();

            JarvisLogger.info("[MyProcessor.initializeFromConfig] Running onScheduled initialization code");
            switch (Config.WORKLOAD) {
                case "PingMeshQuery1":
                    m_workload = new PingMeshQuery1();
                    break;
                case "WordCountQuery1":
                    m_workload = new WordCountQuery1();
                    break;
                case "ChainMapQuery1":
                    m_workload = new ChainMapQuery1();
                    break;
                case "JoinProfile1":
                    m_workload = new JoinProfile1();
                    break;
                case "ToRIpQueryProfile":
                    m_workload = new ToRIpQueryProfile();
                    break;
                case "LogAnalyticsQuery":
                    m_workload = new LogAnalyticsQuery();
                    break;
                default:
                    JarvisLogger.info("[MyProcessor.initializeFromConfig] Encountered unknown workload: " + Config.WORKLOAD);
                    throw new UnsupportedOperationException("Unknown workload");
            }

            JarvisLogger.info("[MyProcessor.initializeFromConfig] Getting workload entities");
            m_firstCp = m_workload.getFirstCps();
            m_finalCp = m_workload.getFinalCp();
            m_internalCps = m_workload.getInternalCps();
            m_workload.beginWorkload();
            m_latestEpochSeen = new Hashtable<>();
            JarvisLogger.info("[MyProcessor.initializeFromConfig] Started workload");

            // TODO: need to shutdown executor service
            m_processorInitialized.set(true);
        }
    }

    private ConcurrentLinkedDeque<FlowFile> m_flowFilesQueue = new ConcurrentLinkedDeque<>();

    // Triggers new epoch to begin when flowfile from data source arrives in NiFi processor
    @Override
    public final void onTrigger(ProcessContext context, ProcessSessionFactory sessionFactory) throws ProcessException {
        ProcessSession session;
        if(!Config.IS_TEST_PHASE) {
            session = sessionFactory.createSession();
        } else {
            synchronized (m_sessionFactoryLock) {
                m_sessionFactory = sessionFactory;
                session = m_sessionFactory.createSession();
            }
        }

        try {
            extractRecords(session);
            session.commit();
        } catch (Throwable var5) {
            session.rollback(true);
            throw var5;
        }

    }

    // Stores index of query instance to send the data item to, by distributing data load
    // in a round robin fashion across all query instances
    private AtomicLong m_roundRobinReplicaIdx = new AtomicLong(0);

    // Obtains the starting control proxy where data items need to be sent, depending on the control
    // proxy on data source from which the data in the flowfile were drained
    private IControlProxy getStartingCp(Kryo kryo, Input flowfileInputReader) {
        IControlProxy startingCp;
        kryo.register(Integer.class);
        Integer cpId = kryo.readObject(flowfileInputReader, Integer.class);
        int queryReplica = (int) (m_roundRobinReplicaIdx.getAndIncrement() %
                Config.QUERY_REPLICATION_FACTOR);
        JarvisLogger.info("[MyProcessor.getStartingCp] Cp Id is: " + cpId);
        if(cpId == 0) {
            startingCp = m_firstCp[queryReplica];
        } else if(cpId==-1) {
            startingCp = m_finalCp;
        } else {
            startingCp = m_internalCps[cpId-1][queryReplica];
        }

        return startingCp;
    }

    // Gets the data type for the data items in the flow file
    private IData getDataTypeInst(Kryo kryo, Input flowfileInputReader) {
        IData dataTypeInst;
        kryo.register(String.class);
        String dataType = kryo.readObject(flowfileInputReader, String.class);
        JarvisLogger.info("[MyProcessor.getDataTypeInst] data type is: " + dataType);
        switch (dataType) {
            case "JoinResult":
                JarvisLogger.info(" [MyProcessor.getDataTypeInst] Processing JoinResult datatype");
                dataTypeInst = new JoinResult();
                break;
            case "PingMeshKryo":
                JarvisLogger.info(" [MyProcessor.getDataTypeInst] Processing PingMeshKryo datatype");
                dataTypeInst = new PingMeshKryo();
                break;
            case "PingMeshKryoWithTime":
                JarvisLogger.info("[MyProcessor.getDataTypeInst] Processing PingMeshKryoWithTime datatype");
                dataTypeInst = new PingMeshKryoWithTime();
                break;
            case "SrcClusterStatsKryo":
                JarvisLogger.info("[MyProcessor.getDataTypeInst] Processing SrcClusterStatsKryo datatype");
                dataTypeInst = new SrcClusterStatsKryo();
                break;
            case "WordCountEntity":
                JarvisLogger.info("[MyProcessor.getDataTypeInst] Processing WordCountEntity datatype");
                dataTypeInst = new WordCountEntity();
                break;
            case "LogAnalyticUtilInfo":
                JarvisLogger.info("[MyProcessor.getDataTypeInst] Processing LogAnalyticUtilInfo datatype");
                dataTypeInst = new LogAnalyticUtilInfo();
                break;
            case "LogAnalyticUtilHistCount":
                JarvisLogger.info("[MyProcessor.getDataTypeInst] Processing LogAnalyticUtilHistCount datatype");
                dataTypeInst = new LogAnalyticUtilHistCount();
                break;
            default:
                throw new UnsupportedOperationException("Unsupported data type found when deserializing");
        }

        return dataTypeInst;
    }

    // Deserializes records from flowfiles and sends them to first control proxies of query instances in
    // round robin fashion
    public void extractRecords(final ProcessSession session) throws ProcessException {
        FlowFile flowFile = session.get();
        if ( flowFile == null ) {
            return;
        }

        int edgeId = Integer.parseInt(flowFile.getAttribute("edgeId"));
        int epochId = Integer.parseInt(flowFile.getAttribute("epochId"));

        // Profiling operators
        long[] startExtract = {0};
        long[] endExtract = {0};
        session.read(flowFile, new InputStreamCallback() {
            @Override
            public void process(InputStream inputStream) throws IOException {
                try {

                    System.setProperty("rx.ring-buffer.size", "150000");

                    // Reading the input data
                    Input input = new Input(inputStream);
                    startExtract[0] = System.currentTimeMillis();

                    Kryo kryo = new Kryo();
                    IControlProxy startingCp = getStartingCp(kryo, input);
                    IData dataTypeInst = getDataTypeInst(kryo, input);
                    Class<IData> dataTypeInstClass = (Class<IData>) dataTypeInst.getClass();
                    kryo.register(dataTypeInstClass);
                    IData object2 = kryo.readObject(input, dataTypeInstClass);

                    JarvisLogger.info("[MyProcessor.extractRecordsSlow] Starting new epoch v12");
                    int recordCount = 1;
                    boolean watermarkRead = false;
                    int latestEpochSeenSize = 0;
                    AtomicInteger debugTotalRecordCount = new AtomicInteger(0);
                    while (object2 != null) {
                        try {
                            if (object2.isWaterMark()) {
                                watermarkRead = true;
                                JarvisLogger.info("[MyProcessor.extractRecords] Watermark has been read. GOing to read next " +
                                        "startig Cp and datatype instance, " + debugTotalRecordCount.get() +" records and size of m_latestEpochSeen map: " +
                                        latestEpochSeenSize + ",new datatype inst:");
                                debugTotalRecordCount.set(0);

                                // Reset the kryo object and starting CP, along with other counters for next epoch records in
                                // the flowfile
                                kryo = new Kryo();
                                startingCp = getStartingCp(kryo, input);
                                dataTypeInst = getDataTypeInst(kryo, input);
                                dataTypeInstClass = (Class<IData>) dataTypeInst.getClass();
                                kryo.register(dataTypeInstClass);
                                JarvisLogger.info("[MyProcessor.extractRecords] Next datatype is: " +
                                        dataTypeInstClass.getTypeName());

                                // NOTE: don't put watermark for each new flowfile, instead aggregate multiple
                                // flowfiles together based on configuration
                            } else {
                                recordCount++;
                                debugTotalRecordCount.getAndIncrement();
                                startingCp.put(object2);
                            }

                            object2 = kryo.readObject(input, dataTypeInstClass);
                        } catch (NullPointerException nulEx) {
                            JarvisLogger.info("[MyProcessor.extractRecords] null pointer exception:" + nulEx.toString());
                            throw nulEx;
                        } catch (KryoException ex) {
                            JarvisLogger.info("[MyProcessor.extractRecords] Underflow error:" + ex.toString());
                            System.out.println("Read value count: " + debugTotalRecordCount.get());
                            debugTotalRecordCount.set(0);
                            break;
                        } catch (Exception ex) {
                            JarvisLogger.info("[MyProcessor.extractRecords] Unknown exception:" + ex.toString());
                            throw ex;
                        }
                    }

                    if(!watermarkRead) {
                        JarvisLogger.info("Missing watermark in flowfile in cloud");
                        throw new UnsupportedOperationException("Missing watermark in flowfile in cloud");
                    }

                    synchronized (m_syncEpochsLock) {
                        if(epochId!=-1) {
                            m_latestEpochSeen.put(edgeId, epochId);

                            // Find minimum epoch ID
                            int minEpoch = Integer.MAX_VALUE;
                            if (m_latestEpochSeen.size() == Config.NUM_EDGES) {
                                for (Integer edgeIdIt :
                                        m_latestEpochSeen.keySet()) {
                                    if (m_latestEpochSeen.get(edgeIdIt) < minEpoch) {
                                        minEpoch = m_latestEpochSeen.get(edgeIdIt);
                                    }
                                }

                                if (minEpoch > m_latestWatermarkSeqNum.get()) {
                                    // Send watermark because we saw epochs from all data sources for current epoch
                                    JarvisLogger.info("[MyProcessor.extractRecordsSlow] we can send " +
                                            "watermark now: " + m_latestWatermarkSeqNum.get());
                                    IData firstWatermark = Utils.getWatermarkMarker(m_workload.getFirstCpWatermarkType());
                                    firstWatermark.setSeqNum(m_latestWatermarkSeqNum.getAndIncrement());
                                    for (int replicaIdx = 0; replicaIdx < Config.QUERY_REPLICATION_FACTOR; replicaIdx++) {
                                        m_firstCp[replicaIdx].putWaterMark(firstWatermark);
                                    }
                                    JarvisLogger.info("[MyProcessor.extractRecords] Final watermark seen is: "
                                            + m_latestWatermarkSeqNum.get());
                                }
                            }
                        }

                        endExtract[0] = System.currentTimeMillis();
                    }

                    // Close the input stream before joining on the thread
                    input.close();
                    JarvisLogger.info("[MyProcessor.extractRecords] record count is " + recordCount + ", with epoch" +
                            " ID: " + epochId + ", edge ID: " + edgeId + ", and extraction time: " +
                            (endExtract[0] - startExtract[0]));
                } catch (Exception e) {
                    e.printStackTrace();
                    JarvisLogger.info("Something went wrong in reading input flowfile: " + e.toString());
                    System.out.println("File not found exception");
                }
            }
        });

        session.remove(flowFile);
    }
}


package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Map operator used to implement custom transforms on input records
public class CustomMapOperator extends CustomOperator {

    PingMeshKryoWithTime m_waterMarkEntryWithTime;

    public CustomMapOperator(int opId, IControlProxy currentQueue, double reductionRatio) {
        super(opId, currentQueue, reductionRatio);
        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
        PingMeshKryo waterMarkEntry = new PingMeshKryo();
        waterMarkEntry.setWatermarkMarker();
        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);

    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
        map(v -> {
            return v;
        }).
        subscribe(
            new Observer<IData>() {
                @Override
                public void onSubscribe(Disposable d) {}

                @Override
                public void onComplete() {
                    m_waterMarkEntryWithTime.resetQueueTime();
                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] created watermark: " +
                            m_waterMarkSeqNum.get());
                    m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                    m_recentEpochEndTime = System.currentTimeMillis();
                    m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                    JarvisLogger.debug("[CustomMapOperator.onComplete] Thread ID is: " +
                            Thread.currentThread().getId() + ", epoch duration is: " +
                            m_recentEpochDuration);
                }

                @Override
                public void onError(Throwable throwable) {
                }

                @Override
                public void onNext(IData data) {
                    try {
                        if(randGen.nextDouble() <= m_reductionRatio) {
                            data.resetQueueTime();
                            m_nextQueue.put(data);
                            m_numOutRecords[0]++;
                        }
                    } catch (Exception e) {
                        JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                    }
                }

            }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}



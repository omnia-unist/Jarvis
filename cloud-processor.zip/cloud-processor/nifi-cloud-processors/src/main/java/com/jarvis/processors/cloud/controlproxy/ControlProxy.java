package com.jarvis.processors.cloud.controlproxy;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.cloud.*;
import com.jarvis.processors.cloud.data.IData;
import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Intermediate control proxy to manage the queue buffers of intermediate operators in the query pipeline
public class ControlProxy implements IControlProxy {
    final int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Output m_networkOutput;
    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    Object watermarkLock = new Object();
    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);
    volatile double m_probSendingToEdge = 1;
    AtomicBoolean m_disableSendingToEdge = new AtomicBoolean(false);
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    private AtomicInteger m_totalInputRecords;

    private Object m_synchronizeWmLock;
    AtomicBoolean m_previousTakeWasWm = new AtomicBoolean(false);

    public ControlProxy(int queueId) {
        m_queueId = queueId;
        JarvisLogger.info("[ControlProxy.ControlProxy] queue ID is: " + m_queueId);
        m_networkOutputStream = new ByteArrayOutputStream();
        m_networkOutput = new Output(m_networkOutputStream);
        m_startEpochTimer.set(System.currentTimeMillis());
        m_totalInputRecords = new AtomicInteger(0);
        m_synchronizeWmLock = new Object();
    }

    private AtomicInteger m_debugReadRecords = new AtomicInteger(0);

    // Reads the operator queue and sends records to next downstream operator
    public IData take() {
        IData takenVal = null;
        try{
            takenVal = queue.take();
            if (takenVal.isWaterMark()) {
                JarvisLogger.debug(m_queueId + " [ControlProxy.take] After reading outside of lock, " +
                        "watermark size in take is " + waterMarkCountInQueue.get());

                // Reset the epoch size to signify end of current epoch processing by operator
                m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
                m_currentEpochDataSizeSentToEdge = 0;
                JarvisLogger.debug(m_queueId + " [ControlProxy.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge);
                JarvisLogger.info("[ControlProxy.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge + ", read records: " + m_debugReadRecords.getAndSet(0));
                m_previousTakeWasWm.set(true);
            } else {
                m_currentEpochDataSizeSentToEdge += takenVal.getPayloadInBytes();
                m_debugReadRecords.incrementAndGet();
            }

        } catch (Exception ex) {
            JarvisLogger.debug("[SyncQueue.take] Exception in dequeueuing " + ex.toString());
            ex.printStackTrace();
        }

        return takenVal;
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator
    public void put(IData item) {
        try {
            m_totalInputRecords.getAndIncrement();
            queue.put(item);
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    public void putWaterMark(IData watermark) {
        try {
            synchronized (m_synchronizeWmLock) {
                waterMarkCountInQueue.incrementAndGet();
                queue.put(watermark);
                m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
                JarvisLogger.debug(m_queueId + " [putWaterMark] Watermark count in putWaterMark " +
                        waterMarkCountInQueue.get() + " and " + " size is " + size() + ", watermark seq num: " +
                        watermark.getSeqNum());
                JarvisLogger.info(m_queueId + " [ControlProxy.putWaterMark] Watermark count in putWaterMark " +
                        waterMarkCountInQueue.get() + " and total input records is: " + m_totalInputRecords.get()
                        + ", watermark seq num: " + watermark.getSeqNum());
                m_totalInputRecords.set(0);
                lastPutWasWatermark.set(true);
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public int size() {
        return queue.size();
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }
}

package com.jarvis.processors.cloud.controlproxy;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.cloud.CloudUploader;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.data.IData;
import org.apache.nifi.processor.Relationship;

import java.io.*;
import java.util.concurrent.atomic.AtomicInteger;

// Final control proxy in the query on stream processor,
// which sends data to the output link on NiFi processor as the final query output
public class FinalControlProxy implements IControlProxy {
    ByteArrayOutputStream m_outputStream;
    Output m_output;
    Kryo m_kryo;
    AtomicInteger m_size;
    CloudUploader m_cloudUploader;
    private Object m_waterMarkInExitLock;
    private Integer m_recentWaterMarkSeqNum = -1;
    private Object m_kryoObjectLock = new Object();

    public volatile double m_prevWindowDataSizeSentToEdge = 0;
    double m_currentWindowDataSizeSentToEdge = 0;

    public FinalControlProxy(IData[] classesToRegister, Relationship MY_RELATIONSHIP) {
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }

        m_kryo.register(Integer.class);
        m_kryo.register(String.class);

        m_outputStream = new ByteArrayOutputStream();
        m_output = new Output(m_outputStream);
        m_waterMarkInExitLock = new Object();
        m_cloudUploader = new CloudUploader(MY_RELATIONSHIP);
    }

    public double getRecentPayloadSizeOnEdge() {
        return m_prevWindowDataSizeSentToEdge;
    }
    AtomicInteger m_debugNumRecords = new AtomicInteger(0);

    // Adds records to payload for sending to output link on NiFi processor
    public void put(IData item) {
        try {
            synchronized(m_kryoObjectLock) {
                item.writeSelfToKryo(m_kryo, m_output);
                m_debugNumRecords.getAndIncrement();
                m_currentWindowDataSizeSentToEdge += item.getPayloadInBytes();
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
        }
    }

    // Adds watermark to payload before sending to output link on NiFi processor
    public void putWaterMark(IData item) {
        try {
            synchronized(m_kryoObjectLock) {
                item.writeSelfToKryo(m_kryo, m_output);
                byte[] epochContent = getByteArrayOutputStreamContent();
                this.reset();

                // -1 denotes that this is the fully processed query data
                if(Config.IS_TEST_PHASE) {
                    new Thread(() -> m_cloudUploader.sendToCloud(-1, epochContent)).start();
                }

                m_prevWindowDataSizeSentToEdge = m_currentWindowDataSizeSentToEdge;
                m_currentWindowDataSizeSentToEdge = 0;
                JarvisLogger.debug("[FinalControlProxy.putWaterMark] Size of recent window in output queue is " +
                        m_prevWindowDataSizeSentToEdge + " , seq num is " + item.getSeqNum());
                JarvisLogger.info("[FinalControlProxy.putWaterMark] Seen watermark in final queue with" +
                        " seq num: " + item.getSeqNum() + ", with size of records = " + m_prevWindowDataSizeSentToEdge +
                        ", with per item size: " + item.getPayloadInBytes() + ", num of records:" + m_debugNumRecords.get());
                m_debugNumRecords.set(0);
                synchronized (m_waterMarkInExitLock) {
                    m_recentWaterMarkSeqNum = item.getSeqNum();
                    m_waterMarkInExitLock.notifyAll();
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
        }
    }

    public byte[] getByteArrayOutputStreamContent() {
        try {
            m_output.flush();
            m_outputStream.flush();
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing output queue wrapper: " + ex.toString());
        }

        return m_outputStream.toByteArray();
    }

    public void reset() {
        m_outputStream.reset();
        m_output.reset();
    }

    public void clear() {
        try {
            m_outputStream.flush();
            m_output.flush();
            m_outputStream.reset();
            m_output.reset();
            m_size.set(0);
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
        }
    }

    public long getRecentEpochDuration() {
        // No op
        throw new UnsupportedOperationException();
    }

   public IData take() {
        // No op
        throw new UnsupportedOperationException();
    }
}
package com.jarvis.processors.cloud.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.data.IData;

// Stores the result of join operator in T2TProbe query
public class JoinResult implements IData {
    int m_seq_num;

    // Stores rtt value for probe
    int m_rtt;

    // Stores ToR ID for probe made by server IP
    int m_torId;
    private long m_timeQueued;
    int m_count;

    public float getMaxValue() {
        return m_rtt;
    }

    public float getMinValue() {
        return m_rtt;
    }

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for JoinResult class");
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for JoinResult class");
    }

    public int getCount() {
        return m_count;
    }

    public JoinResult() {}

    public JoinResult(int rtt, int torId) {
        m_rtt = rtt;
        m_torId = torId;
        m_count = 1;
    }

    public int getSeqNum() {
        return m_seq_num;
    }

    public void setSeqNum(int seqNum) {
        m_seq_num = seqNum;
    }

    public String toString() {
        return m_seq_num + "," + m_rtt + "," + m_torId;
    }

    public int getPayloadInBytes() {
        return 3 * Config.SIZE_OF_INT;
    }

    public void setJoinValue(int value) {
        // No op
        throw new UnsupportedOperationException("JoinResult cannot be join value");
    }

    public Integer getJoinValue() {
        // No op
        throw new UnsupportedOperationException("JoinResult cannot be join value");
    }

    public boolean isWaterMark() {
        return (m_torId == Integer.MIN_VALUE);
    }

    public Integer getGroupingKey() {
        return m_torId;
    }

    public Integer getGroupingValue() {
        return m_rtt;
    }

    public void setWatermarkMarker() {
        m_torId=Integer.MIN_VALUE;
    }

    public void setGroupingKey(int key) {
        // No op
        throw new UnsupportedOperationException("JoinResult mapping cannot have grouping key");
    }


    public Integer getJoinKey() {
        // No op
        throw new UnsupportedOperationException("JoinResult cannot have join key");
    }

    public void setJoinKey(int key) {
        // No op
        throw new UnsupportedOperationException("JoinResult cannot have join key");
    }

    public void resetQueueTime() {
        m_timeQueued = System.currentTimeMillis();
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - m_timeQueued);
    }

    public IData getEntity() { return null; }
    public void setEntity(IData data) {}

    public void writeSelfToKryo(Kryo kryo, Output output) {
        // No-op
    }

    public boolean isJoinMismatchMarker() {
        return m_torId==Integer.MAX_VALUE;
    }

    public void setJoinMismatchMarker() {
        m_torId = Integer.MAX_VALUE;
    }

    public Integer getFilterPredVal() {
        throw new UnsupportedOperationException("JoinResult is not used in filter operator");
    }

    public String getWordKey() {
        throw new UnsupportedOperationException("Not supported for numeric data");
    }
}
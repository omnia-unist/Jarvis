package com.jarvis.processors.cloud;

import org.apache.nifi.logging.ComponentLog;

import java.awt.*;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicBoolean;

// Logger class
public class JarvisLogger {
    static ComponentLog m_logger;
    static AtomicBoolean initialized = new AtomicBoolean(false);
    public static AtomicBoolean verboseMode = new AtomicBoolean(false);
    public static FileWriter m_myWriter;
    public static void initialize(ComponentLog logger) {
        if(!initialized.get()) {
            initialized.set(true);
            m_logger = logger;

            if(Config.DEBUG_MODE.equals("VERBOSE")) {
                verboseMode.set(true);
            }

            m_logger.debug("Debug status in config file is: " + Config.DEBUG_MODE);
            m_logger.debug("Join key status is: " + Config.JOIN_KEY_START);
            m_logger.debug("Join table size is: " + Config.JOIN_TABLE_SIZE);
        }

        try {
            m_myWriter = new FileWriter("tempDebug.txt");
        } catch(Exception ex) {
            System.err.println("Failed creating file in logger, exception: " + ex.toString());
        }
    }

    public static void debug(String s) {
        if(initialized.get() && verboseMode.get()) {
            SimpleDateFormat formatOnly = new SimpleDateFormat("HH:mm:ss");
            String time = formatOnly.format(Calendar.getInstance().getTime());
            m_logger.debug("[ATUL DEBUG]" + time + " [Thread id: " + Thread.currentThread().getId() + "]: " + s);
        }

    }

    public static void info(String s) {
        if(initialized.get()) {
            SimpleDateFormat formatOnly = new SimpleDateFormat("HH:mm:ss");
            String time = formatOnly.format(Calendar.getInstance().getTime());
            m_logger.info("[ATUL INFO] " + time + " [Thread id: " + Thread.currentThread().getId() + "]: " + s);
            try {
                m_myWriter.write("[ATUL INFO] " + time + " [Thread id: " + Thread.currentThread().getId() + "]: " + s +
                        "\n");
            } catch(Exception ex) {
                System.err.println("Failed writing to file in logger, exception: " + ex.toString());
            }
        }
    }
}

package com.jarvis.processors.cloud.controlproxy;

import com.esotericsoftware.kryo.Kryo;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.cloud.*;
import com.jarvis.processors.cloud.data.IData;

import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Control proxy for the operator queue of first operator in query on stream processor side.
public class FirstControlProxy implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);

    // Control proxy variables
    volatile double m_probSendingToEdge = 1;
    AtomicBoolean m_disableSendingToEdge = new AtomicBoolean(false);
    public volatile AtomicInteger m_prevEpochDataSizeSentToEdge = new AtomicInteger(0);
    private AtomicInteger m_currentEpochDataSizeSentToEdge = new AtomicInteger(0);
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    private AtomicInteger m_totalInputRecords;
    boolean m_beginStreaming = true;

    final Object m_readQueueLock = new Object();
    final CyclicBarrier m_readQueueBarrier = new CyclicBarrier(Config.QUERY_REPLICATION_FACTOR);;

    IControlProxy m_outputQueue;

    private Object m_synchronizeWmLock;

    public FirstControlProxy(IControlProxy outputQueue) {
        m_queueId = 0;
        m_outputQueue = outputQueue;
        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
        m_synchronizeWmLock = new Object();
    }

    private long m_pendingWmTakes = 0;

    private AtomicInteger m_debugReadRecords = new AtomicInteger(0);
    private int m_numThreadsReadWm = 0;

    // Reads the output queue for first operator and sends records to next downstream operator
    // Because we introduced query replication on stream processor node, we can have
    // multiple threads (=replication factor) processing incoming stream from data sources.
    // But the first control proxy is per-replicated query, so need not be thread safe.
    public IData take() throws InterruptedException, BrokenBarrierException {
        IData takenVal = queue.take();
        if(takenVal != null) {
            if (takenVal.isWaterMark()) {
                // No-op
            } else {
                m_debugReadRecords.incrementAndGet();
                m_currentEpochDataSizeSentToEdge.addAndGet(takenVal.getPayloadInBytes());
            }
        }

        return takenVal;
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator
    public void put(IData item) {
        try {
            m_totalInputRecords.getAndIncrement();
            queue.put(item);
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    public void putWaterMark(IData watermark) {
        try {
            queue.put(watermark);
            JarvisLogger.debug(m_queueId +
                    " and " + " size is " + size() + ", watermark seq num: " +
                    watermark.getSeqNum());
            JarvisLogger.info(m_queueId + " [FirstControlProxy.putWaterMark] Watermark seen with seq num: " +
                    watermark.getSeqNum() + ", is watermark? : " + watermark.isWaterMark() + ", with " +
                    "total input records put: " + m_totalInputRecords.get());
            m_totalInputRecords.set(0);
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public int size() {
        return queue.size();
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge.get();
        return payloadSize;
    }
}
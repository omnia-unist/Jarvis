package com.jarvis.processors.cloud.operators;


import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.SrcClusterStatsKryo;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

// Custom operator to perform grouping and reduction in S2SProbe and T2TProbe queries,
// on stream processor side
public class CustomFullGroupbyOperator extends CustomOperator {
    SrcClusterStatsKryo m_waterMarkEntryWithTime;

    public CustomFullGroupbyOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntryWithTime = new SrcClusterStatsKryo();
        m_waterMarkEntryWithTime.setSrcCluster(Integer.MIN_VALUE);
        JarvisLogger.info("[CustomFullGroupbyOperator.CustomFullGroupbyOperator] constructor for op: "
                + opId);
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }
    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
        groupBy(v -> v.getGroupingKey()).
                flatMapSingle(grps -> {
                    return grps.toList().map(grpList -> {
                        SrcClusterStatsKryo srcClusterStatsKryo = null;
                        try {
                            int count=0;
                            float avg = 0, max = 0, min = Float.MAX_VALUE;
                            for (IData data :
                                    grpList) {
                                int value = data.getGroupingValue();
                                float maxVal = data.getMaxValue();
                                float minVal = data.getMinValue();
                                if(maxVal > max) {
                                    max = maxVal;
                                }

                                if(minVal < min) {
                                    min = minVal;
                                }

                                avg += (value * data.getCount());
                                count += data.getCount();
                            }

                            srcClusterStatsKryo = new SrcClusterStatsKryo();
                            srcClusterStatsKryo.setSrcCluster((int) grps.getKey());
                            srcClusterStatsKryo.setAvgRtt(avg/(float)count);
                            srcClusterStatsKryo.setMinRtt(min);
                            srcClusterStatsKryo.setMaxRtt(max);
                            srcClusterStatsKryo.setCount(count);

                        } catch (Exception ex) {
                            JarvisLogger.info("[CustomFullGroupbyOperator.setDataflow] ERROR Exception within " +
                                    "groupby operator: " + ex.toString());
                        }

                        return srcClusterStatsKryo;
                    });
                }).
        subscribe(
        new Observer<IData>() {
            @Override
            public void onSubscribe(Disposable d) {}

            @Override
            public void onComplete() {
                m_waterMarkEntryWithTime.resetQueueTime();
                JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] created watermark: " +
                        m_waterMarkSeqNum.get());
                m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                m_recentEpochEndTime = System.currentTimeMillis();
                m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                JarvisLogger.debug("[CustomFullGroupbyOperator.setDataflow] Thread ID is: " +
                        Thread.currentThread().getId() + ", epoch duration is: " +
                        m_recentEpochDuration);
                if(Config.ENABLE_GLOBAL_AGG) {
                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                }

                JarvisLogger.info("[CustomFullGroupbyOperator.onComplete] LP Solver op id: " + m_opId
                        + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount);
            }

            @Override
            public void onError(Throwable throwable) {
            }

            @Override
            public void onNext(IData data) {
                try {
                    data.resetQueueTime();
                    if(Config.ENABLE_GLOBAL_AGG) {
                        m_nextQueue.put(data);
                    }
                    m_numOutRecords[0]++;
                } catch (Exception e) {
                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                }
            }

        }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}



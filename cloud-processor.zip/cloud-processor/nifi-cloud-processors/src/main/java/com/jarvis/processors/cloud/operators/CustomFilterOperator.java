package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.*;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Filter operator used in S2SProbe and T2TProbe queries on the stream processor side
public class CustomFilterOperator extends CustomOperator {

    PingMeshKryoWithTime m_waterMarkEntryWithTime;

    public CustomFilterOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue,1);
        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
        PingMeshKryo waterMarkEntry = new PingMeshKryo();
        waterMarkEntry.setWatermarkMarker();
        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
        filter(v -> Config.FILTER_OUT_ANOMALY == null ? (v.getFilterPredVal() == 0 || v.getFilterPredVal() != 0) :
            (Config.FILTER_OUT_ANOMALY == true ? v.getFilterPredVal() == 0 : v.getFilterPredVal() != 0)).
        subscribe(
        new Observer<IData>() {
            @Override
            public void onSubscribe(Disposable d) {}

            @Override
            public void onComplete() {
                m_waterMarkEntryWithTime.resetQueueTime();
                JarvisLogger.debug(m_opId + " [CustomFilterOperator.onComplete] created watermark: " +
                        m_waterMarkSeqNum.get());
                m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                m_recentEpochEndTime = System.currentTimeMillis();
                m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                JarvisLogger.debug("[CustomFilterOperator.onComplete] Thread ID is: " +
                        Thread.currentThread().getId() + ", epoch duration is: " +
                        m_recentEpochDuration);
                JarvisLogger.info("[CustomFilterOperator.onComplete] LP Solver op id: " + m_opId
                        + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount);
            }

            @Override
            public void onError(Throwable throwable) {
            }

            @Override
            public void onNext(IData data) {
                try {
                    data.resetQueueTime();
                    m_nextQueue.put(data);
                    m_numOutRecords[0]++;
                } catch (Exception e) {
                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                }
            }

        }
);

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}



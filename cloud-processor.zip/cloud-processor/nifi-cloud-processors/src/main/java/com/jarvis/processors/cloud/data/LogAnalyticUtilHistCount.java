package com.jarvis.processors.cloud.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.cloud.Config;

// Stores the histogram count for each bucket, defined by the dimensions of (tenant name, job latency, cpu util, memory util)
// in LogAnalytics query, on stream processor side
public class LogAnalyticUtilHistCount implements IData {
    // Stores the job info dimensions used for bucketing as a single string for aggregation
    private String m_jobInfoSummary;

    // Stores count of items in the bucket defined by dimensions of (tenant name, job latency, cpu util, memory util)
    private int m_count;
    private int m_seqNum;
    private long m_timeQueued;

    public float getMaxValue() {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public float getMinValue() {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public void setCount(int count) { m_count = count; }

    public void setSrcCluster(String srcCluster) {
        m_jobInfoSummary = srcCluster;
    }

    public int getSeqNum() {
        return m_seqNum;
    }

    public int getPayloadInBytes() {
        return (2 * Config.SIZE_OF_INT) + m_jobInfoSummary.getBytes().length;
    }

    public String getWordKey() {
        throw new UnsupportedOperationException("Not supported for numeric data");
    }

    public void setSeqNum(int seqNum) {
        m_seqNum = seqNum;
    }

    public void resetQueueTime() {
        m_timeQueued = System.currentTimeMillis();
    }

    public String getGroupingKey(boolean all) {
        return m_jobInfoSummary;
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for LogAnalyticUtilHistCount class");
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - m_timeQueued);
    }

    public boolean isWaterMark() {
        return (this.m_jobInfoSummary.equals("watermark"));
    }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, this);
    }

    public IData getEntity() {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getGroupingKey() {
        return m_jobInfoSummary.hashCode();
    }

    public Integer getGroupingValue() {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public void setWatermarkMarker() {
        m_jobInfoSummary = "watermark";
    }

    public void setGroupingKey(int key) {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public int getCount() {
        return m_count;
    }

    public void setEntity(IData data) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinKey() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setJoinKey(int key) {
        throw new UnsupportedOperationException();
    }

    public void setJoinValue(int value) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinValue() {
        // No op
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return m_seqNum + "," + m_jobInfoSummary + "," + m_count;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }


    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }


    public Integer getFilterPredVal() { throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount"); }
}

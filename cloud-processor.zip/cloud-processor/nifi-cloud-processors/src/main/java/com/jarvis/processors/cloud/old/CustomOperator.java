//package com.jarvis.processors.cloud.old;
//
//import com.jarvis.processors.cloud.JarvisLogger;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.concurrent.atomic.AtomicInteger;
//
//public abstract class CustomOperator implements  Runnable {
//    int m_queueTimeAnalysisEpoch = 0;
//
//    IQueue m_currentQueue;
//    IQueue m_nextQueue;
//
//    io.reactivex.subjects.PublishSubject<IData> m_subject;
//    long m_totalProcessingTime = 0;
//    long m_maxQueueTime;
//    float m_avgProcessingTime;
//    long m_dataflowBuildDur;
//    Integer[] m_numOutRecords = {0};
//    protected int m_opId;
//    Random randGen = new Random();
//    double m_reductionRatio = 1;
//    int m_recordCount = 0;
//    AtomicInteger m_waterMarkSeqNum = new AtomicInteger(0);
//    private List<Long> m_queueingTimes = new ArrayList<>();
//    protected AtomicBoolean m_subEpochComplete = new AtomicBoolean(false);
//    protected long m_startEpoch;
//    private int m_epochCount = 0;
////    GlobalQueue m_globalQueue;
//
//    public CustomOperator(int opId, ControllerQueue currentQueue, double reductionRatio) {
//        m_opId = opId;
//        m_currentQueue = currentQueue;
//        m_subject = io.reactivex.subjects.PublishSubject.create();
//        m_reductionRatio = reductionRatio;
//    }
//
//    public CustomOperator(int opId, ControllerQueueWithoutAdapt currentQueue, double reductionRatio) {
//        m_opId = opId;
//        m_currentQueue = currentQueue;
//        m_subject = io.reactivex.subjects.PublishSubject.create();
//        m_reductionRatio = reductionRatio;
//    }
//
//    public abstract void setDataflow();
//    public abstract void setNextQueue(IQueue queue);
//
//    public Integer[] getOutputRecCount() {
//        return m_numOutRecords;
//    }
//
//    protected void resetMetrics() {
//        m_maxQueueTime = 0;
//        m_avgProcessingTime = 0;
//        m_dataflowBuildDur = 0;
//        m_numOutRecords[0] = 0;
//        m_totalProcessingTime = 0;
//        m_recordCount = 0;
////        m_queueingTimes.clear();
//    }
//
////    protected void putOnNext(IData data) {
////        synchronized (m_globalQueue.m_enqueueLock) {
////            m_nextQueue.put(data);
////            m_globalQueue.putRecord(m_currentQueue.m_queueId, data);
////        }
////    }
////
////    protected void putOnComplete(IData waterMarkEntryWithTime) {
////        synchronized (m_globalQueue.m_enqueueLock) {
////            m_nextQueue.putWaterMark(waterMarkEntryWithTime);
////            m_globalQueue.putRecord(m_currentQueue.m_queueId, waterMarkEntryWithTime);
////        }
////    }
//
//    public int getOpId() {
//        return m_opId;
//    }
//
////    public boolean processRecord() {
////        IData readObj = m_currentQueue.take();
////        boolean watermarkFound = false;
////        long totalQueueTime = 0;
////        if (readObj != null) {
////            if(readObj.isWaterMark()) {
////                m_subject.onComplete();
////                watermarkFound = true;
////                m_avgProcessingTime = (float) totalProcessingTime / (float) m_recordCount;
////                JarvisLogger.debug("[CustomOperator.run] Records sent from map op " + m_opId + " = "
////                        + m_recordCount + " and written to exit queue: " + m_numOutRecords[0]);
////                resetMetrics();
////                setDataflow();
////            } else {
////                totalQueueTime = readObj.getQueueTime();
////                if(randGen.nextDouble() < m_reductionRatio) {
////                    m_subject.onNext(readObj);
////                    m_recordCount++;
////                }
////
////                if (m_maxQueueTime < totalQueueTime) {
////                    m_maxQueueTime = totalQueueTime;
////                }
////            }
////        }
////
////        return watermarkFound;
////    }
//
//    public void run() {
//        while(true) {
//            try {
//                IData readObj;
//                boolean watermarkFound = false;
//                boolean subEpochFound = false;
//                long totalQueueTime = 0;
//                int recordCount = 0;
//                if(!subEpochFound) {
//                    resetMetrics();
//                }
//
//                setDataflow();
//                while (!watermarkFound) {
//                    readObj = m_currentQueue.take();
//                    if(recordCount == 0) {
//                        m_startEpoch = System.currentTimeMillis();
//                        JarvisLogger.debug("[CustomOperator.run] Thread ID is: " +
//                                Thread.currentThread().getId());
//                    }
//
//                    if (readObj != null) {
//                        if(readObj.isWaterMark() || readObj.isSubEpochMarker()) {
//                            if(readObj.isSubEpochMarker()) {
//                                subEpochFound = true;
//                                m_subEpochComplete.set(true);
//                            }
//
//                            watermarkFound = true;
//                            m_subject.onComplete();
//                        } else {
//                            totalQueueTime = readObj.getQueueTime();
//                            if(randGen.nextDouble() < m_reductionRatio) {
//                                m_subject.onNext(readObj);
//                                recordCount++;
//                            }
//
//                            m_queueingTimes.add(totalQueueTime);
////                            if (m_maxQueueTime < totalQueueTime) {
////                                m_maxQueueTime = totalQueueTime;
////                            }
//                        }
//                    }
//                }
//
//                m_avgProcessingTime = (float) m_totalProcessingTime / (float) recordCount;
////                JarvisLogger.debug("[CustomOperator.run] Records sent from map op " + m_opId + " = "
////                        + recordCount + " and written to exit queue: " + m_numOutRecords[0] +
////                        ", max queue time: " + m_maxQueueTime + ", total processing time: " + m_totalProcessingTime);
//                m_epochCount = m_epochCount + (subEpochFound ? 0 : 1);
//                if(m_epochCount % 20 == 0) {
//                    printAllQueueingTimes();
//                }
//
//                JarvisLogger.debug("[CustomOperator.run] Total processing time: " + m_totalProcessingTime +
//                        ", avg processing time: " + m_avgProcessingTime + ", dataflow ubild dur: " + m_dataflowBuildDur +
//                        ", num records=" + m_numOutRecords[0]);
//            } catch (Exception ex) {
//                JarvisLogger.debug("[CustomOperator.run] Exception waiting: " + ex.toString());
//                ex.printStackTrace();
//            }
//        }
//    }
//
//    public void printAllQueueingTimes() {
//        JarvisLogger.debug("[CustomOperator.run] Printing queueing times");
//        m_queueTimeAnalysisEpoch++;
////        BufferedWriter fileWrite;
//        try {
////            fileWrite = new BufferedWriter(new FileWriter("intermed_file_queueing_times" + m_queueTimeAnalysisEpoch));
////            for (long queueingTime :
////                    m_queueingTimes) {
////               // JarvisLogger.debug(Long.toString(queueingTime));
////                fileWrite.write(queueingTime + " \n");
////            }
//
//            JarvisLogger.debug("[CustomOperator.run] Done printing queueing times");
//            m_queueingTimes.clear();
////            fileWrite.close();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[CustomOperator.printAllQueueingTimes] Failed to print queues: " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//}

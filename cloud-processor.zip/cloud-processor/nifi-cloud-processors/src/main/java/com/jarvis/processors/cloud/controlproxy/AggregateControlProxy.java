package com.jarvis.processors.cloud.controlproxy;

import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.operators.*;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Class to do the final aggregation for data items in an epoch, after all the replicated queries finish processing the
// epoch
public class AggregateControlProxy implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Output m_networkOutput;
    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    Object watermarkLock = new Object();
    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    private AtomicInteger m_totalInputRecords;

    private Object m_replicatedQuerySyncLock;

    ICustomGlobalAggOp m_customAggOp;
    private static final int m_numQueues = Config.QUERY_REPLICATION_FACTOR;
    public AggregateControlProxy(int queueId, ICustomGlobalAggOp globalAgg) {
        m_queueId = queueId;
        m_networkOutputStream = new ByteArrayOutputStream();
        m_networkOutput = new Output(m_networkOutputStream);
        m_startEpochTimer.set(System.currentTimeMillis());
        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
        m_replicatedQuerySyncLock = new Object();
        m_customAggOp = globalAgg;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochTimeInMs.get();
    }
    final CyclicBarrier m_readQueueBarrier = new CyclicBarrier(Config.QUERY_REPLICATION_FACTOR);

    // Adds records into the downstream CustomHashGlobalAggOperator.
    // put, putWaterMark have to run on a single thread
    public void put(IData item) {
        try {
            m_customAggOp.onNext(item);
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    private long m_watermarksReceived = 0;

    private AtomicLong m_startTimer = new AtomicLong(0);
    private AtomicBoolean m_watermarkSeenOnce = new AtomicBoolean(false);

    // This method is required for implementing interface but is dummy for the control proxy
    // No downstream operator thread reads continuously from the queue. Instead, incoming data items
    // are directly added to CustomHashGlobalAggOperator
    public IData take() {
        // No-op
        throw new UnsupportedOperationException();
    }

    // Adds watermark to denote end of epoch for CustomHashGlobalAggOperator
    public void putWaterMark(IData watermark) {
        try {
            m_startTimer.compareAndSet(0, System.currentTimeMillis());

            // Synchronization barrier when encountering watermark
            try {
                m_readQueueBarrier.await();
            } catch (InterruptedException ex) {
                JarvisLogger.info("[AggregateControlProxy.putWaterMark] ERROR Interrupted while waiting on barrier " +
                        ex.toString());
                throw ex;
            } catch (BrokenBarrierException ex) {
                JarvisLogger.info("[FirstControlProxy.putWaterMark] ERROR Broken barrier " + ex.toString());
                throw ex;
            }

            // Watermarks from all the replicated queries have been received
            synchronized (m_replicatedQuerySyncLock) {
                m_watermarkSeenOnce.set(true);
                m_watermarksReceived++;
                JarvisLogger.info("[AggregateControlProxy.putWaterMark] Starting put watermark with count: " +
                         m_watermarksReceived);
                if(m_watermarksReceived == 1) {

                    m_customAggOp.onComplete();
                    JarvisLogger.info("[AggregateContorlProxy.putWaterMark] watermarks received: " +
                            m_watermarksReceived);
                    long elapsedTime = System.currentTimeMillis() - m_startTimer.getAndSet(0);
                    JarvisLogger.info("[AggregateContorlProxy.putWaterMark] elapsed time at barrier: " +
                            elapsedTime);
                }

                if(m_watermarksReceived == Config.QUERY_REPLICATION_FACTOR) {
                    m_watermarksReceived = 0;
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public int size() {
        return queue.size();
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }
}

package com.jarvis.processors.cloud;

import com.jarvis.processors.cloud.data.*;

// Utility class to generate watermark based on data type
public class Utils {

    // Generates watermark based on the input data type
    public static IData getWatermarkMarker(String dataType) {
        IData watermark = null;
        switch (dataType) {
            case "PingMeshKryo":
                PingMeshKryo watermarkEntity = new PingMeshKryo();
                watermark = new PingMeshKryoWithTime();
                watermark.setEntity(watermarkEntity);
                break;
            case "WordCountEntity":
                watermark = new WordCountEntity();
                break;
            case "JoinResult":
                watermark = new JoinResult();
                break;
            case "SrcClusterStatsKryo":
                watermark = new SrcClusterStatsKryo();
                break;
            case "LogAnalyticUtilInfo":
                watermark = new LogAnalyticUtilInfo();
                break;
            default:
                throw new UnsupportedOperationException("No data type for generating watermark/subepoch marker for " +
                        dataType);
        }

        watermark.setWatermarkMarker();
        return watermark;
    }
}

//package com.jarvis.processors.cloud.old;
//import com.esotericsoftware.kryo.Kryo;
//import com.esotericsoftware.kryo.io.Input;
//import com.esotericsoftware.kryo.io.Output;
//import com.jarvis.processors.cloud.CloudUploader;
//import com.jarvis.processors.cloud.JarvisLogger;
//import org.apache.nifi.processor.Relationship;
//
//import java.io.*;
//import java.util.concurrent.atomic.AtomicInteger;
//import java.util.concurrent.atomic.AtomicLong;
//
//public class OutputQueueWrapper implements IQueue {
//    ByteArrayOutputStream m_outputStream;
//    Output m_output;
//    Kryo m_kryo;
//    AtomicInteger m_size;
//    CloudUploader m_cloudUploader;
//
//    public volatile double m_prevWindowDataSizeSentToEdge = 0;
//    double m_currentWindowDataSizeSentToEdge = 0;
//    private boolean m_watermarkObserved;
//    private Object m_waterMarkInExitLock;
//    private Integer m_recentWaterMarkSeqNum = 0;
//    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
//
//    public OutputQueueWrapper(Kryo kryo, Relationship MY_RELATIONSHIP) {
////        m_kryo = new Kryo();
//        m_kryo = kryo;
//        m_outputStream = new ByteArrayOutputStream();
//        m_output = new Output(m_outputStream);
//        m_cloudUploader = new CloudUploader(MY_RELATIONSHIP);
//        m_waterMarkInExitLock = new Object();
//        m_watermarkObserved = false;
//    }
//
//    public void initializeKryo(Object ...classObj) {
//        for (Object classObjInst :
//                classObj) {
//            m_kryo.register(classObjInst.getClass());
//        }
//    }
//
//    public double getRecentPayloadSizeOnEdge() {
//        return m_prevWindowDataSizeSentToEdge;
//    }
//
//    public void put(IData item) {
//        try {
//            item.writeSelfToKryo(m_kryo, m_output);
//            m_currentWindowDataSizeSentToEdge += item.getPayloadInBytes();
//            if(item.isSubEpochMarker()) {
//                JarvisLogger.debug("[OutputQueueWrapper.put] subepoch marker inserted");
//            }
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
//        }
//    }
//
//    public void putWaterMark(IData item) {
//        try {
//            item.writeSelfToKryo(m_kryo, m_output);
//            byte[] epochContent = getByteArrayOutputStreamContent();
//            this.reset();
//            new Thread(() -> m_cloudUploader.sendToCloud(-1, epochContent)).start();
//            m_prevWindowDataSizeSentToEdge = m_currentWindowDataSizeSentToEdge;
//            m_currentWindowDataSizeSentToEdge = 0;
//            m_startIdleTimer.set(System.currentTimeMillis());
//            JarvisLogger.debug("[ExitQueue.putWaterMark] Size of recent window in output queue is " +
//                    m_prevWindowDataSizeSentToEdge + " , seq num is " + item.getSeqNum());
//            synchronized (m_waterMarkInExitLock) {
//                m_watermarkObserved = true;
//                m_recentWaterMarkSeqNum = item.getSeqNum();
//                m_waterMarkInExitLock.notify();
//            }
//
////            readEpochData(epochContent);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
//        }
//    }
//
//    private void readEpochData(byte[] epochContent) {
//        Input input = new Input(epochContent);
////        BufferedWriter writer = new BufferedWriter(
////                new FileWriter("intermed_file_test"));
//        SrcClusterStatsKryo srcClusterStatsKryo = m_kryo.readObject(input, SrcClusterStatsKryo.class);
//        System.out.println(srcClusterStatsKryo.toString());
//        while(srcClusterStatsKryo != null) {
//            srcClusterStatsKryo = m_kryo.readObject(input, SrcClusterStatsKryo.class);
//            System.out.println(srcClusterStatsKryo.toString());
//        }
//
//        input.close();
//    }
//
//    public int getRecentSeqNum() {
//        int seqNum;
//        synchronized (m_waterMarkInExitLock) {
//            seqNum = m_recentWaterMarkSeqNum;
//        }
//
//        return seqNum;
//    }
//
//    public byte[] getByteArrayOutputStreamContent() {
//        try {
//            m_output.flush();
//            m_outputStream.flush();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG]Error while clearing output queue wrapper: " + ex.toString());
//        }
//
//        return m_outputStream.toByteArray();
//    }
//
//    public void reset() {
//        m_outputStream.reset();
//        m_output.reset();
//    }
//
//    public void clear() {
//        try {
//            m_outputStream.flush();
//            m_output.flush();
//            m_outputStream.reset();
//            m_output.reset();
//            m_size.set(0);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
//        }
//    }
//
//    public void unseeWatermark() {
//        synchronized (m_waterMarkInExitLock) {
//            m_watermarkObserved = false;
//        }
//    }
//
//    public void waitForWatermarkWithSeqNum(int seqNum) {
//        try {
//            synchronized (m_waterMarkInExitLock) {
//                while (!(m_watermarkObserved &&
//                        ((seqNum==-1) || (m_recentWaterMarkSeqNum >= seqNum)))) {
//                    m_waterMarkInExitLock.wait();
//                }
//            }
//
//            JarvisLogger.debug("[OutputQueueWrapper.waitForWatermarkWithSeqNum] Seq num is: " + seqNum);
//        } catch (Exception ex) {
//            JarvisLogger.debug("Unhandled exception when waiting for exit watermark: " + ex.toString());
//        }
//    }
//
//    public long getIdleTimerVal() {
//        long idleTimeVal = m_startIdleTimer.getAndSet(Long.MAX_VALUE);
//        return idleTimeVal;
//    }
//
//    public int waitForNewEpochAndGetSeqNum() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public long getRecentIdleTime() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public int getRecentRecordsDrainedSize() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public long getRecentEpochTime() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void enableSendingToEdge() {
//        // No op
////        throw new UnsupportedOperationException();
//    }
//
//    public void resetIdleTimer() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void setProbSendingToEdge(double probSendingToEdge) {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void enableSendingToEdgeFlagOnly() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void disableSendingToEdge() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public int getRecentRecordsDiscardedSize() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void tryDrainTillWatermark() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void setCurrRuntimeState(RuntimeState state) {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void enableFullDrainMode() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public long getRecentNewEpochStartTime() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public IData take() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//}

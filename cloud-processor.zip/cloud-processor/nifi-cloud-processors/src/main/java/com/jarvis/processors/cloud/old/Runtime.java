package com.jarvis.processors.cloud.old;
//
//
//import com.jarvis.processors.cloud.CongestionState;
//import com.jarvis.processors.cloud.JarvisLogger;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.concurrent.atomic.AtomicLong;
//
//public class Runtime implements Runnable {
public class Runtime {
//    public static final int SIZE_OF_INT = 4;
//    public static final int SIZE_OF_FLOAT = 4;
//
//    public static final double IDLE_TIME_DELTA_RATIO_THRESHOLD = 0.25;
//    public static final double IDLE_TO_EPOCH_TIME_RATIO_THRESHOLD = 0.2;
//    public static final double DRAINED_RECORDS_FRACTION_THRESHOLD = 0.1;
//    IQueue[] m_controlProxies;
//    //    OutputQueueWrapper m_outputControlProxy;
//    List<Integer> m_subQueries;
//    int m_prevClearSubQueryIdx;
//    int m_currentFullOpsSubQueryIdx;
//    long m_prevIdleTimes = 0;
//    long m_currIdleTimes = 0;
//    Integer[] cpDrainedDataSizes;
//    Integer[] cpEdgeDataSizes;
//    Integer[] cpDiscardedDataSizes;
//    int queueId;
//    int m_leftSubquery = 0, m_rightSubquery = 0;
//    //    private boolean calibrationDone = false;
//    RuntimeAction m_prevRuntimeAction;
//    private RuntimeState m_currentRuntimeState;
//    RuntimeState m_prevRuntimeState;
//    boolean finalCpIsSubquery = false;
//
//    double m_probUpdateDelta = 0.1;
//    OperatorProbRange[] m_opProbRanges;
//    CongestionState prevCongestionState;
//
//    private int m_finalQueueIdx;
//
//    private Object m_drainFinishedLock = new Object();
//    private Object m_startDrainingInstructLock = new Object();
//    private AtomicBoolean m_drainAllQueues = new AtomicBoolean(false);
//    private AtomicBoolean m_allQueuesDrained = new AtomicBoolean(false);
//    //    private AtomicLong m_newEpochStartTimeMs = new AtomicLong(0);
////    private AtomicLong m_prevNewEpochStartTimeMs = new AtomicLong(0);
//    private AtomicLong m_lastEpochEndTimeMs = new AtomicLong(Long.MAX_VALUE);
//
//    public Runtime() {
//        m_prevRuntimeAction = RuntimeAction.NO_ACTION;
//        prevCongestionState = CongestionState.STABLE;
//        m_currentRuntimeState = RuntimeState.STABLE;
//        m_prevClearSubQueryIdx = -1;
//
//    }
//
////    public void calibrate() {
////        for (int i = 0; i < m_internalControlProxies.length; i++) {
////            m_internalControlProxies[i].blockDraining();
////        }
////
////        calibrationDone = true;
////    }
//
////    public void unCalibrate() {
////        for (int i = 0; i < m_internalControlProxies.length; i++) {
////            m_internalControlProxies[i].unblockDraining();
////        }
////    }
//
//    public void setCps(OutputQueueWrapper outputQueue, ControllerQueue...controlProxies) {
//        List<IQueue> controlProxiesList = new ArrayList<>();
//        for(ControllerQueue controlProxy : controlProxies) {
//            controlProxiesList.add(controlProxy);
//        }
//
//        controlProxiesList.add(outputQueue);
//
//        int numControlProxies = controlProxiesList.size();
//        m_finalQueueIdx=numControlProxies-1;
//        cpDrainedDataSizes = new Integer[numControlProxies];
//        cpEdgeDataSizes = new Integer[numControlProxies];
//        cpDiscardedDataSizes = new Integer[numControlProxies];
//        m_controlProxies = new IQueue[numControlProxies];
//        m_controlProxies = controlProxiesList.toArray(m_controlProxies);
////        m_outputControlProxy = outputQueue;
//        m_subQueries = new ArrayList<>();
//        m_opProbRanges = new OperatorProbRange[numControlProxies-1];
//        for (int i = 0; i < numControlProxies-1; i++) {
//            m_opProbRanges[i] = new OperatorProbRange();
//        }
//    }
//
//
//    public void run() {
//        int newEpochNum = -1;
//        CongestionState currentCongestionState;
//        boolean configChanged = false;
//        while(true) {
//            if(m_currentRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                drainAllQueuesIfNeeded();
//            }
//
//            m_controlProxies[m_finalQueueIdx].waitForWatermarkWithSeqNum(newEpochNum++);
//            currentCongestionState = observeControllerQueues();
//            switch (currentCongestionState) {
//                case CONGESTED:
//                    // Need to reduce compute load
//                    JarvisLogger.debug("[Runtime.run] Congested state");
//                    configChanged = false;
//                    if (m_currentRuntimeState == RuntimeState.STABLE) {
//                        calibrateQuery(CongestionState.CONGESTED);
//                        m_currentRuntimeState = RuntimeState.ADAPT_NOPROBING;
//                    }
//
//                    if((m_prevRuntimeAction==RuntimeAction.OP_INC || m_prevRuntimeAction==RuntimeAction.OP_DEC ||
//                            prevCongestionState==CongestionState.STABLE) && reduceOperatorCongestion()){
//                        m_prevRuntimeAction = RuntimeAction.OP_DEC;
//                        configChanged = true;
//                    } else {
//                        if(!(m_prevRuntimeAction==RuntimeAction.DATA_INC || m_prevRuntimeAction==RuntimeAction.DATA_DEC)
//                                && m_currentFullOpsSubQueryIdx > 0) {
//                            m_currentFullOpsSubQueryIdx--;
//                        }
//
//                        if(reduceDataCongestion()) {
//                            m_prevRuntimeAction=RuntimeAction.DATA_DEC;
//                            configChanged=true;
//                        }
//                    }
//
//                    if(configChanged) {
//                        if(m_prevRuntimeState == RuntimeState.STABLE) {
////                            newEpochNum++;
//                            m_currentRuntimeState = RuntimeState.ADAPT_NOPROBING;
////                            newEpochNum = m_controlProxies[0].waitForNewEpochAndGetSeqNum();
//                            newEpochNum = m_controlProxies[0].waitForNewEpochAndGetSeqNum();
//                        }
//                    } else {
//                        m_prevRuntimeAction = RuntimeAction.NO_ACTION;
//                        m_currentRuntimeState = RuntimeState.STABLE;
//                        // Set runtime current state for all the control proxies
//                        for(int i = 0; i < m_finalQueueIdx; i++) {
//                            m_controlProxies[i].setCurrRuntimeState(m_currentRuntimeState);
//                        }
//                    }
//
//                    break;
//                case CLEAR:
//                    // Need to increase compute load
//                    JarvisLogger.debug("[Runtime.run] Clear state");
//                    m_prevClearSubQueryIdx = m_currentFullOpsSubQueryIdx;
//                    configChanged = false;
//                    if (m_currentRuntimeState == RuntimeState.STABLE) {
//                        JarvisLogger.debug("[Runtime.run] Clear state calibrating : " + m_currentFullOpsSubQueryIdx);
//                        calibrateQuery(CongestionState.CLEAR);
//                        m_currentRuntimeState = RuntimeState.ADAPT_NOPROBING;
////                        configChanged = (fullOpsSubQueryIdx != m_currentFullOpsSubQueryIdx) ? true : false;
//                        // TODO: Figure out how to handle scenario where resetting load after CLEAR state would cause congestion,
//                        // TODO: because here we optimized for case where max settings at CLEAR is good. So we will incur cost
//                        // TODO: of extra epochs when resetting load is bad in CLEAR state and causes congestion
//                    }
//
//                    if ((m_prevRuntimeAction == RuntimeAction.OP_INC || m_prevRuntimeAction == RuntimeAction.OP_DEC ||
//                            prevCongestionState == CongestionState.STABLE) && increaseOperatorLoad()) {
//                        m_prevRuntimeAction = RuntimeAction.OP_INC;
//                        configChanged = true;
//                    } else if (increaseDataLoad()) {
//                        m_prevRuntimeAction = RuntimeAction.DATA_INC;
//                        configChanged = true;
//                    }
//
//                    if (!configChanged) {
//                        m_prevIdleTimes = m_currIdleTimes;
//                        m_prevRuntimeAction = RuntimeAction.NO_ACTION;
//                        m_currentRuntimeState = RuntimeState.STABLE;
//
//                        // Set runtime current state for all the control proxies
//                        for(int i = 0; i < m_finalQueueIdx; i++) {
//                            m_controlProxies[i].setCurrRuntimeState(m_currentRuntimeState);
//                        }
//                    } else {
//                        if(m_prevRuntimeState == RuntimeState.STABLE) {
//                            m_currentRuntimeState = RuntimeState.ADAPT_NOPROBING;
//                            newEpochNum = m_controlProxies[0].waitForNewEpochAndGetSeqNum();
//                        }
//                    }
//
//                    break;
//                case STABLE:
//                    JarvisLogger.debug("[Runtime.run] Stable state");
//                    m_prevRuntimeAction = RuntimeAction.NO_ACTION;
//                    m_currentRuntimeState = RuntimeState.STABLE;
//                    m_prevIdleTimes = m_currIdleTimes;
//                    // Set runtime current state for all the control proxies
//                    for(int i = 0; i < m_finalQueueIdx; i++) {
//                        m_controlProxies[i].setCurrRuntimeState(m_currentRuntimeState);
//                    }
////                    m_prevNewEpochStartTimeMs.set(0);
////                    m_newEpochStartTimeMs.set(0);
////                    newEpochNum++;
////                  //  newEpochNum = -1;
//
//                    break;
//            }
//
//            if(m_currentRuntimeState == RuntimeState.ADAPT_NOPROBING ||
//                    m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                synchronized (m_drainFinishedLock) {
//                    m_allQueuesDrained.set(true);
//                    m_drainFinishedLock.notify();
//                }
//            }
//
//            prevCongestionState = currentCongestionState;
//            m_prevRuntimeState = m_currentRuntimeState;
//            m_controlProxies[m_finalQueueIdx].unseeWatermark();
//
//            JarvisLogger.debug("[Runtime.run] Finished updating control knobs, allowing CP0 to continue with next epoch");
//        }
//    }
//
//    public void waitUntilAllQueuesDrained() {
//        try {
//            if(m_currentRuntimeState == RuntimeState.ADAPT_NOPROBING) {
////                m_prevNewEpochStartTimeMs.set(m_newEpochStartTimeMs.get());
////                m_newEpochStartTimeMs.set(System.currentTimeMillis());
//                m_allQueuesDrained.set(false);
//                JarvisLogger.debug("CP0 [Runtime.waitUntilAllQueuesDrained] First CP going to wait for draining by runtime, m_drainAllQueues: " +
//                        m_drainAllQueues.get() + ", m_allQueuesDrained: " + m_allQueuesDrained);
//                synchronized (m_startDrainingInstructLock) {
//                    m_drainAllQueues.set(true);
//                    m_startDrainingInstructLock.notify();
//                }
//
//                synchronized (m_drainFinishedLock) {
//                    while (!m_allQueuesDrained.get()) {
//                        m_drainFinishedLock.wait();
//                    }
//                }
//
////                m_allQueuesDrained.set(false);
//                JarvisLogger.debug("CP0 [Runtime.waitUntilAllQueuesDrained] First CP released to accept records in current epoch");
//            }
//        } catch (Exception ex) {
//            JarvisLogger.debug("[Runtime.waitUntilAllQueuesDrained] Wait until all queues " +
//                    "drained failed in runtime " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    public void drainAllQueuesIfNeeded() {
//        try {
//            if(m_currentRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                JarvisLogger.debug("Runtime thread [Runtime.drainAllQueuesIfNeeded] m_drainAllQueues: " + m_drainAllQueues.get());
//                synchronized (m_startDrainingInstructLock) {
//                    while(!m_drainAllQueues.get()) {
//                        m_startDrainingInstructLock.wait();
//                    }
//                }
//
//                JarvisLogger.debug("Runtime thread [Runtime.drainAllQueuesIfNeeded] Going to drain queues now");
//                // Drain all queues
//                for(int i = 0; i < m_controlProxies.length-1; i++) {
//                    m_controlProxies[i].enableFullDrainMode();
//                    m_controlProxies[i].tryDrainTillWatermark();
//                }
//
//                // Set runtime current state for all the control proxies
//                for(int i = 1; i < m_finalQueueIdx; i++) {
//                    m_controlProxies[i].setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
//                    m_controlProxies[i].resetIdleTimer();
//                }
//
//                m_drainAllQueues.set(false);
//                JarvisLogger.debug("[Runtime.drainAllQueuesIfNeeded] Drained all queues and going to update control knobs now");
//            }
//        } catch (Exception ex) {
//            JarvisLogger.debug("[Runtime.drainAllQueuesIfNeeded] drain all queues if needed failed: " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        //        // Wait for final queue to see epoch WM
//        //        m_controlProxies[m_finalQueueIdx].waitForWatermarkWithSeqNum(m_recentSeqNum.get());
//
//        //                    m_startIdleTimer.set(Long.MAX_VALUE);
//
//        //        synchronized (m_newEpochLock) {
//        //            m_drainAllQueues.set(true);
//        //            m_newEpochLock.notify();
//        //        }
//    }
//
//    public CongestionState observeControllerQueues() {
//        CongestionState state = CongestionState.STABLE;
//        double congestedRecordCount = 0;
//        long totalIdleTime = 0;
//        double avgIdleTimeRatio = 0;
//        int id;
//
//        // Only iterate over internal control proxies
//        // Clear durations
//        long currIdleTime = 0, epochTime = 0;
//        double idleTimeRatio = 0;
//        if(m_currentRuntimeState == RuntimeState.ADAPT_NOPROBING) {
////            currIdleTime = m_newEpochStartTimeMs.get() - m_lastEpochEndTimeMs.getAndSet(Long.MAX_VALUE);
////            epochTime = m_newEpochStartTimeMs.get() - m_prevNewEpochStartTimeMs.get();
//            currIdleTime = m_controlProxies[0].getRecentNewEpochStartTime() -
//                    m_controlProxies[m_finalQueueIdx].getIdleTimerVal();
//            epochTime = m_controlProxies[0].getRecentEpochTime();
//            idleTimeRatio = (double) currIdleTime / (double) epochTime;
//        }
//
//        // Congestion
//        for (id = 0; id < m_finalQueueIdx; id++) {
//            IQueue queue = m_controlProxies[id];
//
//            // Detect clear state
//            if(m_currentRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//                currIdleTime = queue.getRecentIdleTime();
//                epochTime = queue.getRecentEpochTime();
//                idleTimeRatio = (double) currIdleTime/(double) epochTime;
//            }
//
//            // Detect drained state
//            cpDrainedDataSizes[id] = queue.getRecentRecordsDrainedSize();
//            cpEdgeDataSizes[id] = (int)queue.getRecentPayloadSizeOnEdge();
//            cpDiscardedDataSizes[id] = queue.getRecentRecordsDiscardedSize();
//
//            double drainedRecordsSizeRatio =
//                    (double) cpDrainedDataSizes[id]/(double) (cpDrainedDataSizes[id] + cpEdgeDataSizes[id]);
//
//            JarvisLogger.debug("[Runtime.observeControllerQueues] Records drained size: " + cpDrainedDataSizes[id] +
//                    " and idle time: " + currIdleTime);
//            if(cpDrainedDataSizes[id] > 0) {
//                // Detect congested state
//                // TODO: Do we need threshold?
////                congestedRecordCount += recentRecordsDrained;
//                congestedRecordCount += drainedRecordsSizeRatio;
//            } else if (m_currentRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//                totalIdleTime += currIdleTime;
//                avgIdleTimeRatio += idleTimeRatio;
//            }
//        }
//
//        m_currIdleTimes = m_currentRuntimeState==RuntimeState.ADAPT_NOPROBING ? currIdleTime : totalIdleTime;
//        avgIdleTimeRatio = m_currentRuntimeState==RuntimeState.ADAPT_NOPROBING ? idleTimeRatio : avgIdleTimeRatio/(double) (id+1);
//        double avgRecordsDrainedSize = (double) congestedRecordCount/(double) (id+1);
//
//        JarvisLogger.debug("[Runtime.observeControllerQueues] Final records drained metric: " + avgRecordsDrainedSize +
//                " and idle time metric: " + avgIdleTimeRatio + ", current idle time: " + m_currIdleTimes);
//
//        if(avgRecordsDrainedSize > DRAINED_RECORDS_FRACTION_THRESHOLD) {
//            state = CongestionState.CONGESTED;
//            m_prevIdleTimes = 0; // Idle time is reset
//        } else if(congestedRecordCount == 0 && avgIdleTimeRatio > IDLE_TO_EPOCH_TIME_RATIO_THRESHOLD &&
//                (m_currIdleTimes-m_prevIdleTimes) > IDLE_TIME_DELTA_RATIO_THRESHOLD * m_prevIdleTimes){
//            // Check first condition as well because previous idle time can
//            // be negative since its set to current idle time:
//            state = CongestionState.CLEAR;
//            // TODO: how to ensure once you enter CLEAR and before RuntimeState goes back to STABLE, we need to stay in CLEAR
////            m_prevIdleTimes = totalIdleTime;
//        }
//
//        return state;
//    }
//
//    public void calibrateQuery(CongestionState congestionState) {
//        double origDataSizeEdge =  cpEdgeDataSizes[0];
//        int opOutputSize = 0;
//        double prevDataRedRatio = 1;
//
//        m_subQueries.clear();
//        m_subQueries.add(0);
//        finalCpIsSubquery = false;
//        for (int i = 1; i < m_finalQueueIdx; i++) {
//            opOutputSize = cpEdgeDataSizes[i] + cpDrainedDataSizes[i] + cpDiscardedDataSizes[i];
//            double currDataRedRatio = (double) opOutputSize/origDataSizeEdge;
//            JarvisLogger.debug("[Runtime.calibrateQuery] O/P size: " + opOutputSize +
//                    " orig size: " + origDataSizeEdge + ", discarded size: " + cpDiscardedDataSizes[i] + ", " +
//                    "edge data size: " + cpEdgeDataSizes[i]);
//            if(currDataRedRatio < prevDataRedRatio) {
//                m_subQueries.add(i);
//                prevDataRedRatio = currDataRedRatio;
//            }
//        }
//
//        double outputDataSize = m_controlProxies[m_finalQueueIdx].getRecentPayloadSizeOnEdge();
//        double finalDataRedRatio = outputDataSize/origDataSizeEdge;
//        JarvisLogger.debug("[Runtime.calibrateQuery] Final O/P size: " + outputDataSize);
//        if(finalDataRedRatio < prevDataRedRatio) {
////            m_currentSubQueryIdx = -1;
//            m_subQueries.add(m_finalQueueIdx);
//            finalCpIsSubquery = true;
//        }
////        else {
//
////        }
//
//        resetSearchIndexesFull(congestionState);
//        JarvisLogger.debug("[Runtime.calibrateQuery] current subquery index is " +
//                m_currentFullOpsSubQueryIdx);
//    }
//
//    public void resetSearchIndexesPartial(CongestionState congestionState) {
//
//    }
//
//    public void resetSearchIndexesFull(CongestionState congestionState) {
//        // Reset indexes for operator binary search
//        // Start with maximum subquery
//        if(congestionState == CongestionState.CONGESTED) {
//            m_leftSubquery = 0;
//        } else if(congestionState == CongestionState.CLEAR) {
//            m_rightSubquery = m_subQueries.size()-1;
//        }
//    }
//
//    public void alwaysResetAllSearchIndexes() {
//        // Reset indexes for operator binary search
//        // Start with maximum subquery
//        m_currentFullOpsSubQueryIdx = m_subQueries.size() - 1;
//        m_rightSubquery = m_subQueries.size() - 1;
//        m_leftSubquery = 0;
//        for(int i = 0; i < m_opProbRanges.length; i++) {
//            m_opProbRanges[i].reset();
//        }
//
//        for(int i = 0; i < m_finalQueueIdx; i++) {
//            m_controlProxies[i].enableSendingToEdge();
//        }
//    }
//
//    public boolean reduceOperatorCongestion() {
//        // Operator partitioning binary search
//        boolean operatorSearchResult = false;
////        if(m_currentSubQueryIdx == -1) {
////            m_currentSubQueryIdx = m_subQueries.size() - 1;
////            operatorSearchResult = true;
////        } else {
//        m_rightSubquery = m_currentFullOpsSubQueryIdx - 1;
//        if (m_rightSubquery >= m_leftSubquery) {
//            enableProxyCompletely();
//            m_currentFullOpsSubQueryIdx = (int) Math.floor((m_rightSubquery + m_leftSubquery) / 2);
//            operatorSearchResult = true;
//            disableProxyCompletely();
//
//        }
////        }
//
//        JarvisLogger.debug("[Runtime.reduceOperatorCongestion] current subquery idx is: " + m_currentFullOpsSubQueryIdx +
//                " , subquery size: "+m_subQueries.size());
//        return operatorSearchResult;
//    }
//
//    public boolean reduceDataCongestion() {
//        boolean probUpdated = false;
//        int cpIndexToUpdate = m_currentFullOpsSubQueryIdx; // This was previously m_currentSubQueryIdx-1
//        int queueIdx = cpIndexToUpdate >= 0 ? m_subQueries.get(cpIndexToUpdate) : m_finalQueueIdx;
//        if(queueIdx != m_finalQueueIdx) {
//            double probCurrent = m_opProbRanges[queueIdx].getProbCurrent();
//            if(probCurrent > 0) {
//                double probHigh = probCurrent - m_probUpdateDelta;
//                m_opProbRanges[queueIdx].setProbHigh(probHigh);
//                double probLow = m_opProbRanges[queueIdx].getProbLow();
//                if (probLow <= probHigh) {
//                    probCurrent = (double) (probHigh + probLow) / (double) 2;
//                    m_opProbRanges[queueIdx].setProbCurrent(probCurrent);
//                    m_controlProxies[queueIdx].setProbSendingToEdge(probCurrent);
//                    probUpdated = true;
//                }
//
//                //            disableProxyCompletely(m_currentFullOpsSubQueryIdx +1);
//                JarvisLogger.debug("[Runtime.reduceDataCongestion] current subquery idx updated is: " + cpIndexToUpdate +
//                        " , subquery size: "+m_subQueries.size() + " , probCurrent is: " + probCurrent + ", probHigh is: " + probHigh +
//                        " , probLow is: " + probLow);
//            } else {
//                JarvisLogger.debug("[Runtime.reduceDataCongestion] Prob current is 0, no scope to further reduce data congestion");
//            }
//        } else {
//            JarvisLogger.debug("[Runtime.reduceDataCongestion] current subquery idx updated is: " + cpIndexToUpdate +
//                    " , subquery size: " + m_subQueries.size());
//        }
//
//        return probUpdated;
//    }
//
//    public boolean increaseDataLoad() {
//        boolean probUpdated = false;
//        int queueIdx = m_subQueries.get(m_currentFullOpsSubQueryIdx);
//        if(queueIdx != m_finalQueueIdx) {
//            double probCurrent = m_opProbRanges[queueIdx].getProbCurrent();
//            if(probCurrent < 1) {
//                m_controlProxies[queueIdx].enableSendingToEdgeFlagOnly();
//                double probLow = probCurrent + m_probUpdateDelta;
//                m_opProbRanges[queueIdx].setProbLow(probLow);
//                double probHigh = m_opProbRanges[queueIdx].getProbHigh();
//                if (probLow <= probHigh) {
//                    probCurrent = (double) (probHigh + probLow) / (double) 2;
//                    m_opProbRanges[queueIdx].setProbCurrent(probCurrent);
//                    m_controlProxies[queueIdx].setProbSendingToEdge(probCurrent);
//                    probUpdated = true;
//                }
//
//                disableProxyCompletely(m_currentFullOpsSubQueryIdx + 1);
//                JarvisLogger.debug("[Runtime.increaseDataLoad] current subquery idx updated is: " + m_currentFullOpsSubQueryIdx +
//                        " , subquery size: " + m_subQueries.size() + " , probCurrent is: " + probCurrent + ", probHigh is: " + probHigh +
//                        " , probLow is: " + probLow);
//            } else {
//                JarvisLogger.debug("[Runtime.increaseDataLoad] Prob current is 1, no scope for increasing data load");
//            }
//        } else {
//            JarvisLogger.debug("[Runtime.increaseDataLoad] current subquery idx updated is: " + m_currentFullOpsSubQueryIdx +
//                    " , subquery size: " + m_subQueries.size());
//        }
//
//        return probUpdated;
//    }
//
//    private void enableProxyCompletely() {
//        int currIdx = m_subQueries.get(m_currentFullOpsSubQueryIdx);
//        if(currIdx!=m_finalQueueIdx) {
//            m_controlProxies[currIdx].enableSendingToEdge();
//            m_opProbRanges[currIdx].setProbCurrent(1);
//            m_opProbRanges[currIdx].setProbHigh(1);
//            m_opProbRanges[currIdx].setProbLow(0);
//        }
//    }
//
//    private void disableProxyCompletely() {
//        disableProxyCompletely(m_currentFullOpsSubQueryIdx);
//    }
//
//    private void disableProxyCompletely(int idx) {
//        int currIdx = idx < m_subQueries.size() ? m_subQueries.get(idx) : m_finalQueueIdx;
//        if(currIdx!=m_finalQueueIdx) {
//            m_controlProxies[currIdx].disableSendingToEdge();
//            m_opProbRanges[currIdx].setProbCurrent(0);
//            m_opProbRanges[currIdx].setProbHigh(1);
//            m_opProbRanges[currIdx].setProbLow(0);
//        }
//    }
//
//    public RuntimeState getCurrRuntimeState() {
//        return m_currentRuntimeState;
//    }
//
//    public boolean increaseOperatorLoad() {
//        boolean operatorSearchResult = false;
////        enableProxyCompletely();
//        m_leftSubquery = m_currentFullOpsSubQueryIdx + 1;
////            if (finalCpIsSubquery && m_currentSubQueryIdx == m_subQueries.size() - 1) {
////                m_currentSubQueryIdx = -1;
////                operatorSearchResult = true;
////            } else
//        if (m_rightSubquery >= m_leftSubquery) {
//            enableProxyCompletely();
//            m_currentFullOpsSubQueryIdx = (int) Math.floor((m_rightSubquery + m_leftSubquery) / 2);
//            operatorSearchResult = true;
//            disableProxyCompletely();
//        }
//        JarvisLogger.debug("[Runtime.increaseOperatorLoad] current subquery idx is: " + m_currentFullOpsSubQueryIdx +
//                " , subquery size: "+m_subQueries.size());
//        return operatorSearchResult;
//    }
//
////    public void reduceSubQuery() {
////        if(m_currentSubQueryIdx == -1) {
////            m_currentSubQueryIdx = m_subQueries.size() - 1;
////            m_internalControlProxies[m_subQueries.get(m_currentSubQueryIdx)].setDisableSendingToEdge();
////        } else {
////            if(m_currentSubQueryIdx > 0) {
////                m_currentSubQueryIdx -= 1;
////            }
////
////            m_internalControlProxies[m_subQueries.get(m_currentSubQueryIdx)].setDisableSendingToEdge();
////        }
////    }
//
////    public void increaseSubQuery() {
////        if(m_currentSubQueryIdx != -1) {
////            if(m_currentSubQueryIdx < m_subQueries.size() - 1) {
////                m_internalControlProxies[m_subQueries.get(m_currentSubQueryIdx)].unsetDisableSendingToEdge();
////                m_currentSubQueryIdx++;
////                m_internalControlProxies[m_subQueries.get(m_currentSubQueryIdx)].setDisableSendingToEdge();
////            } else {
////                m_internalControlProxies[m_subQueries.get(m_currentSubQueryIdx)].unsetDisableSendingToEdge();
////                m_currentSubQueryIdx = -1;
////            }
////        }
////    }
//
////    public void updateProbSendingToEdge() {
////        int id = 0;
////        for (ControllerQueue queue :
////                m_internalControlProxies) {
////            int numRecordsDrained = cpDrainedDataSizes[id];
////            updateProbSendingToEdge(queue, numRecordsDrained);
////            id++;
////        }
////    }
//
//    public void updateProbSendingToEdge(ControllerQueue queue, int numRecordsDrained) {
//        double probSendingToEdge = queue.getProbSendingToEdge();
//        if(numRecordsDrained > 1) {
//            probSendingToEdge -= m_probUpdateDelta;
//        } else {
//            probSendingToEdge += m_probUpdateDelta;
//        }
//
//        if(probSendingToEdge <= 0) {
//            probSendingToEdge = 0;
//        } else if(probSendingToEdge >= 1) {
//            probSendingToEdge = 1;
//        }
//
//        queue.setProbSendingToEdge(probSendingToEdge);
//    }
}

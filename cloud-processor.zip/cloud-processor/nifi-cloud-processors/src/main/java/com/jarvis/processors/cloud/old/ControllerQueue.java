//package com.jarvis.processors.cloud.old;
//
//import com.esotericsoftware.kryo.Kryo;
//import com.esotericsoftware.kryo.io.Output;
//import com.jarvis.processors.cloud.*;
//import org.apache.nifi.processor.Relationship;
//
//import java.io.ByteArrayOutputStream;
//import java.util.Random;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.concurrent.atomic.AtomicInteger;
//import java.util.concurrent.atomic.AtomicLong;
//
//public class ControllerQueue implements IQueue {
//    int m_queueId;
//    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
//    //    LinkedBlockingQueue<T> m_networkQueue = new LinkedBlockingQueue<>();
//    ByteArrayOutputStream m_networkOutputStream;
//    Output m_networkOutput;
//    Kryo m_kryo;
//    int m_threshold;
//    CloudUploader m_cloudUploader;
//    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
//    AtomicBoolean drainageTriggeredByCp = new AtomicBoolean(false);
//    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
//    AtomicBoolean m_drainageJustFinished = new AtomicBoolean(false);
//    Object watermarkLock = new Object();
//    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
//    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
//    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
//    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);
//
//    AtomicBoolean triggerDrainageCommandRuntime = new AtomicBoolean(false);
//
//    // Required for observing dataflow state after changing p_e values
//    AtomicBoolean m_selfObserve = new AtomicBoolean(false);
//    AtomicBoolean m_sampleWmSeqNum = new AtomicBoolean(false);
//    Object m_newEpochLock = new Object();
//    AtomicInteger m_recentSeqNum = new AtomicInteger(-1);
//
//    // Control proxy variables
//    volatile double m_probSendingToEdge = 1;
//    AtomicBoolean m_disableSendingToEdge = new AtomicBoolean(false);
//    public volatile double m_prevEpochDataSizeSentToEdge = 0;
//    private double m_currentEpochDataSizeSentToEdge = 0;
//    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
//    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
//    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
//    RuntimeState m_currRuntimeState;
//    private int m_currSubEpochSize = 0;
//    private int m_recordsInSubEpoch = 0;
//    private AtomicInteger m_totalSubEpochsCount = new AtomicInteger(0);
//    private int m_numSubEpochs = 0;
//    private int m_currSubEpochsCount = 0;
//    private int m_numRecordsInEpoch = 0;
//    private int m_totalInputRecords;
//
//    Object probSendingToEdgeLock = new Object();
//
//    Random randGen = new Random();
//
//    IData m_waterMarkEntry;
//    IData m_subEpochWatermarkEntry;
//    IQueue[] m_controlProxies;
//    IQueue m_outputQueue;
//
//    AtomicBoolean m_drainedAllQueues;
//    AtomicBoolean m_fullDrainModeEnabled = new AtomicBoolean(false);
//
//    Runtime m_runtime;
//
//    public ControllerQueue(int queueId, int threshold, Kryo kryo, Relationship MY_RELATIONSHIP, IData watermarkEntry,
//                           IData subWatermarkEntry, OutputQueueWrapper outputQueue, Runtime runtime,
//                           int numSubEpochs, int totalInputRecords) {
//        m_queueId = queueId;
//        m_threshold = threshold;
////        m_kryo = new Kryo();
//        m_kryo = kryo;
//        m_networkOutputStream = new ByteArrayOutputStream();
//        m_networkOutput = new Output(m_networkOutputStream);
//        m_cloudUploader = new CloudUploader(MY_RELATIONSHIP);
//        m_waterMarkEntry = watermarkEntry;
//        m_subEpochWatermarkEntry = subWatermarkEntry;
//        m_startEpochTimer.set(System.currentTimeMillis());
//        m_drainedAllQueues = new AtomicBoolean(false);
//        m_outputQueue = outputQueue;
//        m_runtime = runtime;
//        m_numSubEpochs = numSubEpochs;
//        m_totalInputRecords = totalInputRecords;
//    }
//
//    public void setControlProxies(ControllerQueue...controlProxies) {
//        m_controlProxies = controlProxies;
//    }
//
//    public IData take() {
//        IData takenVal = null;
//        try{
//
////            if(m_fullDrainModeEnabled.get()) {
////                tryDrainTillWatermark();
////            }
//
//            takenVal = queue.take();
//            if (takenVal.isWaterMark()) {
//                synchronized (watermarkLock) {
//                    waterMarkCountInQueue.decrementAndGet();
//                    drainageTriggeredByCp.set(true);
//                    if(queue.size() == 0 && m_currRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//                        m_startIdleTimer.set(System.currentTimeMillis());
//                        JarvisLogger.debug(m_queueId + " [ControllerQueue.take] start timer is " + m_startIdleTimer.get());
//                    }
//
//                    JarvisLogger.debug(m_queueId + " [SyncQueue.take] After reading outside of lock, " +
//                            "watermark size in take is " + waterMarkCountInQueue.get());
//
//                    // Reset the window size to signify end of current window processing by operator
//                    m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
//                    m_currentEpochDataSizeSentToEdge = 0;
////                   m_startIdleTimer.compareAndSet(Long.MAX_VALUE, System.currentTimeMillis());
//                    JarvisLogger.debug(m_queueId + " [SyncQueue.take] Size of recent window processed is " +
//                            m_prevEpochDataSizeSentToEdge);
//                    watermarkLock.notify();
//                }
//            } else {
//                m_currentEpochDataSizeSentToEdge += takenVal.isSubEpochMarker() ? 0 :
//                        takenVal.getPayloadInBytes();
//            }
//
//        } catch (Exception ex) {
//            JarvisLogger.debug("[SyncQueue.take] Exception in dequeueuing " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return takenVal;
//    }
//
////    public boolean drainRecord() {
////        boolean watermarkFound = false;
////        try {
////            if(waterMarkCountInQueue.get() > 0 && !drainageTriggered.get()) {
////                synchronized (watermarkLock) {
////                    if(waterMarkCountInQueue.get() > 0 && !drainageTriggered.get()) {
////                        JarvisLogger.debug(m_queueId + "[ControllerQueue.drainRecord] Watermark count for take is " +
////                                waterMarkCountInQueue.get() + ", Queue size is " + size());
////                        IData takenVal = queue.poll();
////                        if(takenVal != null) {
////                            if (isEntryWatermark(takenVal)) {
////                                watermarkFound = true;
////                            }
////                        }
////                    }
////                }
////            }
////            IData readObj = queue.take();
////
////        } catch (Exception ex) {
////            JarvisLogger.debug("[ControllerQueue.drainRecord] Failed while draining record: " + ex.toString());
////            ex.printStackTrace();
////        }
////    }
//
//
//
//    // TODO: Run with thread pool instead of creating new thread
//    // TODO: Evaluate with async drainage too
//    public void tryDrainTillWatermark() {
//        long start = System.currentTimeMillis();
//        IData takenVal;
//        int numRecords = 0;
//        int recordsDrainedSize = 0;
//        boolean watermarkFound = false;
//
//        // Additional condition: && !m_drainBlocked.get()
//        if((waterMarkCountInQueue.get() > 0 || m_fullDrainModeEnabled.get())
//                && !drainageTriggeredByCp.get()) {
//            synchronized (watermarkLock) {
//                // Additional condition: && !m_drainBlocked.get()
//                if((waterMarkCountInQueue.get() > 0  || m_fullDrainModeEnabled.get())
//                        && !drainageTriggeredByCp.get()) {
//                    JarvisLogger.debug(m_queueId + "[tryDrainTillWatermark] Watermark count for take is " +
//                            waterMarkCountInQueue.get() + ", Queue size is " + size());
//                    while (!watermarkFound && (takenVal = queue.poll()) != null) {
//                        // Transfer all queue contents for current window to cloud upload
//                        if (takenVal.isWaterMark()) {
//                            watermarkFound = true;
//                            try {
//                                queue.put(takenVal);
//                            } catch (Exception ex) {
//                                JarvisLogger.debug("[SyncQueueWrapper.tryDrainTillWatermark] Couldn't re-insert watermark");
//                                ex.printStackTrace();
//                            }
////                            m_startIdleTimer.compareAndSet(Long.MAX_VALUE, System.currentTimeMillis());
//                        } else if(takenVal.isSubEpochMarker()) {
//                            // Ignore sub-epoch markers when draining to cloud
//                            continue;
//                        }
//
//                        takenVal.writeSelfToKryo(m_kryo, m_networkOutput);
//                        numRecords++;
//                        recordsDrainedSize += takenVal.getPayloadInBytes();
//                    }
//
//                    // If next op reader dequeued watermark before drainer thread could
//                    if(recordsDrainedSize > 0 && !watermarkFound) {
//                        m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
//                    }
//
//                    JarvisLogger.debug(m_queueId + " [tryDrainTillWatermark] Total records ejected in this drain session is " +
//                            numRecords + " and " + "watermark count for take is " + waterMarkCountInQueue.get() +
//                            " and queue size is " + size() + ", records drianed size is: " + recordsDrainedSize);
//                }
//
//                drainageTriggeredByCp.set(true);
//                m_fullDrainModeEnabled.set(false);
//            }
//
//            // If there was more than just the watermark
//            if(numRecords > 1) {
//                byte[] windowContent = getByteArrayOutputStreamContent();
//                m_cloudUploader.sendToCloud(-1, windowContent);
//                reset();
//            }
//        }
//
//        int recordsWithoutWm = watermarkFound ?
//                (recordsDrainedSize-m_waterMarkEntry.getPayloadInBytes()) :
//                recordsDrainedSize;
//        m_recentEpochRecordsDrainedSize.set(recordsWithoutWm);
//    }
//
//    // TODO: evaluate synchronous vs. asynchronous design, don't use locks here if possible
//    public void put(IData item) {
//        try {
//            if(lastPutWasWatermark.get()) {
//                JarvisLogger.debug(m_queueId + " [ControllerQueue.put] Queue size on put " + size() + ", records drianed size: "
//                        + m_recentEpochRecordsDrainedSize.get());
//
//                m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
//                m_startEpochTimer.set(System.currentTimeMillis());
//
//                lastPutWasWatermark.set(false);
//                if(m_selfObserve.get()) {
//                    m_sampleWmSeqNum.set(true);
//                }
//
//                if(m_queueId == 0 &&
//                        m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    m_runtime.waitUntilAllQueuesDrained();
//
//                    // reset sub-epoch parameters
//                    JarvisLogger.debug("[ControllerQueue.put] Number of subepochs is " + m_currSubEpochsCount +
//                            ", and size is " + m_currSubEpochSize);
//                    m_recordsInSubEpoch = (int) (m_totalInputRecords * m_probSendingToEdge)/m_numSubEpochs;
//                    m_currSubEpochSize = 0;
//                    m_currSubEpochsCount = 0;
//                    JarvisLogger.debug(m_queueId + " [ControllerQueue.put] Expected records in subepoch: " +
//                            m_recordsInSubEpoch);
//                } else if(m_currRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//                    tryDrainTillWatermark();
//                    m_recentIdleTimeInMs.set(System.currentTimeMillis() - m_startIdleTimer.get());
//                    JarvisLogger.debug(m_queueId + " [ControllerQueue.put] start timer: " + m_startIdleTimer.get() + ", " +
//                            "recent idle time: " + m_recentIdleTimeInMs.get());
//                    m_startIdleTimer.set(Long.MAX_VALUE);
//                }
//
//                JarvisLogger.debug(m_queueId + " [ControllerQueue.put] Done waiting for Runtime. Going to add records to queue");
//            }
//
//            double randNum = randGen.nextDouble();
//            synchronized (probSendingToEdgeLock) {
//                if (!m_disableSendingToEdge.get() && randNum < m_probSendingToEdge) {
//                    queue.put(item);
//                    if(m_queueId == 0 && m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                        m_currSubEpochSize++;
//                        if(m_currSubEpochSize % m_recordsInSubEpoch == 0 &&
////                                m_currSubEpochsCount < m_numSubEpochs) {
//                                m_currSubEpochSize < (m_recordsInSubEpoch * m_numSubEpochs)) {
//                            queue.put(m_subEpochWatermarkEntry);
//                            m_currSubEpochsCount++;
//                            JarvisLogger.debug(m_queueId + " [ControllerQueue.put] Added subepoch marker to close epoch #" +
//                                    m_currSubEpochsCount + ", and subepoch size: " + m_currSubEpochSize);
//                        }
//                    }
//                } else {
//                    // Discard the record to cloud
//                    item.writeSelfToKryo(m_kryo, m_networkOutput);
//                    m_currEpochRecordsDiscardedSize.addAndGet(item.getPayloadInBytes());
//                }
//            }
//        } catch (Exception ex) {
//            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    public void putWaterMark(IData watermark) {
//        try {
//            if(m_sampleWmSeqNum.get()) {
//                m_selfObserve.set(false);
//                m_sampleWmSeqNum.set(false);
//
//                // So the next put will drain all queues first
//                m_currRuntimeState = RuntimeState.ADAPT_NOPROBING;
//                synchronized (m_newEpochLock) {
//                    m_recentSeqNum.set(watermark.getSeqNum());
//                    m_newEpochLock.notify();
//                }
//            }
//
//            synchronized (watermarkLock) {
//                while(waterMarkCountInQueue.get() > 0) {
//                    watermarkLock.wait();
//                }
//
//                waterMarkCountInQueue.incrementAndGet();
//                queue.put(watermark);
//                drainageTriggeredByCp.set(false);
//                m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
//                JarvisLogger.debug(m_queueId + " [putWaterMark] Watermark count in putWaterMark " +
//                        waterMarkCountInQueue.get() + " and " + " size is " + size() + ", watermark seq num: " + watermark.getSeqNum());
//            }
//
//
////            m_networkQueue.put(watermark);
////            PingMeshKryo waterMarkEntryKryoOnly = ((PingMeshKryoWithTime)watermark).getEntity();
////            m_kryo.writeObject(m_networkOutput, waterMarkEntryKryoOnly);
////            m_cloudUploader.sendToCloud();
//            lastPutWasWatermark.set(true);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    public int waitForNewEpochAndGetSeqNum() {
//        int seqNum = -1;
//        m_selfObserve.set(true);
//        try {
//            synchronized (m_newEpochLock) {
//                while (m_recentSeqNum.get() == -1) {
////                while(m_recentSeqNum.get() == -1 ||
////                        (m_currRuntimeState == RuntimeState.ADAPT_NOPROBING &&
////                                !m_drainedAllQueues.get())) {
//                    m_newEpochLock.wait();
//                }
//            }
//
//            seqNum = m_recentSeqNum.getAndSet(-1);
//            JarvisLogger.debug("Runtime thread [ControllerQueue.waitForNewEpochAndGetSeqNum] Seq num is : " + seqNum);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[ControllerQueue.waitForNewEpochAndGetSeqNum] Failed to get seq num: " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return seqNum;
//    }
//
//    public int size() {
//        return queue.size();
//    }
//
//    public byte[] getByteArrayOutputStreamContent() {
//        try {
//            m_networkOutput.flush();
//            m_networkOutputStream.flush();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return m_networkOutputStream.toByteArray();
//    }
//
//    public void reset() {
//        m_networkOutputStream.reset();
//        m_networkOutput.reset();
//    }
//
//    public void clear() {
//        queue.clear();
//        try {
//            m_networkOutputStream.flush();
//            m_networkOutput.flush();
//            m_networkOutputStream.reset();
//            m_networkOutput.reset();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    // Runtime related functions
//    public void disableSendingToEdge() {
//        m_disableSendingToEdge.set(true);
//        setProbSendingToEdge(0);
//    }
//
//    public void enableSendingToEdgeFlagOnly() {
//        m_disableSendingToEdge.set(false);
//    }
//
//    public void enableSendingToEdge() {
//        enableSendingToEdgeFlagOnly();
//        setProbSendingToEdge(1);
//    }
//
//    public void setSelfObserve() {
//        m_selfObserve.set(true);
//    }
//
//    public long getRecentNewEpochStartTime() {
//        return m_startEpochTimer.get();
//    }
//
//    public void resetIdleTimer() {
//        m_startIdleTimer.set(Long.MAX_VALUE);
//    }
//
//    public void setCurrRuntimeState(RuntimeState state) {
//        m_currRuntimeState = state;
//    }
//
//    public void setProbSendingToEdge(double probSendingToEdge) {
//        synchronized (probSendingToEdgeLock) {
//            m_probSendingToEdge = probSendingToEdge;
//        }
//    }
//
//    public double getProbSendingToEdge() {
//        double probReturnVal;
//        synchronized (probSendingToEdgeLock) {
//            probReturnVal = m_probSendingToEdge;
//        }
//
//        return probReturnVal;
//    }
//
//    public int getRecentRecordsDrainedSize() {
//        int drainedRec = m_recentEpochRecordsDrainedSize.get();
//        m_recentEpochRecordsDrainedSize.set(0);
//        return drainedRec;
//    }
//
//    public int getRecentRecordsDiscardedSize() {
//        return m_prevEpochRecordsDiscardedSize.get();
//    }
//
//    public void enableFullDrainMode() {
//        m_fullDrainModeEnabled.set(true);
//    }
//
//    public long getRecentIdleTime() {
//        if(m_queueId!=0 && m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//            throw new UnsupportedOperationException("Can't get recent idle time for CP which is not the first CP");
//        }
//
//        long idleTime = m_recentIdleTimeInMs.get();
//        m_recentIdleTimeInMs.set(0);
//        return idleTime;
//    }
//
//    public long getRecentEpochTime() {
//        return m_recentEpochTimeInMs.get();
//    }
//
//    public double getRecentPayloadSizeOnEdge() {
//        double payloadSize = m_prevEpochDataSizeSentToEdge;
//        m_prevEpochDataSizeSentToEdge = 0;
//        return payloadSize;
//    }
//
//    public void waitForWatermarkWithSeqNum(int seqNum) {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void unseeWatermark() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public long getIdleTimerVal() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//}

package com.jarvis.processors.cloud.workloads;

import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.*;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import com.jarvis.processors.cloud.operators.CustomMapOperator;
import com.jarvis.processors.cloud.operators.CustomOperator;

// Chains one or more map operators
public class ChainMapQuery1 extends Workload {

    public ChainMapQuery1() {
        super();

        classesToRegister = new IData[2];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();

        m_numOperators = 1;
        PingMeshKryo dummyWaterMarkWithoutTime = new PingMeshKryo();
        dummyWaterMarkWithoutTime.setWatermarkMarker();
        m_dummyWatermarkMarkerType = "PingMeshKryo";
        setQueuesAndRuntime();

        for(int i = 0; i < Config.QUERY_REPLICATION_FACTOR; i++) {
            m_customOperators[0][i] = new CustomMapOperator(0, m_firstCp[i], 1);
            m_customOperators[0][i].setNextQueue(m_finalCp);
        }
    }
}

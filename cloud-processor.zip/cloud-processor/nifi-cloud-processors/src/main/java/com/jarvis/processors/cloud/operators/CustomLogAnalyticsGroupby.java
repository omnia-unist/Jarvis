package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.LogAnalyticUtilHistCount;
import com.jarvis.processors.cloud.data.IData;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Operator to perform grouping on the extract tenant job information from logs
public class CustomLogAnalyticsGroupby extends CustomOperator {
    LogAnalyticUtilHistCount m_waterMarkEntryWithTime;

    public CustomLogAnalyticsGroupby(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntryWithTime = new LogAnalyticUtilHistCount();
        m_waterMarkEntryWithTime.setWatermarkMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                groupBy(v -> v.getGroupingKey(true)).
                flatMapSingle(grps -> {
                    return grps.toList().map(grpList -> {
                        int count=0;
                        for (IData data :
                                grpList) {
                            count += data.getCount();
                        }

                        LogAnalyticUtilHistCount histCount = new LogAnalyticUtilHistCount();
                        histCount.setSrcCluster(grps.getKey());
                        histCount.setCount(count);
                        return histCount;
                    });
                }).
                subscribe(
                        new Observer<IData>() {
                            @Override
                            public void onSubscribe(Disposable d) {}

                            @Override
                            public void onComplete() {
                                m_waterMarkEntryWithTime.resetQueueTime();
                                m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                                m_recentEpochEndTime = System.currentTimeMillis();
                                m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                                JarvisLogger.info("[CustomLogAnalyticsGroupby.onComplete] LP Solver op id: " + m_opId
                                    + ", epoch duration is: " + m_recentEpochDuration + ", records: " +
                                        m_currentEpochRecordCount + ", number of times put was called in onNext: " +
                                        m_numOutRecords[0]);
                                m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                            }

                            @Override
                            public void onError(Throwable throwable) {
                            }

                            @Override
                            public void onNext(IData data) {
                                try {
                                    data.resetQueueTime();
                                    m_numOutRecords[0]++;
                                    m_nextQueue.put(data);
                                } catch (Exception e) {
                                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                                }
                            }

                        }
                );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}


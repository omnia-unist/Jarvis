package com.jarvis.processors.cloud.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.data.IData;

// Stores the PingMesh record for S2SProbe query
public class PingMeshKryo implements IData {
    public int m_constantCol;
    public int m_event_time;
    public int m_src_cluster;
    public int m_src_ip;
    public int m_src_port;
    public int m_dest_cluster;
    public int m_dest_ip;
    public int m_dest_port;
    public int m_seq_num;
    public int m_rtt;
    public int m_errcode;
    public int m_result_type;
    public int m_level;
    public int m_msglen;
    int m_count;

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for PingMeshKryo class");
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for PingMeshKryo class");
    }

    public int getCount() {
        return m_count;
    }

    public float getMaxValue() {
        return m_rtt;
    }

    public float getMinValue() {
        return m_rtt;
    }

    public int getSeqNum() {
        return m_seq_num;
    }

    public void setSeqNum(int seqNum) {
        m_seq_num = seqNum;
    }

    public String toString() {
        return m_constantCol + "," + m_event_time + "," + m_src_cluster + "," + m_src_ip +
                "," + m_src_port + "," + m_dest_cluster + "," + m_dest_ip + "," +
                m_dest_port + "," + m_seq_num + "," + m_rtt + "," + m_errcode + "," +
                m_result_type + "," + m_level + "," + m_msglen;
    }

    public int getPayloadInBytes() {
        return 14 * Config.SIZE_OF_INT;
    }

    public boolean isWaterMark() {
        return (this.m_constantCol == Integer.MIN_VALUE);
    }

    public Integer getGroupingKey() {
        return m_src_cluster;
    }

    public Integer getGroupingValue() {
        return m_rtt;
    }

    public long getQueueTime() { return -1; }
    public void resetQueueTime() {}
    public IData getEntity() { return null; }
    public void setEntity(IData data) {}

    public void setWatermarkMarker() { this.m_constantCol = Integer.MIN_VALUE; }

    public void setGroupingKey(int key) { this.m_src_cluster = key; }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        // No-op
    }

    public Integer getJoinKey() {
        return m_src_cluster;
    }

    public void setJoinKey(int key) {
        m_src_cluster = key;
    }

    public void setJoinValue(int value) {
        m_rtt = value;
    }

    public Integer getJoinValue() {
        return m_rtt;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("PingMeshkryo doesn't have join marker");
    }

    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("PingMeshkryo doesn't have join marker");
    }

    public Integer getFilterPredVal() { return m_errcode; }

    public String getWordKey() {
        throw new UnsupportedOperationException("Not supported for numeric data");
    }

    @Override
    public boolean equals(Object summary) {
        boolean areEqual = false;
        if(summary == this) {
            areEqual = true;
        }

        if(summary instanceof PingMeshKryo) {
            PingMeshKryo sumaryObj = (PingMeshKryo) summary;
            areEqual = (m_seq_num==sumaryObj.m_seq_num) &&
                    (m_constantCol==sumaryObj.m_constantCol) &&
                    (m_dest_cluster==sumaryObj.m_dest_cluster) &&
                    (m_dest_ip==sumaryObj.m_dest_ip) &&
                    (m_dest_port==sumaryObj.m_dest_port) &&
                    (m_errcode==sumaryObj.m_errcode) &&
                    (m_event_time==sumaryObj.m_event_time) &&
                    (m_level==sumaryObj.m_level) &&
                    (m_msglen==sumaryObj.m_msglen) &&
                    (m_result_type==sumaryObj.m_result_type) &&
                    (m_rtt==sumaryObj.m_rtt) &&
                    (m_src_cluster==sumaryObj.m_src_cluster) &&
                    (m_src_ip==sumaryObj.m_src_ip) &&
                    (m_src_port==sumaryObj.m_src_port);
        }

        return areEqual;
    }
}

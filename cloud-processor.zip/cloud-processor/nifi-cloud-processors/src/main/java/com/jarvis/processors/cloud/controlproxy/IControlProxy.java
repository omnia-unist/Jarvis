package com.jarvis.processors.cloud.controlproxy;

import com.jarvis.processors.cloud.data.IData;

import java.util.concurrent.BrokenBarrierException;

// Interface for control proxy
public interface IControlProxy {
    // Put the data item into operator queue
    void put(IData item);

    // Put watermark into operator queue
    void putWaterMark(IData item);

    // Reads operator queue records
    IData take() throws InterruptedException, BrokenBarrierException;
}

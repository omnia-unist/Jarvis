//package com.jarvis.processors.cloud.old;
//
//import com.esotericsoftware.kryo.Kryo;
//import com.esotericsoftware.kryo.io.Output;
//
//public class SrcClusterStatsKryo implements IData {
//    private int m_srcCluster;
//    private float m_maxRtt;
//    private float m_minRtt;
//    private float m_avgRtt;
//    private int m_seqNum;
//    private long m_timeQueued;
//
//    public void setSrcCluster(int srcCluster) {
//        m_srcCluster = srcCluster;
//    }
//
//    public int getSrcCluster() {
//        return m_srcCluster;
//    }
//
//    public float getMaxRtt() {
//        return m_maxRtt;
//    }
//
//    public float getMinRtt() {
//        return m_minRtt;
//    }
//
//    public float getAvgRtt() {
//        return m_avgRtt;
//    }
//
//    public int getSeqNum() {
//        return m_seqNum;
//    }
//
//    public int getPayloadInBytes() {
//        return Runtime.SIZE_OF_INT + (3 * Runtime.SIZE_OF_FLOAT);
//    }
//
//
//    public void setSeqNum(int seqNum) {
//        m_seqNum = seqNum;
//    }
//
//    public void setMaxRtt(float maxRtt) {
//        m_maxRtt = maxRtt;
//    }
//
//    public void setMinRtt(float minRtt) {
//        m_minRtt = minRtt;
//    }
//
//    public void setAvgRtt(float avgRtt) {
//        m_avgRtt = avgRtt;
//    }
//
//    public void resetQueueTime() {
//        m_timeQueued = System.currentTimeMillis();
//    }
//
//    public long getQueueTime() {
//        return (System.currentTimeMillis() - m_timeQueued);
//    }
//
//    public int getHotKey() {
//        return m_srcCluster;
//    }
//
//    public boolean isWaterMark() {
//        return (this.m_srcCluster == Integer.MIN_VALUE);
//    }
//
//    public boolean isSubEpochMarker() {
//        return (this.m_srcCluster == Integer.MAX_VALUE);
//    }
//
//    public void writeSelfToKryo(Kryo kryo, Output output) {
//        kryo.writeObject(output, this);
//    }
//
//    public int getFilterPredVal() { return m_srcCluster; }
//
//    public IData getEntity() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public int getKey() {
//        return m_srcCluster;
//    }
//
//    public int getValue() {
//        return (int)m_avgRtt;
//    }
//
//    public void setEntity(IData data) {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public String toString() {
//        return m_seqNum + "," + m_srcCluster + "," + m_avgRtt + "," +
//                m_maxRtt + "," + m_minRtt;
//    }
//
//}

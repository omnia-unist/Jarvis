//package com.jarvis.processors.cloud.old;
//
//public interface IQueue {
//    void put(IData item);
//    void putWaterMark(IData item);
//
////    void putAdapt(IData item);
////    void putWaterMarkAdapt(IData item);
//
//    byte[] getByteArrayOutputStreamContent();
//    void reset();
//    void waitForWatermarkWithSeqNum(int seqNum);
//    int waitForNewEpochAndGetSeqNum();
//    void unseeWatermark();
//    long getRecentIdleTime();
//    int getRecentRecordsDrainedSize();
//    double getRecentPayloadSizeOnEdge();
//    int getRecentRecordsDiscardedSize();
//    long getRecentEpochTime();
//    void enableSendingToEdge();
//    void setProbSendingToEdge(double probSendingToEdge);
//    void enableSendingToEdgeFlagOnly();
//    void disableSendingToEdge();
//
//    //    boolean drainRecord();
//    long getIdleTimerVal();
//    void tryDrainTillWatermark();
//    void enableFullDrainMode();
//    void setCurrRuntimeState(RuntimeState state);
//    long getRecentNewEpochStartTime();
//    void resetIdleTimer();
//    IData take();
//}

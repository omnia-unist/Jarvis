package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.WordCountEntity;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.Arrays;
import java.util.List;

// Operator to filter out log lines which do not contain tenant job information
public class CustomLogAnalyticFilterOperator extends CustomOperator {

    WordCountEntity m_waterMarkEntry;
    String[] patternsArr = new String[] {"tenant name", "job running time", "cpu util", "gpu util", "memory util"};
    List<String> patternsList = Arrays.asList(patternsArr);

    public CustomLogAnalyticFilterOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue,1);
        m_waterMarkEntry = new WordCountEntity();
        m_waterMarkEntry.setWatermarkMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                map(v -> {
                    v.convertToLowerCase();
                    return v;
                }).
                filter(v -> patternsList.stream().anyMatch(v.toString()::contains)).
                subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        m_waterMarkEntry.resetQueueTime();
                        m_waterMarkEntry.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                        m_recentEpochEndTime = System.currentTimeMillis();
                        m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                        m_nextQueue.putWaterMark(m_waterMarkEntry);
                        JarvisLogger.info("[CustomLogAnalyticFilterOperator.onComplete] LP Solver op id: " + m_opId
                                + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            data.resetQueueTime();
                            m_numOutRecords[0]++;
                            m_nextQueue.put(data);
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}


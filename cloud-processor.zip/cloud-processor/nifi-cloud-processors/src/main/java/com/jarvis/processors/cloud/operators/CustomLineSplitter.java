package com.jarvis.processors.cloud.operators;

import com.jarvis.processors.cloud.*;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.IData;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.PingMeshKryoWithTime;
import com.jarvis.processors.cloud.data.WordCountEntity;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// Used to split lines in log based queries, and then perform count-based aggregation
public class CustomLineSplitter extends CustomOperator {

    WordCountEntity m_waterMarkEntry;
    private final String WHITE_SPACE = "\t";

    private final Map<String, Integer> wordCountMap = new ConcurrentHashMap<>();

    public CustomLineSplitter(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntry = new WordCountEntity();
        m_waterMarkEntry.setWatermarkMarker();

    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long[] processStart = {0L};
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                map(v -> { return v; }).
                subscribe(
                        new Observer<IData>() {
                            @Override
                            public void onSubscribe(Disposable d) {}

                            @Override
                            public void onComplete() {
                                // Send every word count into next queue
                                for (String wordKey :
                                        wordCountMap.keySet()) {
                                    WordCountEntity wordCountEntity = new WordCountEntity(wordKey,
                                            wordCountMap.get(wordKey));
                                    m_nextQueue.put(wordCountEntity);
                                }

                                JarvisLogger.info("Word count map size is: " + wordCountMap.get(wordCountMap.keySet().toArray()[9]));
                                wordCountMap.clear();
                                m_waterMarkEntry.resetQueueTime();
                                JarvisLogger.info(m_opId + " [CustomLineSplitter.onComplete] created watermark: " +
                                        m_waterMarkSeqNum.get());
                                m_waterMarkEntry.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                                m_recentEpochEndTime = System.currentTimeMillis();
                                m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                                JarvisLogger.info("[CustomLineSplitter.onComplete] Thread ID is: " +
                                        Thread.currentThread().getId() + ", epoch duration is: " +
                                        m_recentEpochDuration);
                                m_nextQueue.putWaterMark(m_waterMarkEntry);
                            }

                            @Override
                            public void onError(Throwable throwable) {
                            }

                            @Override
                            public void onNext(IData data) {
                                try {
                                    if(randGen.nextDouble() <= m_reductionRatio) {
                                        data.resetQueueTime();
                                        List<String> wordsAsStrings = Stream.of(data.getWordKey().split(WHITE_SPACE)).
                                                collect(Collectors.toList());
                                        wordsAsStrings.forEach( word -> wordCountMap.compute(word,
                                                (key, value) -> value == null ? 1 : value+1));

                                        m_numOutRecords[0]++;
                                    }
                                } catch (Exception e) {
                                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                                }
                            }

                        }
                );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }
}



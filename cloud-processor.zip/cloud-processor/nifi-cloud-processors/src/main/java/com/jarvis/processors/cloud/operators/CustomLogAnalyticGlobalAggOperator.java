package com.jarvis.processors.cloud.operators;


import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.JarvisLogger;
import com.jarvis.processors.cloud.controlproxy.IControlProxy;
import com.jarvis.processors.cloud.data.LogAnalyticUtilHistCount;
import com.jarvis.processors.cloud.data.IData;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Computes the final aggregation data from the output of all query instances,
// for LogAnalyticsQuery in which the aggregation key is a string
public class CustomLogAnalyticGlobalAggOperator implements ICustomGlobalAggOp {
    LogAnalyticUtilHistCount m_waterMarkEntryWithTime;
    IControlProxy m_nextQueue;
    io.reactivex.subjects.PublishSubject<IData> m_subject;
    AtomicInteger m_waterMarkSeqNum = new AtomicInteger(0);
    protected int m_opId;
    protected AtomicLong m_startEpoch = new AtomicLong(0);
    protected long m_recentEpochDuration = 0;
    protected long m_recentEpochEndTime = 0;
    ConcurrentHashMap<String, LinkedBlockingQueue<IData>> m_aggMap = new ConcurrentHashMap<>();

    public CustomLogAnalyticGlobalAggOperator(int opId) {
        m_opId = opId;
        m_waterMarkEntryWithTime = new LogAnalyticUtilHistCount();
        m_waterMarkEntryWithTime.setWatermarkMarker();
        JarvisLogger.info("[CustomLogAnalyticGlobalAggOperator.CustomFullGroupbyOperator] constructor for op: "
                + opId);
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }
    public void onNext(IData data) {
        if(Config.ENABLE_GLOBAL_AGG) {
            if(m_aggMap.size() == 0) {
                m_startEpoch.compareAndSet(0, System.currentTimeMillis());
            }

            LinkedBlockingQueue<IData> valuesQueue = m_aggMap.get(data.getGroupingKey());
            if (valuesQueue == null) {
                valuesQueue = new LinkedBlockingQueue<>();
                LinkedBlockingQueue availQueue = m_aggMap.putIfAbsent(data.getGroupingKey(true), valuesQueue);
                if (availQueue != null) {
                    valuesQueue = availQueue;
                }
            }

            valuesQueue.add(data);
        }
    }

    public void onComplete() {
        m_waterMarkEntryWithTime.resetQueueTime();
        m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
        m_recentEpochEndTime = System.currentTimeMillis();
        m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch.getAndSet(0);
        if(Config.ENABLE_GLOBAL_AGG) {
            int totalRecordCount = 0;

            // Process the entire map
            for (String groupingKey :
                    m_aggMap.keySet()) {
                int count=0;
                for (IData entry :
                        m_aggMap.get(groupingKey)) {
                    count += entry.getCount();
                }

                LogAnalyticUtilHistCount histCount = new LogAnalyticUtilHistCount();
                histCount.setSrcCluster(groupingKey);
                histCount.setCount(count);
                m_nextQueue.put(histCount);
            }

            m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
            m_aggMap.clear();
            JarvisLogger.info("[CustomLogAnalyticGlobalAggOperator.onComplete] LP Solver op id: " + m_opId
                    + ", epoch duration is: " + m_recentEpochDuration + ", records: " + totalRecordCount +
                    "sent watermark " + m_waterMarkSeqNum.get());
        }
    }
}



//package com.jarvis.processors.cloud.old;
//
//import com.jarvis.processors.cloud.JarvisLogger;
//import io.reactivex.Observer;
//import io.reactivex.disposables.Disposable;
//
//public class CustomFilterOperator extends CustomOperator {
//
//    PingMeshKryoWithTime m_waterMarkEntryWithTime;
//    PingMeshKryoWithTime m_subEpochMarkerWithTime;
//
//    public CustomFilterOperator(int opId, ControllerQueueWithoutAdapt currentQueue) {
//        super(opId, currentQueue,1);
//        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
//        PingMeshKryo waterMarkEntry = new PingMeshKryo();
//        waterMarkEntry.m_constantCol = Integer.MIN_VALUE;
//        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);
//
//        m_subEpochMarkerWithTime = new PingMeshKryoWithTime();
//        PingMeshKryo subEpochMarker = new PingMeshKryo();
//        subEpochMarker.m_constantCol = Integer.MAX_VALUE;
//        m_subEpochMarkerWithTime.setEntity(subEpochMarker);
//    }
//
//    public CustomFilterOperator(int opId, ControllerQueue currentQueue) {
//        super(opId, currentQueue,1);
//        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
//        PingMeshKryo waterMarkEntry = new PingMeshKryo();
//        waterMarkEntry.m_constantCol = Integer.MIN_VALUE;
//        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);
//
//        m_subEpochMarkerWithTime = new PingMeshKryoWithTime();
//        PingMeshKryo subEpochMarker = new PingMeshKryo();
//        subEpochMarker.m_constantCol = Integer.MAX_VALUE;
//        m_subEpochMarkerWithTime.setEntity(subEpochMarker);
//    }
//
//    public void setNextQueue(IQueue queue) {
//        // No-op since final operator
//        m_nextQueue = queue;
//    }
//
//    public void setDataflow() {
//        Long[] processStart = {0L};
//        Long startDataflowBuild = System.currentTimeMillis();
//        m_subject = io.reactivex.subjects.PublishSubject.create();
//        m_subject.
////                doOnNext(v -> {
////                    processStart[0] = System.currentTimeMillis();
////                }).
//        filter(v -> v.getFilterPredVal() != 0).
////                doOnNext(v -> {
////                    m_totalProcessingTime += (System.currentTimeMillis() - processStart[0]);
////                }).
//        subscribe(
//        new Observer<IData>() {
//            @Override
//            public void onSubscribe(Disposable d) {}
//
//            @Override
//            public void onComplete() {
//                if(!m_subEpochComplete.get()) {
//                    m_waterMarkEntryWithTime.resetQueueTime();
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] created watermark: " +
//                            m_waterMarkSeqNum.get());
//                    m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
//                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
//                } else {
//                    m_nextQueue.put(m_subEpochMarkerWithTime);
//                    m_subEpochComplete.set(false);
//                    JarvisLogger.debug(m_opId + " [CustomMapOperator.onComplete] subepoch marker set");
//                }
//            }
//
//            @Override
//            public void onError(Throwable throwable) {
//            }
//
//            @Override
//            public void onNext(IData data) {
//                try {
//                    data.resetQueueTime();
//                    m_nextQueue.put(data);
//                    m_numOutRecords[0]++;
//                } catch (Exception e) {
//                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
//                }
//            }
//
//        }
//    );
//
//        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
//    }
//}
//

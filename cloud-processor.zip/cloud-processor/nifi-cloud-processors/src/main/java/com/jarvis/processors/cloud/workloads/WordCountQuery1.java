package com.jarvis.processors.cloud.workloads;

import com.jarvis.processors.cloud.Config;
import com.jarvis.processors.cloud.controlproxy.ControlProxy;
import com.jarvis.processors.cloud.data.*;
import com.jarvis.processors.cloud.operators.CustomLineSplitter;
import com.jarvis.processors.cloud.operators.CustomOperator;

// Performs word count query
public class WordCountQuery1 extends Workload {
    public WordCountQuery1() {
        super();

        classesToRegister = new IData[1];
        classesToRegister[0] = new WordCountEntity();

        m_numOperators = 1;

        m_dummyWatermarkMarkerType = "WordCountEntity";
        setQueuesAndRuntime();

        // Instantiate query instances
        for (int j = 0; j < Config.QUERY_REPLICATION_FACTOR; j++) {
            m_customOperators[0][j] = new CustomLineSplitter(j, m_firstCp[j]);
            m_customOperators[0][j].setNextQueue(m_finalCp);
        }
    }
}

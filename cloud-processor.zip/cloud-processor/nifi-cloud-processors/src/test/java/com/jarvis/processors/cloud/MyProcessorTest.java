/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jarvis.processors.cloud;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.jarvis.processors.cloud.data.PingMeshKryo;
import com.jarvis.processors.cloud.data.SrcClusterStatsKryo;
import com.jarvis.processors.cloud.data.WordCountEntity;
import org.apache.nifi.util.MockFlowFile;
import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jarvis.processors.cloud.MyProcessor.MY_RELATIONSHIP;
import static com.jarvis.processors.cloud.MyProcessor.MY_RELATIONSHIP_1;
import static com.jarvis.processors.cloud.MyProcessor.*;

// Implements unit tests and integration tests for processing of streams from data sources in the stream processor
public class MyProcessorTest {

    private TestRunner testRunner;

    @Before
    public void init() {
        testRunner = TestRunners.newTestRunner(MyProcessor.class);
    }

    // Tests S2SProbe query on stream processor
    @Test
    public void testProcessor() {

        File flowfileInp = new File("/home/athuls89/Desktop/OSL/msr/Datasets/PingMesh/xxa-1000records.allintify.kryo");
        try {
            InputStream in = null;

            int flowFileCount = 0;
            int shortSleep = 500;
            int mediumSleep = 1500;
            int longSleep = 500;
            testRunner.setProperty(MY_PROPERTY, "debugConfig.cfg");
            while(flowFileCount < 20) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                if(flowFileCount <= 20) {
                    Thread.sleep(longSleep);
                } else if(flowFileCount < 20) {
                    Thread.sleep(shortSleep);
                } else {
                    Thread.sleep(mediumSleep);
                }

                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            System.out.println("Size of MY_RELATIONSHIP is " + results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            System.out.println("Size of MY_RELATIONSHIP_1 is " + results1.size());

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);

            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            PingMeshKryo object2 = m_kryo.readObject(kryoInput, PingMeshKryo.class);
            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                    read++;
                }
            } catch (Exception ex) {
                System.out.println("Done reading");
            }

            System.out.println("Edge processing record count: " + read);
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of SecClusterStatsKryo data for S2SProbe and T2TProbe queries, from flowfile
    private void readSrcClusterStatsKryoFile(MockFlowFile flowFile, String outputFile) {
        try {
            Kryo kryo = new Kryo();
            kryo.register(SrcClusterStatsKryo.class);
            byte[] outputEdge = testRunner.getContentAsByteArray(flowFile);
            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input input = new Input(outputEdgeStream);
            System.out.println("Writing output to : " + outputFile);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));

            SrcClusterStatsKryo object2 = kryo.readObject(input, SrcClusterStatsKryo.class);
            writer.write(object2.toString()+"\n");
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, SrcClusterStatsKryo.class);
                    writer.write(object2.toString()+"\n");
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of SecClusterStatsKryo data for S2SProbe and T2TProbe queries, from text file on disk
    private void readSrcClusterStatsKryoFile(String inputFile, String outputFile) {
        try {
            Kryo kryo = new Kryo();
            kryo.register(SrcClusterStatsKryo.class);
            Input input = new Input(new FileInputStream(inputFile));
            System.out.println("Writing output to : " + outputFile);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));

            Integer cpId = kryo.readObject(input, Integer.class);
            String dataType = kryo.readObject(input, String.class);

            SrcClusterStatsKryo object2 = kryo.readObject(input, SrcClusterStatsKryo.class);
            writer.write(object2.toString()+"\n");
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, SrcClusterStatsKryo.class);
                    writer.write(object2.toString()+"\n");
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of WordCountEntity data, from text file
    private void readWordCountEntityKryoFile(String inputFile, String outputFile) {
        try {
            Kryo kryo = new Kryo();
            kryo.register(WordCountEntity.class);
            kryo.register(String.class);
            kryo.register(Integer.class);
            Input input = new Input(new FileInputStream(inputFile));
            byte[] read = input.getBuffer();
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));

            Integer cpId = kryo.readObject(input, Integer.class);
            String dataType = kryo.readObject(input, String.class);

            WordCountEntity object2 = kryo.readObject(input, WordCountEntity.class);
            writer.write(object2.toString()+"\n");
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, WordCountEntity.class);
                    writer.write(object2.toString()+"\n");
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of WordCountEntity data, from flow file
    private void readWordCountEntityKryoFile(MockFlowFile flowFile, String outputFile) {
        try {
            Kryo kryo = new Kryo();
            kryo.register(WordCountEntity.class);
            byte[] outputEdge = testRunner.getContentAsByteArray(flowFile);
            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input input = new Input(outputEdgeStream);
            System.out.println("Writing output to : " + outputFile);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));

            WordCountEntity object2 = kryo.readObject(input, WordCountEntity.class);
            writer.write(object2.toString()+"\n");
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, WordCountEntity.class);
                    writer.write(object2.toString()+"\n");
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of WordCountEntity data, from flow file
    @Test
    public void TestIntegrationOutFile() {
        readWordCountEntityKryoFile("testInput/wordCountCompleted2", "temp2");
    }

    // Tests the integration of WordCountEntity data processing using WordCountQuery1 query, from flow files
    @Test
    public void TestIntegrationWordCount() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        try {
            if (dirListing != null && dirListing.length > 0) {
                try {

                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("wordCount")) {
                            System.out.println("[MyProcessorTest.TestIntegration] file is: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "wordCountDebug.cfg");
                            in = new FileInputStream(testInput);
                            testRunner.enqueue(in);
                            testRunner.run(1);
                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(1, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readWordCountEntityKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of LogAnalytics query, in the All-SP configuration
    @Test
    public void TestLogAnalyticsQuery() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId=0;
                    int flowFileCount = 0;
                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("allSpLogAnalyticsCompleted")) {
                            readWordCountEntityKryoFile(testInput.getAbsolutePath(), "temp");
                            System.out.println("[MyProcessorTest.TestIntegration] file is: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "LogAnalyticQuery.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", "0");
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            if(flowFileCount == 1 || flowFileCount == 2) {
                                epochId++;
                            }
                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(2, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readWordCountEntityKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of LogAnalytics query, in the All-Src configuration
    @Test
    public void TestLogAnalyticsAllSrcQuery() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId=1;
                    int flowFileCount = 0;
                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("allSrcLogAnalyticsCompleted")) {
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "LogAnalyticQuery.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", "0");
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            if(flowFileCount == 1 || flowFileCount == 2) {
                                epochId++;
                            }
                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(2, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readWordCountEntityKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of LogAnalytics query, in the Filter-Src configuration
    @Test
    public void TestLogAnalyticsFilterSrcAdaptQuery() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId=1;
                    int flowFileCount = 0;
                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("filterSrcLogAnalyticsUtil")) {
                            System.out.println("Processing file: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "LogAnalyticQuery.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", "0");
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            if(flowFileCount == 1 || flowFileCount == 2 || flowFileCount == 3) {
                                epochId++;
                            }
                            Thread.sleep(2000);
                            testRunner.assertQueueEmpty();
                        }
//                    }
                    }

                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(2, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readWordCountEntityKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of S2SProbe query
    @Test
    public void TestIntegrationPingMesh() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        int flowFileCount = 0;
        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId=0;
                    for (File testInput :
                            dirListing) {
//                        if(testInput.getAbsolutePath().contains("multiS2sProbeCompleted")) {
                        if(testInput.getAbsolutePath().contains("s2sProbeCompleted")) {
                            System.out.println("[MyProcessorTest.TestIntegration] file is: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "debugConfig.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", "0");
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            epochId++;
                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    Thread.sleep(10000);
                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    readSrcClusterStatsKryoFile(results.get(0), "temp");
                    Assert.assertEquals(9, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of S2SProbe query, in the All-SP configuration, from single edge
    @Test
    public void TestIntegrationAllSpSingleEdge() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        int flowFileCount = 0;

        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId = 0;
                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("allSp")) {
                            System.out.println("[MyProcessorTest.TestIntegration] file is: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "allSpConfig.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", "0");
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            if(flowFileCount == 9 || flowFileCount == 19) {
                                epochId++;
                            }

                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    System.out.println("Flow File count is: " + flowFileCount);
                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(2, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readSrcClusterStatsKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }

    // Tests the integration of S2SProbe query, in the All-SP configuration, from multiple edges
    @Test
    public void TestIntegrationAllSpMultipleEdges() {
        File dir = new File("testInput");
        File[] dirListing = dir.listFiles();
        List<MockFlowFile> results = null, results1 = null;
        int flowFileCount = 0;

        try {
            if (dirListing != null && dirListing.length > 0) {
                try {
                    int epochId = 0;
                    for (File testInput :
                            dirListing) {
                        if(testInput.getAbsolutePath().contains("allSp")) {
                            System.out.println("[MyProcessorTest.TestIntegration] file is: " + testInput.getAbsolutePath());
                            InputStream in = null;
                            testRunner.setProperty(MY_PROPERTY, "allSpConfig.cfg");
                            in = new FileInputStream(testInput);
                            MockFlowFile mockFile = testRunner.enqueue(in);
                            final int edgeIdTemp = flowFileCount % 2;
                            final int epochIdTemp = epochId;
                            Map<String, String> attrs = new HashMap<String, String>() {{
                                put("edgeId", Integer.toString(edgeIdTemp));
                                put("epochId", Integer.toString(epochIdTemp));
                            }};
                            mockFile.putAttributes(attrs);
                            testRunner.run(1);
                            flowFileCount++;
                            if(flowFileCount == 9 || flowFileCount == 18) {
                                epochId++;
                            }

                            Thread.sleep(1000);
                            testRunner.assertQueueEmpty();
                        }
                    }

                    JarvisLogger.m_myWriter.close();
                    System.out.println("Flow File count is: " + flowFileCount);
                    Thread.sleep(3000);

                    results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
                    Assert.assertEquals(2, results.size());
                    results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
                    Assert.assertEquals(0, results1.size());
                    System.out.println("Results sizes are: " + results.size() + ", " + results1.size());
                } catch (Exception ex) {
                    System.out.println("Couldn't read flowfile input " + ex.toString());
                    ex.printStackTrace();
                }

                readSrcClusterStatsKryoFile(results.get(0), "temp");
            } else {
                Assert.fail("testInput directory does not have files");
            }
        } catch (Exception ex) {
            JarvisLogger.info("Exception thrown in integration test on cloud side: " + ex.toString());
        }
    }
}


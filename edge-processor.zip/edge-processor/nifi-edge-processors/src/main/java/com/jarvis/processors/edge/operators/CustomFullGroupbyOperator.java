package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.controlproxy.ControlProxy;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.SrcClusterStatsKryo;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Custom operator to perform grouping and reduction in S2SProbe and T2TProbe queries
public class CustomFullGroupbyOperator extends CustomOperator {
    SrcClusterStatsKryo m_waterMarkEntryWithTime;
    SrcClusterStatsKryo m_subEpochMarkerWithTime;

    public CustomFullGroupbyOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntryWithTime = new SrcClusterStatsKryo();
        m_waterMarkEntryWithTime.setWatermarkMarker();

        m_subEpochMarkerWithTime = new SrcClusterStatsKryo();
        m_subEpochMarkerWithTime.setSubEpochMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                groupBy(v -> v.getGroupingKey()).
                flatMapSingle(grps -> {
                    return grps.toList().map(grpList -> {
                        int max = 0, min = Integer.MAX_VALUE, count=0;
                        float avg = 0;
                        for (IData data :
                                grpList) {
                            int value = data.getGroupingValue();
                            if(value > max) {
                                max = value;
                            }

                            if(value < min) {
                                min = value;
                            }

                            avg += value;
                            count += data.getCount();
                        }

                        SrcClusterStatsKryo srcClusterStatsKryo = new SrcClusterStatsKryo();
                        srcClusterStatsKryo.setSrcCluster((int) grps.getKey());
                        srcClusterStatsKryo.setAvgRtt(avg/(float)count);
                        srcClusterStatsKryo.setMinRtt(min);
                        srcClusterStatsKryo.setMaxRtt(max);
                        srcClusterStatsKryo.setCount(count);
                        return srcClusterStatsKryo;
                    });
                }).
                subscribe(
                        new Observer<IData>() {
                            @Override
                            public void onSubscribe(Disposable d) {}

                            @Override
                            public void onComplete() {
                                if(!m_subEpochComplete.get()) {
                                    m_waterMarkEntryWithTime.resetQueueTime();
                                    JarvisLogger.debug(m_opId + " [CustomFullGroupbyOperator.onComplete] created watermark: " +
                                            m_waterMarkSeqNum.get());
                                    m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                                    m_recentEpochEndTime = System.currentTimeMillis();
                                    m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                                    JarvisLogger.debug("[CustomFullGroupbyOperator.setDataflow] Thread ID is: " +
                                            Thread.currentThread().getId() + ", epoch duration is: " +
                                            m_recentEpochDuration);
                                    JarvisLogger.info("[CustomFullGroupbyOperator.onComplete] LP Solver op id: " + m_opId
                                        + ", epoch duration is: " + m_recentEpochDuration + ", records: " +
                                            m_currentEpochRecordCount + ", number of times put was called in onNext: " +
                                            m_numOutRecords[0]);
                                    m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                                } else {
                                    m_subEpochComplete.set(false);
                                    m_nextQueue.put(m_subEpochMarkerWithTime);
                                }
                            }

                            @Override
                            public void onError(Throwable throwable) {
                            }

                            @Override
                            public void onNext(IData data) {
                                try {
                                    data.resetQueueTime();
                                    m_numOutRecords[0]++;
                                    m_nextQueue.put(data);
                                } catch (Exception e) {
                                    JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                                }
                            }

                        }
                );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}


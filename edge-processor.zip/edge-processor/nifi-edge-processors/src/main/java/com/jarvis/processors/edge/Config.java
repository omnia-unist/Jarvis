package com.jarvis.processors.edge;

import org.apache.nifi.logging.ComponentLog;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Reads input config file and stores all config information
public class Config {
    public static String DEBUG_MODE;
    public static int JOIN_TABLE_SIZE;
    public static int JOIN_KEY_START;
    public static boolean IS_TEST_PHASE;
    public static boolean LARGE_RESOURCE_CHANGE;
    public static boolean INITIAL_LOAD_FACTOR_LP;
    public static boolean INITIAL_LOAD_FACTOR_1;
    public static boolean INITIAL_LOAD_FACTOR_0;
    public static boolean INITIAL_LOAD_FACTOR_BOOTSTRAP;

    public static List<Double> m_initialLoadFactors;
    public static PartitioningConfig PARTITION_CONFIG;
    public static String WORKLOAD;
    public static Double DRAIN_THRESHOLD;
    public static Double IDLE_TIME_DELTA_THRESHOLD;
    public static Double IDLE_TO_EPOCH_RATIO_THRESHOLD;
    public static List<Double> m_beginLoadFactors;
    public static int FIRST_EPOCH_TO_START_RUNTIME;
    public static int MAX_DETECTION_EPOCHS;
    public static int MAX_NUM_ADAPTATIONS;
    public static String EDGE_ID;
    public static String INPUT_FILE;
    public static boolean TO_DRAIN;
    public static int NUM_SUBEPOCHS;
    public static Boolean FILTER_OUT_ANOMALY;
    public static int COOL_DOWN_ITERATIONS;
    public static int WARM_UP_TIME_SECONDS;
    public static int WARM_UP_INPUT_SCALE_FACTOR;
    public static int REGULAR_INPUT_SCALE_FACTOR;
    public static float GROUPING_REDUCTION_FRACTION;
    public static int NUMBER_OF_MULTIQUERY_INSTANCES;
    public static void loadConfig(ComponentLog logger, String configFilePath) {
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(configFilePath))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONObject configObj = (JSONObject) ((JSONArray) obj).get(0);

            JSONObject configValues = (JSONObject) configObj.get("configValues");
            DEBUG_MODE = (String) configValues.get("debugMode");
            logger.debug("[Config.loadConfig] debug mode is " + DEBUG_MODE);
            String joinTableSizeAsStr = (String) configValues.get("joinTableSize");
            JOIN_TABLE_SIZE = Integer.parseInt(joinTableSizeAsStr);
            logger.debug("[Config.loadConfig] join table size is " + JOIN_TABLE_SIZE);
            String joinKeyStartAsStr = (String) configValues.get("joinKeyStart");
            JOIN_KEY_START = Integer.parseInt(joinKeyStartAsStr);
            logger.debug("[Config.loadConfig] join key start is " + JOIN_KEY_START);
            String isTestPhase = (String) configValues.get("isTestPhase");
            IS_TEST_PHASE = isTestPhase.equals("yes") ? true : false;;
            logger.debug("[Config.loadConfig] is test phase " + IS_TEST_PHASE);

            String drainThreshold = (String) configValues.get("drainedRecordsFractionThreshold");
            DRAIN_THRESHOLD = Double.parseDouble(drainThreshold);
            logger.debug("[Config.loadConfig] drain threshold is " + DRAIN_THRESHOLD);

            String idleToEpochTimeRatioThreshold = (String) configValues.get("idleToEpochTimeRatioThreshold");
            IDLE_TO_EPOCH_RATIO_THRESHOLD = Double.parseDouble(idleToEpochTimeRatioThreshold);
            logger.debug("[Config.loadConfig] idle to epoch time ratio threshold is " +
                    IDLE_TO_EPOCH_RATIO_THRESHOLD);

            String idleTimeDeltaRatioThreshold = (String) configValues.get("idleTimeDeltaRatioThreshold");
            IDLE_TIME_DELTA_THRESHOLD = Double.parseDouble(idleTimeDeltaRatioThreshold);
            logger.debug("[Config.loadConfig] idle time delta ratio threshold is " + IDLE_TIME_DELTA_THRESHOLD);

            String firstEpochToStartRuntime = (String) configValues.get("firstEpochToStartRuntime");
            FIRST_EPOCH_TO_START_RUNTIME = Integer.parseInt(firstEpochToStartRuntime);
            logger.debug("[Config.loadConfig] First epoch to start runtime is " + FIRST_EPOCH_TO_START_RUNTIME);

            String detectionEpochs = (String) configValues.get("detectionEpochs");
            MAX_DETECTION_EPOCHS = Integer.parseInt(detectionEpochs);
            logger.debug("[Config.loadConfig] Number of detection epochs is " + MAX_DETECTION_EPOCHS);

            String warmUpTime = (String) configValues.get("warmUpTime");
            WARM_UP_TIME_SECONDS = Integer.parseInt(warmUpTime);
            logger.debug("[Config.loadConfig] Warm up time is " + WARM_UP_TIME_SECONDS);

            String maxNumAdaptations = (String) configValues.get("maxNumAdaptations");
            MAX_NUM_ADAPTATIONS = Integer.parseInt(maxNumAdaptations);
            logger.debug("[Config.loadConfig] Max number of adaptations is " + MAX_NUM_ADAPTATIONS);

            String numQueryInstancesStr = configValues.containsKey("numQueryInstances") ?
                    (String) configValues.get("numQueryInstances") : null;
            NUMBER_OF_MULTIQUERY_INSTANCES = numQueryInstancesStr != null ?
                    Integer.parseInt(numQueryInstancesStr) : 1;
            logger.debug("[Config.loadConfig] Number of query instances is " + NUMBER_OF_MULTIQUERY_INSTANCES);

            String warmUpInputScaleFactor = (String) configValues.get("warmUpInputScaleFactor");
            WARM_UP_INPUT_SCALE_FACTOR = Integer.parseInt(warmUpInputScaleFactor);
            logger.debug("[Config.loadConfig] warm up input scale factor is " + WARM_UP_INPUT_SCALE_FACTOR);

            String regularInputScaleFactor = configValues.containsKey("regularInputScaleFactor") ?
                    (String) configValues.get("regularInputScaleFactor") : null;
            REGULAR_INPUT_SCALE_FACTOR = regularInputScaleFactor != null ?
                    Integer.parseInt(regularInputScaleFactor) : 1;
            logger.debug("[Config.loadConfig] Regular input scale factor is " + REGULAR_INPUT_SCALE_FACTOR);

            String groupingReductionFraction = configValues.containsKey("groupingReductionFraction") ?
                    (String) configValues.get("groupingReductionFraction") : null;
            GROUPING_REDUCTION_FRACTION = groupingReductionFraction != null ?
                    Float.parseFloat(groupingReductionFraction) : 1;
            logger.debug("[Config.loadConfig] Grouping reduction fraction is " + GROUPING_REDUCTION_FRACTION);

            EDGE_ID = (String) configValues.get("edgeId");
            logger.debug("[Config.loadConfig] Edge ID is " + EDGE_ID);

            WORKLOAD = (String) configValues.get("workload");
            logger.debug("[Config.loadConfig] workload is " + WORKLOAD);

            INPUT_FILE = (String) configValues.get("inputFile");
            logger.debug("[Config.loadConfig] Config file path is: " + INPUT_FILE);

            String partitionConfigVal = (String) configValues.get("partitioningConfig");
            switch (partitionConfigVal) {
                case "AllSP":
                    Config.PARTITION_CONFIG = PartitioningConfig.ALL_SP;
                    break;
                case "Adapt":
                    Config.PARTITION_CONFIG = PartitioningConfig.ADAPT;
                    break;
                case "NoAdapt":
                    Config.PARTITION_CONFIG = PartitioningConfig.NO_ADAPT;
                    break;
            }

            logger.debug("[Config.loadConfig] Partition config: " + PARTITION_CONFIG);

            String filterOutAnomaly = ((String) configValues.get("filterOutAnomaly")).toLowerCase();
            if(filterOutAnomaly.equals("none")) {
                FILTER_OUT_ANOMALY = null;
            } else {
                if(filterOutAnomaly.equals("true")) {
                    FILTER_OUT_ANOMALY = true;
                } else {
                    FILTER_OUT_ANOMALY = false;
                }
            }

            String toDrain = (String) configValues.get("toDrain");
            TO_DRAIN = (toDrain.equals("Yes")) ? true: false;

            String resourceChangeType = (String) configValues.get("resourceChangeType");
            LARGE_RESOURCE_CHANGE = (resourceChangeType.equals("LARGE")) ? true: false;

            String numSubEpochsStr = (String) configValues.get("numSubepochs");
            NUM_SUBEPOCHS = Integer.parseInt(numSubEpochsStr);

            String coolDownIterations = (String) configValues.get("coolDownIterations");
            COOL_DOWN_ITERATIONS = Integer.parseInt(coolDownIterations);

            String initialLoadFactor = (String) configValues.get("initializeLoadFactor");
            INITIAL_LOAD_FACTOR_LP = (initialLoadFactor.equals("LP")) ? true: false;
            INITIAL_LOAD_FACTOR_0 = (initialLoadFactor.equals("0")) ? true: false;
            INITIAL_LOAD_FACTOR_1 = (initialLoadFactor.equals("1")) ? true: false;
            INITIAL_LOAD_FACTOR_BOOTSTRAP = (initialLoadFactor.equals("Bootstrap")) ? true : false;
            if(!(INITIAL_LOAD_FACTOR_1 || INITIAL_LOAD_FACTOR_0 || INITIAL_LOAD_FACTOR_LP
                    || INITIAL_LOAD_FACTOR_BOOTSTRAP)) {
                m_initialLoadFactors = new ArrayList<>();
                String[] loadFactorAsStr = initialLoadFactor.split(",");
                for (String loadFactor :
                        loadFactorAsStr) {
                    m_initialLoadFactors.add(Double.parseDouble(loadFactor));
                }
            }

            String beginLoadFactor = (String) configValues.get("beginLoadFactor");

            // Custom begin load factors
            m_beginLoadFactors = new ArrayList<>();
            String[] beginLoadFactorAsStr = beginLoadFactor.split(",");
            for (String beginLoadFactorVals :
                    beginLoadFactorAsStr) {
                m_beginLoadFactors.add(Double.parseDouble(beginLoadFactorVals));
            }

            logger.debug("[Config.loadConfig] initial load factor is " + initialLoadFactor);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.edge.Runtime;

// Stores grouping output for S2SProbe and T2TProbe queries
public class SrcClusterStatsKryo implements IData {
    // Stores the grouping key
    private int m_srcIp;

    // Stores max rtt value
    private float m_maxRtt;

    // Stores min rtt value
    private float m_minRtt;

    // Stores avg rtt value
    private float m_avgRtt;
    private int m_seqNum;
    private long m_timeQueued;
    int m_count;

    public int getCount() {
        return m_count;
    }

    public void setCount(int count) {
        m_count = count;
    }

    public void setSrcCluster(int srcCluster) {
        m_srcIp = srcCluster;
    }

    public int getSrcCluster() {
        return m_srcIp;
    }

    public float getMaxRtt() {
        return m_maxRtt;
    }

    public float getMinRtt() {
        return m_minRtt;
    }

    public float getAvgRtt() {
        return m_avgRtt;
    }

    public int getSeqNum() {
        return m_seqNum;
    }

    public int getPayloadInBytes() {
        return Runtime.SIZE_OF_INT + (3 * Runtime.SIZE_OF_FLOAT);
    }

    public void setSeqNum(int seqNum) {
        m_seqNum = seqNum;
    }

    public void setMaxRtt(float maxRtt) {
        m_maxRtt = maxRtt;
    }

    public void setMinRtt(float minRtt) {
        m_minRtt = minRtt;
    }

    public void setAvgRtt(float avgRtt) {
        m_avgRtt = avgRtt;
    }

    public void resetQueueTime() {
        m_timeQueued = System.currentTimeMillis();
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - m_timeQueued);
    }

    public boolean isWaterMark() {
        return (this.m_srcIp == Integer.MIN_VALUE);
    }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, this);
    }

    public IData getEntity() {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getGroupingKey() {
        return m_srcIp;
    }

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for SrcClusterStatsKryo class");
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for SrcClusterStatsKryo class");
    }

    public Integer getGroupingValue() {
        return (int)m_avgRtt;
    }

    public void setWatermarkMarker() {
        m_srcIp = Integer.MIN_VALUE;
    }

    public void setGroupingKey(int key) {
        m_srcIp = key;
    }

    public void setEntity(IData data) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinKey() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setJoinKey(int key) {
        throw new UnsupportedOperationException();
    }

    public void setJoinValue(int value) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinValue() {
        // No op
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return m_seqNum + "," + m_srcIp + "," + m_avgRtt + "," +
                m_maxRtt + "," + m_minRtt;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }

    public String getTypeAsString() {
        return "SrcClusterStatsKryo";
    }

    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }

    public boolean isSubEpochMarker() {
        return (this.m_srcIp == Integer.MAX_VALUE);
    }

    public void setSubEpochMarker() {
        this.m_srcIp = Integer.MAX_VALUE;
    }

    public Integer getFilterPredVal() { return m_srcIp; }
}

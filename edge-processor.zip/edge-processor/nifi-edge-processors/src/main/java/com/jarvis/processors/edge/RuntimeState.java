package com.jarvis.processors.edge;

// Denotes the Jarvis runtime state
public enum RuntimeState {
    // non-congested/non-idle phase
    STABLE,

    // Idle or congested phase
    ADAPT_NOPROBING,

    // Profiling phase
    PROFILE,

    // Cool down phase after adaptation, before another adaptation can be triggered
    COOL_DOWN,
}

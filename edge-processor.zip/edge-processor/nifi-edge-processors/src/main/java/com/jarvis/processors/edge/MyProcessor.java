/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jarvis.processors.edge;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.*;
import com.jarvis.processors.edge.workloads.*;
import org.apache.commons.io.FileUtils;
import org.apache.nifi.annotation.behavior.ReadsAttribute;
import org.apache.nifi.annotation.behavior.ReadsAttributes;
import org.apache.nifi.annotation.behavior.WritesAttribute;
import org.apache.nifi.annotation.behavior.WritesAttributes;
import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.SeeAlso;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.annotation.lifecycle.OnScheduled;
import org.apache.nifi.components.PropertyDescriptor;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.*;
import org.apache.nifi.processor.exception.ProcessException;
import org.apache.nifi.processor.util.StandardValidators;

import java.io.*;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

// Entry point for MiNiFi to execute the Jarvis system
@Tags({"example"})
@CapabilityDescription("Provide a description")
@SeeAlso({})
@ReadsAttributes({@ReadsAttribute(attribute="", description="")})
@WritesAttributes({@WritesAttribute(attribute="", description="")})
public class MyProcessor extends AbstractSessionFactoryProcessor {

    public static final PropertyDescriptor MY_PROPERTY = new PropertyDescriptor
            .Builder().name("MY_PROPERTY")
            .displayName("My property")
            .description("Example Property")
            .required(true)
            .addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
            .build();

    // MiNiFi dataflow connector to send data over network to stream processor
    public static final Relationship MY_RELATIONSHIP = new Relationship.Builder()
            .name("MY_RELATIONSHIP")
            .description("Example relationship")
            .build();

    // [Deprecated] MiNiFi dataflow connector to send drained data from data source over network
    public static final Relationship MY_RELATIONSHIP_1 = new Relationship.Builder()
            .name("MY_RELATIONSHIP_1")
            .description("Example relationship 1")
            .build();

    private List<PropertyDescriptor> descriptors;
    private Set<Relationship> relationships;

    // List of first control proxies (for multiple queries)
    IControlProxy m_firstCp[];

    // List of workloads (for multiple queries)
    Workload[] m_workload;
    public static Object m_sessionFactoryLock;
    public static ProcessSessionFactory m_sessionFactory;

    // End time for warm up period in ms
    long m_warmUpEndTimeInMs;

    // Stores the latest sequence number for watermark sent to query
    public AtomicInteger m_waterMarkSeqNum = new AtomicInteger(0);

    // Flag to indicate if MiNiFi processor initialized with Jarvis code
    private AtomicBoolean m_processorInitialized = new AtomicBoolean(false);

    // Flag to indicate if input stream is cached or not
    private AtomicBoolean m_inputCached = new AtomicBoolean(false);

    // Cache of input stream records to be read from memory as the stream progresses
    List<IData> m_extractedRecordsCache = new ArrayList<>();

    // Data type of input stream records
    String m_cachedDataType;

    // Flag to indicate if warm up phase is currently active
    private boolean m_isWarmUpPhase = true;

    // Stores requests triggered by timer in MiNiFi processor, to indicate beginning of new epoch
    LinkedBlockingQueue<Integer> m_localReqQueue = new LinkedBlockingQueue<>();

    // Initialize MiNiFi processor
    @Override
    protected void init(final ProcessorInitializationContext context) {
        final List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();
        descriptors.add(MY_PROPERTY);
        this.descriptors = Collections.unmodifiableList(descriptors);

        final Set<Relationship> relationships = new HashSet<Relationship>();
        relationships.add(MY_RELATIONSHIP);
        relationships.add(MY_RELATIONSHIP_1);
        this.relationships = Collections.unmodifiableSet(relationships);
        // TODO: need to shutdown executor service
    }

    @Override
    public Set<Relationship> getRelationships() {
        return this.relationships;
    }

    @Override
    public final List<PropertyDescriptor> getSupportedPropertyDescriptors() {
        return descriptors;
    }

    @OnScheduled
    public void onScheduled(final ProcessContext context) {
        initializeFromConfig(context.getProperty(MY_PROPERTY).getValue());
    }

    // Read config and initialize workload/first control proxies
    private void initializeFromConfig(String configFilePath) {
        if(!m_processorInitialized.get()) {
            Config.loadConfig(getLogger(), configFilePath);
            JarvisLogger.initialize(getLogger());

            JarvisLogger.info("[MyProcessor.initializeFromConfig] Running onScheduled initialization code");
            m_sessionFactoryLock = new Object();
            m_workload = new Workload[Config.NUMBER_OF_MULTIQUERY_INSTANCES];
            m_firstCp = new IControlProxy[Config.NUMBER_OF_MULTIQUERY_INSTANCES];
            CloudUploader cloudUploader = new CloudUploader(MY_RELATIONSHIP);
            for(int i = 0; i < Config.NUMBER_OF_MULTIQUERY_INSTANCES; i++) {
                switch (Config.WORKLOAD) {
                    case "PingMeshQuery1":
                        m_workload[i] = new PingMeshQuery1(cloudUploader);
                        break;
                    case "PingMeshQuery1HalfSrc":
                        m_workload[i] = new PingMeshQuery1HalfSrc(cloudUploader);
                        break;
                    case "WordCountQuery1":
                        m_workload[i] = new WordCountQuery1(cloudUploader);
                        break;
                    case "ChainMapQuery1":
                        m_workload[i] = new ChainMapQuery1(cloudUploader);
                        break;
                    case "AllSpQuery":
                        m_workload[i] = new AllSpQuery(cloudUploader);
                        break;
                    case "JoinProfile1":
                        m_workload[i] = new JoinProfile1(cloudUploader);
                        break;
                    case "ToRIpQueryStatsSummary":
                        m_workload[i] = new ToRIpQueryStatsSummary(cloudUploader);
                        break;
                    case "ToRIpQueryCountProbe":
                        m_workload[i] = new ToRIpQueryCountProbe(cloudUploader);
                        break;
                    case "LogAnalyticsQuery":
                        m_workload[i] = new LogAnalyticsQuery(cloudUploader);
                        break;
                    case "AllSpLogAnalyticsQuery":
                        m_workload[i] = new AllSpLogAnalyticsQuery(cloudUploader);
                        break;
                    case "FilterSrcLogAnalyticUtilQuery":
                        m_workload[i] = new FilterSrcLogAnalyticUtilQuery(cloudUploader);
                        break;
                    default:
                        throw new UnsupportedOperationException("Unknown workload");
                }

                m_firstCp[i] = m_workload[i].getFirstCp();
            }

            // TODO: need to shutdown executor service
            m_warmUpEndTimeInMs = System.currentTimeMillis() + (Config.WARM_UP_TIME_SECONDS * 1000);
            JarvisLogger.info("[MyProcessor.init] warm up end time is " + m_warmUpEndTimeInMs);
            Thread t1 = new Thread(new Runnable() {
                @Override
                public void run() {
                    dataStreamGenerator();
                }
            });
            t1.start();
            m_processorInitialized.set(true);
        }
    }

    // Triggers new epoch to begin when timer in MiNiFi processor executes
    @Override
    public final void onTrigger(ProcessContext context, ProcessSessionFactory sessionFactory) throws ProcessException {
        ProcessSession session;
        synchronized (m_sessionFactoryLock) {
            m_sessionFactory = sessionFactory;
            session = m_sessionFactory.createSession();
        }

        try {
            m_localReqQueue.put(0);
            // Note that this is only used as trigger to process same flowfile (from disk/cached).
            // So dummy file is never used
            FlowFile dummyFile = session.get();
            if(dummyFile != null) {
                session.remove(dummyFile);
            }

            session.commit();
        } catch (InterruptedException ex) {
            JarvisLogger.info("[MyProcessor.onTrigger] [ERROR] Could not put new scheduling request in queue");
        } catch (Throwable var5) {
            session.rollback(true);
            throw var5;
        }
    }

    // Get the next data item in stream by deserialziing data from input stream stored as
    // Kryo object, to send it to query for execution
    private IData getObjectToEnqueue(Kryo kryo, Input input, String datatypeInFlowfile) {
        IData objectToEnqueue;
        switch (datatypeInFlowfile) {
            case "PingMeshKryo":
                IData kryoObjectRead = kryo.readObject(input, PingMeshKryo.class);
                objectToEnqueue = new PingMeshKryoWithTime();
                objectToEnqueue.setEntity(kryoObjectRead);
                break;
            case "WordCountEntity":
                String lineRead = kryo.readObject(input, String.class);
                objectToEnqueue = new WordCountEntity(lineRead, 1);
                break;
            default:
                throw new UnsupportedOperationException("Cannot get object to enqueue for: " +
                        " input type: " + datatypeInFlowfile);
        }

        return objectToEnqueue;
    }

    // Get new watermark for the input data type
    private IData getWatermarkMarker(String inputDataTypeInFlowfile) {
        IData watermarkMarker;
        switch (inputDataTypeInFlowfile) {
            case "WordCountEntity":
                watermarkMarker = new WordCountEntity();
                watermarkMarker.setWatermarkMarker();
                break;
            case "PingMeshKryo":
                PingMeshKryo waterMark = new PingMeshKryo();
                waterMark.setWatermarkMarker();
                watermarkMarker = new PingMeshKryoWithTime();
                watermarkMarker.setEntity(waterMark);
                break;
            default:
                throw new UnsupportedOperationException("Trying to read input data type that is not supported");
        }
        return watermarkMarker;
    }

    // Generates the data stream records, begins a new epoch whenever MiNiFi timer is triggered
    // to start a new epoch. No flowfile expected. The input records are read directly from disk
    // by this processor.
    public void dataStreamGenerator() {
        try {
            int warmUpRecordCount = 0;
            boolean workloadInitialized = false;
            while(true) {
                m_localReqQueue.take();
                int readRecords = 0;
                long startExtract = System.currentTimeMillis();
                if (!m_inputCached.get()) {
                    Kryo kryo = new Kryo();
                    kryo.register(String.class);
                    kryo.register(Integer.class);
                    kryo.register(PingMeshKryo.class);
                    kryo.register(PingMeshKryoWithTime.class);
                    kryo.register(WordCountEntity.class);

                    System.setProperty("rx.ring-buffer.size", "150000");
                    JarvisLogger.info("[MyProcessor.extractRecordsCachedDeserialized] Reading flowfile from disk for first time");
                    File file = new File(Config.INPUT_FILE);
                    byte[] recordsFromFlowFile = FileUtils.readFileToByteArray(file);
                    Input input = new Input(recordsFromFlowFile);
                    m_cachedDataType = (String) kryo.readObject(input, String.class);
                    int numRecordsFlowFile = (Integer) kryo.readObject(input, Integer.class);
                    int recordCountInRegularPhase = numRecordsFlowFile/Config.REGULAR_INPUT_SCALE_FACTOR;
                    warmUpRecordCount = (int) ((double) numRecordsFlowFile/(double) Config.WARM_UP_INPUT_SCALE_FACTOR);
                    IData objectToEnqueue = getObjectToEnqueue(kryo, input, m_cachedDataType);
                    int outputGroupCount = (int) (Config.GROUPING_REDUCTION_FRACTION * recordCountInRegularPhase);
                    if(!workloadInitialized) {
                        for(int i = 0; i < Config.NUMBER_OF_MULTIQUERY_INSTANCES; i++) {
                            m_workload[i].beginWorkload(objectToEnqueue.getPayloadInBytes());
                        }
                        workloadInitialized = true;
                    }

                    putInAllQueues(objectToEnqueue, false);
                    m_extractedRecordsCache.add(objectToEnqueue);

                    int read = 1;
                    if(m_isWarmUpPhase && System.currentTimeMillis() > m_warmUpEndTimeInMs) {
                        JarvisLogger.info("[MyProcessor.extractRecordsCachedDeserialized] resetting m_isWarmUpPhase " +
                                "at " + System.currentTimeMillis());
                        m_isWarmUpPhase = false;
                    }

                    while (read < recordCountInRegularPhase) {
                        objectToEnqueue = getObjectToEnqueue(kryo, input, m_cachedDataType);
                        if(objectToEnqueue.getGroupingKey() <= outputGroupCount) {
                            if (Config.IS_TEST_PHASE || read < warmUpRecordCount || !m_isWarmUpPhase) {
                                putInAllQueues(objectToEnqueue, false);
                            }

                            m_extractedRecordsCache.add(objectToEnqueue);
                            read++;
                        }
                    }

                    input.close();
                    JarvisLogger.info("[MyProcessor.extractRecordsCachedDeserialized] total number of records read is: " + read);
                    m_inputCached.set(true);
                } else {
                    if(m_isWarmUpPhase && System.currentTimeMillis() > m_warmUpEndTimeInMs) {
                        JarvisLogger.info("[MyProcessor.extractRecordsCachedDeserialized] warm up time ended at " +
                                System.currentTimeMillis());
                        m_isWarmUpPhase = false;
                    }

                    for (IData record : m_extractedRecordsCache) {
                        if(Config.IS_TEST_PHASE || readRecords < warmUpRecordCount || !m_isWarmUpPhase) {
                            putInAllQueues(record, false);
                            readRecords++;
                        } else {
                            break;
                        }
                    }
                }

                IData watermarkMarker = getWatermarkMarker(m_cachedDataType);
                watermarkMarker.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                putInAllQueues(watermarkMarker, true);
                long endExtract = System.currentTimeMillis();
                JarvisLogger.info("[MyProcessor] Putting watermark into first Cp. Extraction: " + (endExtract - startExtract) +
                        ", is warm up: " + m_isWarmUpPhase + ", read recordS:" + readRecords + ", warmup record count:" +
                        " " + warmUpRecordCount);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JarvisLogger.info("[MyProcessor.extractRecordsCached] " +
                    "Exception when reading records: " + e.toString());
            System.out.println("File not found exception");
        }
    }

    // Put the data item into all the first control proxies
    public void putInAllQueues(IData objectToEnqueue, boolean isWatermark) {
        for(int i = 0; i < Config.NUMBER_OF_MULTIQUERY_INSTANCES; i++) {
            if(isWatermark) {
                m_firstCp[i].putWaterMark(objectToEnqueue);
            } else {
                m_firstCp[i].put(objectToEnqueue);
            }
        }
    }
}

package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.JarvisLogger;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

// Abstract class which contains functionality to implement query operators in Jarvis
public abstract class CustomOperator implements  Runnable {

    // Incoming queue for operator
    IControlProxy m_currentQueue;

    // Outgoing downstream queue for operator
    IControlProxy m_nextQueue;

    // RxJava subject for processing records (defines the query logic)
    io.reactivex.subjects.PublishSubject<IData> m_subject;

    // Profiling information
    long m_totalProcessingTime = 0;
    long m_maxQueueTime;
    float m_avgProcessingTime;
    long m_dataflowBuildDur;
    Integer[] m_numOutRecords = {0};
    protected long m_currentEpochRecordCount = 0;
    protected long m_recentEpochRecordCount = 0;

    // Operator ID
    protected int m_opId;
    Random randGen = new Random();

    // Reduction ratio enforced, for debugging
    protected double m_reductionRatio = 1;

    // Epoch related information
    AtomicInteger m_waterMarkSeqNum = new AtomicInteger(0);
    protected AtomicBoolean m_subEpochComplete = new AtomicBoolean(false);
    protected long m_startEpoch;
    private int m_epochCount = 0;
    protected long m_recentEpochDuration = 0;
    protected long m_recentEpochEndTime = 0;

    public CustomOperator(int opId, IControlProxy currentQueue, double reductionRatio) {
        m_opId = opId;
        m_currentQueue = currentQueue;
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_reductionRatio = reductionRatio;
    }

    // Implements the operator logic by composing one or more RxJava operators
    public abstract void setDataflow();

    // Sets downstream queue
    public abstract void setNextQueue(IControlProxy queue);

    // Profile information
    public abstract double getProfileEpochStartTime();
    public abstract double getProfileEpochEndTime();

    // Setter for epoch record count
    public void setRecentEpochRecordCount(long recordCount) {
        m_recentEpochRecordCount = recordCount;
    }

    // Getter for epoch record count
    public long getRecentEpochRecordCount() {
        return m_recentEpochRecordCount;
    }

    // Resets metrics at the end of an epoch
    protected void resetMetrics() {
        m_maxQueueTime = 0;
        m_avgProcessingTime = 0;
        m_dataflowBuildDur = 0;
        m_numOutRecords[0] = 0;
        m_totalProcessingTime = 0;
        m_currentEpochRecordCount = 0;
    }

    // Getter for operator Id
    public int getOpId() {
        return m_opId;
    }

    // Run thread for continuously processing records from incoming queue and executing operator computation
    public void run() {
        boolean markerFound, subEpochFound;
        while(true) {
            try {
                IData readObj;
                markerFound = false;
                subEpochFound = false;
                setDataflow();
                while (!markerFound) {
                    readObj = m_currentQueue.take();
                    if(m_currentEpochRecordCount == 0) {
                        m_startEpoch = System.currentTimeMillis();
                    }

                    if (readObj != null) {
                        if(readObj.isWaterMark() || readObj.isSubEpochMarker()) {
                            if(readObj.isSubEpochMarker()) {
                                subEpochFound = true;
                                m_subEpochComplete.set(true);
                            }

                            markerFound = true;
                            setRecentEpochRecordCount(m_currentEpochRecordCount);
                            m_subject.onComplete();
                        } else {
                            m_subject.onNext(readObj);
                            m_currentEpochRecordCount++;
                        }
                    }
                }

                m_epochCount = m_epochCount + (subEpochFound ? 0 : 1);

                if(!subEpochFound) {
                    JarvisLogger.debug("[CustomOperator.run] Total processing time: " + m_totalProcessingTime +
                            ", avg processing time: " + m_avgProcessingTime + ", dataflow ubild dur: " + m_dataflowBuildDur +
                            ", num records=" + m_numOutRecords[0]);
                    resetMetrics();
                }
            } catch (Exception ex) {
                JarvisLogger.debug("[CustomOperator.run] Exception waiting: " + ex.toString());
                ex.printStackTrace();
            }
        }
    }
}

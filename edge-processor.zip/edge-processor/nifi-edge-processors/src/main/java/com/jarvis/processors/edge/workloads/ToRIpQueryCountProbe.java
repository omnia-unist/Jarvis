package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.*;
import com.jarvis.processors.edge.operators.CustomFilterOperator;
import com.jarvis.processors.edge.operators.CustomGroupbyCountOnly;
import com.jarvis.processors.edge.operators.CustomJoinOperator;
import com.jarvis.processors.edge.operators.CustomOperator;

// Implements T2TProbe query with count information for aggregation
public class ToRIpQueryCountProbe extends Workload {

    public ToRIpQueryCountProbe(CloudUploader cloudUploader) {
        super();
        if(Config.JOIN_TABLE_SIZE == 0) {
            throw new UnsupportedOperationException("Join table size is 0 for Join profiling workload");
        }

        m_numOperators = 3;

        m_dataTypesAsStrings = new String[m_numOperators+1];
        m_dataTypesAsStrings[0] = "PingMeshKryo";
        m_dataTypesAsStrings[1] = "PingMeshKryo";
        m_dataTypesAsStrings[2] = "JoinResult";
        m_dataTypesAsStrings[3] = "ToRCountProbe";

        classesToRegister = new IData[m_numOperators+1];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();
        classesToRegister[2] = new JoinResult();
        classesToRegister[3] = new ToRCountProbe();

        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, false, true}, cloudUploader);

        m_customOperators[0] = new CustomFilterOperator(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_internalCps[0]);

        m_customOperators[1] = new CustomJoinOperator(1, m_internalCps[0]);
        m_customOperators[1].setNextQueue(m_internalCps[1]);

        m_customOperators[2] = new CustomGroupbyCountOnly(2, m_internalCps[1]);
        m_customOperators[2].setNextQueue(m_finalCp);
    }
}

package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.data.SrcClusterStatsKryo;
import com.jarvis.processors.edge.operators.CustomFilterOperator;
import com.jarvis.processors.edge.operators.CustomFullGroupbyOperator;
import com.jarvis.processors.edge.operators.CustomOperator;

// Implements S2SProbe query
public class PingMeshQuery1 extends Workload {

    public PingMeshQuery1(CloudUploader cloudUploader) {
        super();

        m_dataTypesAsStrings = new String[3];
        m_dataTypesAsStrings[0] = "PingMeshKryo";
        m_dataTypesAsStrings[1] = "PingMeshKryo";
        m_dataTypesAsStrings[2] = "SrcClusterStatsKryo";

        classesToRegister = new IData[3];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();
        classesToRegister[2] = new SrcClusterStatsKryo();

        m_numOperators = 2;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, true}, cloudUploader);

        m_customOperators[0] = new CustomFilterOperator(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_internalCps[0]);

        m_customOperators[1] = new CustomFullGroupbyOperator(1, m_internalCps[0]);
        m_customOperators[1].setNextQueue(m_finalCp);
    }
}

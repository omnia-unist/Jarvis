package com.jarvis.processors.edge.controlproxy;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.data.IData;

import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Control proxy for the operator queue of first operator in query, without any adaptation logic.
// Coordinates the execution of all downstream control proxies.
public class FirstControlProxyNoAdapt implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Kryo m_kryo;
    AtomicBoolean queueDrained = new AtomicBoolean(false);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);

    // Control proxy variables
    volatile double m_probSendingToEdge = 1;
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    private AtomicInteger m_totalInputRecords;
    boolean m_beginStreaming = true;
    IControlProxy m_outputQueue;
    IControlProxy[] m_internalCps;

    AtomicBoolean m_drainedAllQueues;
    private Object m_synchronizeWmLock;

    BloomFilter m_bloomFilter;
    AtomicInteger m_latestWatermarkSeqNum = new AtomicInteger(-1);

    public FirstControlProxyNoAdapt(IData[] classesToRegister,
                                    IControlProxy outputQueue,IControlProxy[] internalCps) {
        m_queueId = 0;
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }

        m_kryo.register(Integer.class);
        m_kryo.register(String.class);

        m_startEpochTimer.set(System.currentTimeMillis());
        m_drainedAllQueues = new AtomicBoolean(false);
        m_outputQueue = outputQueue;
        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
        m_internalCps = internalCps;

        m_synchronizeWmLock = new Object();
        // We are not considering hot keys in this branch code
        // loadBloomFilters();
    }

    // We are not considering hot keys in this branch code
    private void loadBloomFilters() {
        m_bloomFilter = BloomFilter.create(Funnels.byteArrayFunnel(), 1000);
        BigInteger val = new BigInteger("1032");
        m_bloomFilter.put(val.toByteArray());
        BigInteger val1 = new BigInteger("433");
        JarvisLogger.debug("Bloomg filter: " + m_bloomFilter.mightContain(val1.toByteArray()));
    }

    public void printAndResetQueueDebugStats() {
        // No-op
    }

    // Reads the output queue for first operator and sends records to next downstream operator
    public IData take() {
        IData takenVal = null;
        try{
            takenVal = queue.take();
            if (takenVal.isWaterMark()) {
                JarvisLogger.debug(m_queueId + " [FirstControlProxyNoAdapt.take] After reading outside of lock"
                );

                // Reset the epoch size to signify end of current epoch processing by operator
                m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
                m_currentEpochDataSizeSentToEdge = 0;
                JarvisLogger.debug(m_queueId + " [FirstControlProxyNoAdapt.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge);
                JarvisLogger.info("[FirstControlProxyNoAdapt.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge);
            } else {
                m_currentEpochDataSizeSentToEdge += takenVal.getPayloadInBytes();
            }

        } catch (Exception ex) {
            JarvisLogger.debug("[FirstControlProxyNoAdapt.take] Exception in dequeueuing " + ex.toString());
            ex.printStackTrace();
        }

        return takenVal;
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void put(IData item) {
        try {
            if (m_beginStreaming || lastPutWasWatermark.get()) {
                synchronized(m_synchronizeWmLock) {
                    if (m_beginStreaming || lastPutWasWatermark.get()) {
                        m_beginStreaming = false;
                        int nextWatermarkSeqNum = m_latestWatermarkSeqNum.get() + 1;
                        JarvisLogger.info(m_queueId + "[FirstControlProxyNoAdapt.put] New epoch entering, whose epoch number" +
                                " i.e. watermark seq num will be: " + nextWatermarkSeqNum);
                        JarvisLogger.debug(m_queueId + " [FirstControlProxyNoAdapt.put] Queue size on put " + size() +
                                ", records drianed size: "
                                + m_recentEpochRecordsDrainedSize.get());

                        m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
                        m_startEpochTimer.set(System.currentTimeMillis());
                        m_totalInputRecords.set(0);
                        JarvisLogger.debug(m_queueId + " [FirstControlProxyNoAdapt.put] Done waiting for Runtime. Going to add " +
                                "records to queue. ");
                        JarvisLogger.info("[FirstControlProxyNoAdapt.put] Prob sending to edge is: " + m_probSendingToEdge);
                        lastPutWasWatermark.set(false);
                    }
                }
            }

            m_totalInputRecords.getAndIncrement();
            queue.put(item);
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void putWaterMark(IData watermark) {
        try {
            queue.put(watermark);
            queueDrained.set(false);
            m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
            m_latestWatermarkSeqNum.set(watermark.getSeqNum());
            JarvisLogger.debug(m_queueId +
                    " and " + " size is " + size() + ", watermark seq num: " +
                    watermark.getSeqNum());
            JarvisLogger.info(m_queueId + " [FirstControlProxyNoAdapt.putWaterMark] Watermark seen with seq num: " + watermark.getSeqNum());

            lastPutWasWatermark.set(true);
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public int size() {
        return queue.size();
    }


    public long getRecentEpochDuration() {
        return m_recentEpochTimeInMs.get();
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }

    public void waitForWatermarkWithSeqNum(int seqNum) {
        // No op
        throw new UnsupportedOperationException();
    }

    public byte[] getByteArrayOutputStreamContent() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void reset() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public long getRecentIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public int getRecentRecordsDrainedSize() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public int getRecentRecordsDiscardedSize() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void setProbSendingToEdge(double probSendingToEdge) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public IdleTimeStats getIdleTimerVal() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public boolean tryDrainTillWatermark() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void enableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void disableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public IdleTimeStats getRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void resetIdleTimer() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void setCurrRuntimeState(RuntimeState state) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public IdleTimeStats getFinalCpRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }
}

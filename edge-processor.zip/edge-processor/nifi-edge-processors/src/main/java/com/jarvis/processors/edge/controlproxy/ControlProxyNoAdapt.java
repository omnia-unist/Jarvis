package com.jarvis.processors.edge.controlproxy;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.data.IData;
import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Intermediate control proxy that does not support adaptation
public class ControlProxyNoAdapt implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Output m_networkOutput;
    Kryo m_kryo;
    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);

    // Control proxy variables
    volatile double m_probSendingToEdge = 1;
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    private AtomicInteger m_totalInputRecords;

    private Object m_synchronizeWmLock;
    AtomicBoolean m_drainedAllQueues;
    AtomicBoolean m_previousTakeWasWm = new AtomicBoolean(false);
    private AtomicInteger m_debugRecordsTaken = new AtomicInteger(0);

    BloomFilter m_bloomFilter;

    public ControlProxyNoAdapt(int queueId, IData[] classesToRegister) {

        m_queueId = queueId;
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }
        m_kryo.register(Integer.class);
        m_kryo.register(String.class);

        m_networkOutputStream = new ByteArrayOutputStream();
        m_networkOutput = new Output(m_networkOutputStream);
        m_startEpochTimer.set(System.currentTimeMillis());
        m_drainedAllQueues = new AtomicBoolean(false);
        m_totalInputRecords = new AtomicInteger(0);
        m_synchronizeWmLock = new Object();
        // We are not considering hot keys in this branch code
        // loadBloomFilters();
    }

    // Unsupported code: used for prioritizing processing of hot keys on data source which
    // Jarvis does not currently support yet.
    private void loadBloomFilters() {
        m_bloomFilter = BloomFilter.create(Funnels.byteArrayFunnel(), 1000);
        BigInteger val = new BigInteger("1032");
        m_bloomFilter.put(val.toByteArray());
        BigInteger val1 = new BigInteger("433");
        JarvisLogger.debug("Bloomg filter: " + m_bloomFilter.mightContain(val1.toByteArray()));
    }

    public long getRecentEpochDuration() {
        return m_recentEpochTimeInMs.get();
    }

    // Reads the operator queue and sends records to next downstream operator
    public IData take() {
        IData takenVal = null;
        try{
            takenVal = queue.take();
            if (takenVal.isWaterMark()) {
                // Reset the epoch size to signify end of current epoch processing by operator
                m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
                m_currentEpochDataSizeSentToEdge = 0;
                JarvisLogger.debug(m_queueId + " [ControlProxyNoAdapt.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge);
                JarvisLogger.info(m_queueId + " [ControlProxyNoAdapt.take] Size of recent window processed is " +
                        m_prevEpochDataSizeSentToEdge + ", num of records: " + m_debugRecordsTaken.get());
                m_debugRecordsTaken.set(0);
                m_previousTakeWasWm.set(true);
            } else {
                m_currentEpochDataSizeSentToEdge += takenVal.getPayloadInBytes();
                m_debugRecordsTaken.getAndIncrement();
            }

        } catch (Exception ex) {
            JarvisLogger.debug("[SyncQueue.take] Exception in dequeueuing " + ex.toString());
            ex.printStackTrace();
        }

        return takenVal;
    }

    public void printAndResetQueueDebugStats() {
        // No-op
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator.
    // put and putWaterMark have to run on a single thread
    public void put(IData item) {
        try {
            if(lastPutWasWatermark.get()) {
                synchronized (m_synchronizeWmLock) {
                    if(lastPutWasWatermark.get()) {
                        m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
                        m_startEpochTimer.set(System.currentTimeMillis());

                        m_totalInputRecords.set(0);
                        JarvisLogger.info("[ControlProxyNoAdapt.put] queueId:" + m_queueId + ", prob sending to edge is: "
                                + m_probSendingToEdge + ", recent epoch records drained size: " +
                                        m_recentEpochRecordsDrainedSize.get());
                        lastPutWasWatermark.set(false);
                    }
                }
            }

            m_totalInputRecords.getAndIncrement();
            queue.put(item);
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    // put, putWaterMark have to run on a single thread
    public void putWaterMark(IData watermark) {
        try {
            waterMarkCountInQueue.incrementAndGet();
            queue.put(watermark);
            m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
            JarvisLogger.info(m_queueId + " [ControlProxyNoAdapt.putWaterMark] Watermark count in putWaterMark " +
                    waterMarkCountInQueue.get() + " and num of records is " + m_totalInputRecords.get() +
                    ", watermark seq num: " + watermark.getSeqNum());
            lastPutWasWatermark.set(true);
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public int size() {
        return queue.size();
    }

    // Gets the most recent payload size for network data sent from data source
    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }

    public void waitForWatermarkWithSeqNum(int seqNum) {
        // No op
        throw new UnsupportedOperationException();
    }

    public byte[] getByteArrayOutputStreamContent() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void reset() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public long getRecentIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public int getRecentRecordsDrainedSize() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public int getRecentRecordsDiscardedSize() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void setProbSendingToEdge(double probSendingToEdge) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }
//    void enableSendingToEdgeFlagOnly();

    //    boolean drainRecord();
    public IdleTimeStats getIdleTimerVal() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public boolean tryDrainTillWatermark() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void enableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void disableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public IdleTimeStats getRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void resetIdleTimer() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public void setCurrRuntimeState(RuntimeState state) {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

    public IdleTimeStats getFinalCpRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Not supported in no adapt queues");
    }

}

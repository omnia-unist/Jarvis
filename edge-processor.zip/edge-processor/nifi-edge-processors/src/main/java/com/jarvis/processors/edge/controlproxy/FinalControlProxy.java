package com.jarvis.processors.edge.controlproxy;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.IdleTimeStats;
import com.jarvis.processors.edge.JarvisLogger;
import com.jarvis.processors.edge.RuntimeState;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.SrcClusterStatsKryo;
import org.apache.nifi.processor.Relationship;

import java.io.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Final control proxy in the query, which sends data to CloudUploader for network transfer from the data source
public class FinalControlProxy implements IControlProxy {
    ByteArrayOutputStream m_outputStream;
    Output m_output;
    Kryo m_kryo;
    AtomicInteger m_size;
    CloudUploader m_cloudUploader;

    int tempDebugNumRecords = 0;

    public volatile double m_prevWindowDataSizeSentToEdge = 0;
    double m_currentWindowDataSizeSentToEdge = 0;
    private boolean m_watermarkObserved;
    private Object m_waterMarkInExitLock;
    private Object m_idleTimeStatsUpdatesLock;
    private Integer m_recentWaterMarkSeqNum = -1;
    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
    String m_dataTypeAsString;
    boolean m_postStatefulOperator;
    int m_queueId;

    public FinalControlProxy(int queueId, IData[] classesToRegister, String dataTypeAsString, CloudUploader uploader,
                             boolean postStatefulOperator) {
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }

        m_kryo.register(Integer.class);
        m_kryo.register(String.class);


        m_dataTypeAsString = dataTypeAsString;
        m_outputStream = new ByteArrayOutputStream();
        m_output = new Output(m_outputStream);
        m_cloudUploader = uploader;
        m_waterMarkInExitLock = new Object();
        m_idleTimeStatsUpdatesLock = new Object();
        m_watermarkObserved = false;
        m_postStatefulOperator = postStatefulOperator;
        m_queueId = queueId;
        addMetadataToFlowfile();
    }

    public IdleTimeStats getFinalCpRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Final CP cannot get recent adapt idle time stats directly");
    }

    public double getRecentPayloadSizeOnEdge() {
        return m_prevWindowDataSizeSentToEdge;
    }

    // Adds records into the payload for network transfer from data source to stream processor.
    // API for upstream operator to send processed records over network
    public void put(IData item) {
        try {
            if(item.isSubEpochMarker()) {
                // Ignore subepoch markers
            } else {
                item.writeSelfToKryo(m_kryo, m_output);
                m_currentWindowDataSizeSentToEdge += item.getPayloadInBytes();
                tempDebugNumRecords++;
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
        }
    }

    // Adds metadata to the top of payload sent to stream processor.
    // Control proxy ID and data type of objects in payload are added, so the flowfile can be read easily and routed
    // on stream processor side
    private void addMetadataToFlowfile() {
        // The first thing we write is the control proxy ID and data type, so the flowfile can be read easily and routed
        // on stream processor side
        int nextCpQueue = -1;
        if(m_postStatefulOperator) {
            nextCpQueue = m_queueId - 1;
        }

        m_kryo.writeObject(m_output, nextCpQueue);
        m_kryo.writeObject(m_output, m_dataTypeAsString);
    }

    // Adds watermark to denote end of epoch before payload is transferred to stream processor
    public void putWaterMark(IData item) {
        try {
            item.writeSelfToKryo(m_kryo, m_output);
            byte[] epochContent = getByteArrayOutputStreamContent();
            this.reset();
            m_prevWindowDataSizeSentToEdge = m_currentWindowDataSizeSentToEdge;
            m_currentWindowDataSizeSentToEdge = 0;
            m_cloudUploader.sendToCloud(epochContent, item.getSeqNum());
            JarvisLogger.info("[FinalControlProxy.putWaterMark] Seen watermark in final queue with" +
                    " seq num: " + item.getSeqNum() + ", epoch number of records: " + tempDebugNumRecords +
                    ", Size of recent window in output queue is " + m_prevWindowDataSizeSentToEdge);
            tempDebugNumRecords=0;

            addMetadataToFlowfile();
            synchronized (m_waterMarkInExitLock) {
                synchronized (m_idleTimeStatsUpdatesLock) {
                    m_recentWaterMarkSeqNum = item.getSeqNum();
                    m_startIdleTimer.set(System.currentTimeMillis());
                }

                m_waterMarkInExitLock.notifyAll();
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in queueuing " + ex.toString());
        }
    }

    public byte[] getByteArrayOutputStreamContent() {
        try {
            m_output.flush();
            m_outputStream.flush();
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing output queue wrapper: " + ex.toString());
        }

        return m_outputStream.toByteArray();
    }

    public void reset() {
        m_outputStream.reset();
        m_output.reset();
    }

    public void clear() {
        try {
            m_outputStream.flush();
            m_output.flush();
            m_outputStream.reset();
            m_output.reset();
            m_size.set(0);
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
        }
    }

    public void printAndResetQueueDebugStats() {
        // No-op
    }

    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
        throw new UnsupportedOperationException("Runtime doesn't wait on final CP");
    }

    // First control proxy uses this API to wait for an epoch to have finished processing before starting to send
    // data from the next epoch into the query
    public void waitForWatermarkWithSeqNum(int seqNum) {
        try {
            JarvisLogger.info("[FinalControlProxy.waitForWatermarkWithSeqNum] waiting for watermark with seq num: "+
                    seqNum + ", watermark observed:" + m_watermarkObserved);
            synchronized (m_waterMarkInExitLock) {
                while (!((seqNum==-1) || (m_recentWaterMarkSeqNum >= seqNum))) {
                    m_waterMarkInExitLock.wait();
                }
            }

            JarvisLogger.info("[FinalControlProxy.waitForWatermarkWithSeqNum] Seq num seen is: " + seqNum);
        } catch (Exception ex) {
            JarvisLogger.debug("Unhandled exception when waiting for exit watermark: " + ex.toString());
        }
    }

    public IdleTimeStats getIdleTimerVal() {
        long recentWm, idleTimeVal;
        synchronized (m_idleTimeStatsUpdatesLock) {
            recentWm = m_recentWaterMarkSeqNum;
            idleTimeVal = m_startIdleTimer.getAndSet(Long.MAX_VALUE);
        }
        return new IdleTimeStats(idleTimeVal, recentWm);
    }

    public long getRecentIdleTime() {
        // No op
        throw new UnsupportedOperationException();
    }

    public int getRecentRecordsDrainedSize() {
        // No op
        throw new UnsupportedOperationException();
    }

    public long getRecentEpochDuration() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void enableSendingToEdge() {
        // No op
//        throw new UnsupportedOperationException();
    }

    public void resetIdleTimer() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setProbSendingToEdge(double probSendingToEdge) {
        // No op
        throw new UnsupportedOperationException();
    }

    public void enableSendingToEdgeFlagOnly() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void disableSendingToEdge() {
        // No op
        throw new UnsupportedOperationException();
    }

    public int getRecentRecordsDiscardedSize() {
        // No op
        throw new UnsupportedOperationException();
    }

    public boolean tryDrainTillWatermark() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setCurrRuntimeState(RuntimeState state) {
        // No op
        throw new UnsupportedOperationException();
    }

    public IdleTimeStats getRecentAdaptIdleTime() {
        // No op
        throw new UnsupportedOperationException();
    }

    public IData take() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void enableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Final control proxy shouldn't need to set " +
                "flag to drain queues immediately");
    }

    public void disableDrainQueuesAsap() {
        throw new UnsupportedOperationException("Final control proxy shouldn't need to unset " +
                "flag to drain queues immediately");
    }
}

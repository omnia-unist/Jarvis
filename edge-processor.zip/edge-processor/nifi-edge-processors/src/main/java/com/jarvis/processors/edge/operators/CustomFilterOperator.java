package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Filter operator used in S2SProbe and T2TProbe queries
public class CustomFilterOperator extends CustomOperator {

    PingMeshKryoWithTime m_waterMarkEntryWithTime;
    PingMeshKryoWithTime m_subEpochMarkerWithTime;

    public CustomFilterOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue,1);
        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
        PingMeshKryo waterMarkEntry = new PingMeshKryo();
        waterMarkEntry.setWatermarkMarker();
        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);

        m_subEpochMarkerWithTime = new PingMeshKryoWithTime();
        PingMeshKryo subEpochMarker = new PingMeshKryo();
        subEpochMarker.setSubEpochMarker();
        m_subEpochMarkerWithTime.setEntity(subEpochMarker);
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                filter(v -> Config.FILTER_OUT_ANOMALY == null ? (v.getFilterPredVal() == 0 || v.getFilterPredVal() != 0) :
                    (Config.FILTER_OUT_ANOMALY == true ? v.getFilterPredVal() == 0 : v.getFilterPredVal() != 0)).
                subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        if(!m_subEpochComplete.get()) {
                            m_waterMarkEntryWithTime.resetQueueTime();
                            JarvisLogger.debug(m_opId + " [CustomFilterOperator.onComplete] created watermark: " +
                                    m_waterMarkSeqNum.get());
                            m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                            m_recentEpochEndTime = System.currentTimeMillis();
                            m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                            JarvisLogger.debug("[CustomFilterOperator.onComplete] Thread ID is: " +
                                    Thread.currentThread().getId() + ", epoch duration is: " +
                                    m_recentEpochDuration);
                            JarvisLogger.info("[CustomFilterOperator.onComplete] LP Solver op id: " + m_opId
                                    + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount +
                                    ", watermark seq num is: " + m_waterMarkEntryWithTime.getSeqNum());
                            m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                        } else {
                            m_subEpochComplete.set(false);
                            m_nextQueue.put(m_subEpochMarkerWithTime);
                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            data.resetQueueTime();
                            m_numOutRecords[0]++;
                            m_nextQueue.put(data);
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}


package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

// Wrapper class for PingMesh record, which also contains queueing time for profiling
public class PingMeshKryoWithTime implements IData {
    private PingMeshKryo m_data;
    private long timeQueued;

    public int getCount() {
        return getEntity().getCount();
    }

    public String getGroupingKey(boolean all) {
        return getGroupingKey(all);
    }

    public void convertToLowerCase() {
        getEntity().convertToLowerCase();
    }

    public int getSeqNum() {
        return getEntity().getSeqNum();
    }

    public void setSeqNum(int seqNum) {
        getEntity().setSeqNum(seqNum);
    }

    public void setEntity(IData data) {
        m_data = (PingMeshKryo) data;
        resetQueueTime();
    }

    public IData getEntity() {
        return m_data;
    }

    public int getPayloadInBytes() {
        return getEntity().getPayloadInBytes();
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - timeQueued);
    }

    public void resetQueueTime() {
        timeQueued = System.currentTimeMillis();
    }

    public String toString() {
        return getEntity().toString();
    }

    public boolean isWaterMark() {
        return this.getEntity().isWaterMark();
    }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, (PingMeshKryo) this.getEntity());
    }

    public Integer getGroupingKey() {
        return getEntity().getGroupingKey();
    }

    public Integer getGroupingValue() {
        return getEntity().getGroupingValue();
    }

    public void setWatermarkMarker() { getEntity().setWatermarkMarker(); }

    public void setGroupingKey(int key) { getEntity().setGroupingKey(key); }

    public Integer getJoinKey() {
        return getEntity().getJoinKey();
    }

    public void setJoinKey(int key) {
        getEntity().setJoinKey(key);
    }

    public void setJoinValue(int value) {
        getEntity().setJoinValue(value);
    }

    public Integer getJoinValue() {
        return getEntity().getJoinValue();
    }

    public boolean isJoinMismatchMarker() {
        return getEntity().isJoinMismatchMarker();
    }

    public void setJoinMismatchMarker() {
        getEntity().setJoinMismatchMarker();
    }

    public boolean isSubEpochMarker() {
        return this.getEntity().isSubEpochMarker();
    }

    public void setSubEpochMarker() {
        this.getEntity().setSubEpochMarker();
    }

    public Integer getFilterPredVal() { return getEntity().getFilterPredVal(); }
}
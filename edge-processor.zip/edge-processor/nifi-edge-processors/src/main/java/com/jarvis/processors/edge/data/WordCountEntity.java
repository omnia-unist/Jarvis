package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

// Used to store string count information, used in LogAnalytics query
public class WordCountEntity implements IData  {
    public String m_stringEntity;
    public int m_count;
    public int m_seqNum;

    public int getCount() {
        return m_count;
    }

    public void convertToLowerCase() {
        m_stringEntity = m_stringEntity.trim().toLowerCase();
    }

    public WordCountEntity(String stringEntity, int count) {
        m_stringEntity = stringEntity;
        m_count = count;
        m_seqNum = 0;
    }

    public WordCountEntity() {
        m_stringEntity = "";
        m_count = 1;
        m_seqNum = 0;
    }

    public String toString() {
        return m_stringEntity;
    }

    public int getSeqNum() {
        return m_seqNum;
    }

    public void setSeqNum(int seqNum) { m_seqNum = seqNum; }

    public int getPayloadInBytes() {
            return m_stringEntity.getBytes().length;
    }

    public boolean isWaterMark() {
        return (this.m_stringEntity.equals("watermark"));
    }

    public Integer getGroupingKey() {
        return m_stringEntity.hashCode();
    }

    public Integer getGroupingValue() {
        return null;
    }

    public long getQueueTime() { return -1; }
    public void resetQueueTime() {}
    public IData getEntity() { return null; }
    public void setEntity(IData data) {
        m_stringEntity = data.toString();
    }

    public void setWatermarkMarker() { this.m_stringEntity = "watermark"; }

    public void setGroupingKey(int key) { this.m_stringEntity = null; }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, this);
    }

    public Integer getJoinKey() {
        return null;
    }

    public void setJoinKey(int key) {
        m_stringEntity ="null";
    }

    public void setJoinValue(int value) {
        m_stringEntity = null;
    }

    public Integer getJoinValue() {
        return null;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("WordCountLine doesn't have join marker");
    }

    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("WordCountLine doesn't have join marker");
    }

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for WordCountEntity class");
    }

    public boolean isSubEpochMarker() {
        return (this.m_stringEntity == "subepochMarker");
    }

    public void setSubEpochMarker() {
        m_stringEntity = "subepochMarker";
    }

    public Integer getFilterPredVal() { return null; }
}

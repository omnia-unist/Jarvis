package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.controlproxy.*;
import com.jarvis.processors.edge.data.*;
import com.jarvis.processors.edge.operators.CustomJoinOperator;
import com.jarvis.processors.edge.operators.CustomLineSplitter;
import com.jarvis.processors.edge.operators.CustomOperator;

import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP;
import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP_1;

// Implements join operator for profiling
public class JoinProfile1 extends Workload {

    public JoinProfile1(CloudUploader cloudUploader) {
        super();
        if(Config.JOIN_TABLE_SIZE == 0) {
            throw new UnsupportedOperationException("Join table size is 0 for Join profiling workload");
        }

        m_dataTypesAsStrings = new String[2];
        m_dataTypesAsStrings[0] = "PingMeshKryo";
        m_dataTypesAsStrings[1] = "JoinResult";

        classesToRegister = new IData[3];
        classesToRegister[0] = new PingMeshKryoWithTime();
        classesToRegister[1] = new PingMeshKryo();
        classesToRegister[2] = new JoinResult();

        m_numOperators = 1;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];


        setQueuesAndRuntime(new boolean[] {false, false}, cloudUploader);

        m_customOperators[0] = new CustomJoinOperator(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_finalCp);
    }
}

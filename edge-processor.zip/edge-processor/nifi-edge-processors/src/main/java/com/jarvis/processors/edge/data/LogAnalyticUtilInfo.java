package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

// Used for storing log data for LogAnalytics query
public class LogAnalyticUtilInfo implements IData  {
        // Stores the tenant name
        public String m_tenantName;

        // Stores the job info name such as latency or resource utilization
        public String m_jobInfoVar;

        // Stores the corresponding value for job info
        public float m_jobInfoVal;

        // Stores count of records for each tenant, job info var, job info val
        public int m_count;

        // Stores a record sequence number
        public int m_seqNum;
        public int getCount() {
            return m_count;
        }
        public void convertToLowerCase() {
            throw new UnsupportedOperationException("Not supported for LogAnalyticUtilInfo");
        }

        public LogAnalyticUtilInfo() {
            m_tenantName = "";
            m_jobInfoVar = "";
            m_count = 1;
        }

        public LogAnalyticUtilInfo(String srcCluster, String device, float util, int count) {
            m_tenantName = srcCluster;
            m_jobInfoVar = device;
            m_jobInfoVal = util;
            m_count = count;
        }

        public String toString() {
            return m_tenantName + "," + m_jobInfoVar + "," + m_jobInfoVal;
        }

        public int getSeqNum() {
            return m_seqNum;
        }

        public void setSeqNum(int seqNum) { m_seqNum = seqNum; }

        // Gets the payload size in bytes
        public int getPayloadInBytes() {
                return m_tenantName.getBytes().length + m_jobInfoVar.getBytes().length +
                        4;
        }

        // Checks if record is watermark
        public boolean isWaterMark() {
            return (this.m_tenantName.equals("watermark"));
        }

        public Integer getGroupingKey() {
            throw new UnsupportedOperationException("getGroupingKey with no args not supported for LogAnalyticUtilInfo");
        }

        public String getGroupingKey(boolean all) {
            return all ? m_tenantName + "," + m_jobInfoVar + "," + m_jobInfoVal : m_tenantName;
        }

        public Integer getGroupingValue() {
            return null;
        }

        public long getQueueTime() { return -1; }
        public void resetQueueTime() {}
        public IData getEntity() { return null; }
        public void setEntity(IData data) {
            throw new UnsupportedOperationException("setEntity not supported for LogAnalyticUtilInfo");
        }

        public void setWatermarkMarker() { this.m_tenantName = "watermark"; }

        public void setGroupingKey(int key) {
            throw new UnsupportedOperationException("setGroupingKey not supported for LogAnalyticUtilInfo");
        }

        public void writeSelfToKryo(Kryo kryo, Output output) {
            kryo.writeObject(output, this);
        }

        public Integer getJoinKey() {
            return null;
        }

        public void setJoinKey(int key) {
            throw new UnsupportedOperationException("setJoinKey not supported for LogAnalyticUtilInfo");
        }

        public void setJoinValue(int value) {
            throw new UnsupportedOperationException("setJoinValue not supported for LogAnalyticUtilInfo");
        }

        public Integer getJoinValue() {
            return null;
        }

        public boolean isJoinMismatchMarker() {
            // No op
            throw new UnsupportedOperationException("WordCountLine doesn't have join marker");
        }

        public void setJoinMismatchMarker() {
            // No op
            throw new UnsupportedOperationException("WordCountLine doesn't have join marker");
        }

        public boolean isSubEpochMarker() {
            return (this.m_tenantName.equals("subepochMarker"));
        }

        public void setSubEpochMarker() {
            this.m_tenantName = "subepochMarker";
        }

        public Integer getFilterPredVal() { return null; }
}

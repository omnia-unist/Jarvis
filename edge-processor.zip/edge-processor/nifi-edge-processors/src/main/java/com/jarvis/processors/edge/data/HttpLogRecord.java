package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;

// Stores Http log record information for Http web server monitoring
public class HttpLogRecord implements IData {
    long m_recordTime;
    String m_section;
    int m_status;
    int m_bytes;
    int m_count;

    public int getCount() {
        return m_count;
    }

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for HttpLogRecord class");
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for HttpLogRecord class");
    }

    public HttpLogRecord(String line) {
        String[] fields = line.split(",");
        m_recordTime = Long.parseLong(fields[3]);
        m_section = parseSection(fields[4]);
        m_status = Integer.parseInt(fields[5]);
        m_bytes = Integer.parseInt(fields[6]);
    }

    public int getPayloadInBytes() {
        return m_section.getBytes().length + 8 + 4 + 4;
    }

    public long getQueueTime() {
        throw new UnsupportedOperationException();
    }

    public int getSeqNum() {
        throw new UnsupportedOperationException();
    }

    public void setSeqNum(int seqNum) {
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return m_recordTime + "," + m_section + "," + m_bytes + "," + m_status + "\n";
    }

    public boolean isJoinMismatchMarker() {
        throw new UnsupportedOperationException();
    }

    public void setJoinMismatchMarker() {
        throw new UnsupportedOperationException();
    }

    public void setJoinValue(int value) {
        throw new UnsupportedOperationException();
    }

    public Integer getJoinValue() {
        throw new UnsupportedOperationException();
    }

    public boolean isWaterMark() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot be watermark");
    }

    public Integer getGroupingKey() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping key");
    }

    public Integer getGroupingValue() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping value");
    }

    public void setWatermarkMarker() {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot be watermark");
    }

    public void setGroupingKey(int key) {
        // No op
        throw new UnsupportedOperationException("IpTor mapping cannot have grouping key");
    }


    public Integer getJoinKey() {
        throw new UnsupportedOperationException();
    }

    public void setJoinKey(int key) {
        throw new UnsupportedOperationException();
    }

    public void resetQueueTime() {}
    public IData getEntity() { return null; }
    public void setEntity(IData data) {}

    public void writeSelfToKryo(Kryo kryo, Output output) {
        // No-op
    }

    public boolean isSubEpochMarker() {
        throw new UnsupportedOperationException("HttpLogRecord is never used in groupby operator");
    }

    public void setSubEpochMarker() {
        throw new UnsupportedOperationException("HttpLogRecord is never used in groupby operator");
    }

    public Integer getFilterPredVal() {
        throw new UnsupportedOperationException("HttpLogRecord is not used in filter operator");
    }

    public String getTypeAsString() {
        return "HttpLogRecord";
    }



    public String parseSection(String request) {
        // Find second occurrence of "/"
        String reqSection = request.split(" ")[1];
        int indSectionEnd = reqSection.indexOf("/", reqSection.indexOf("/")+1);
        if(indSectionEnd == -1) {
            indSectionEnd = reqSection.length();
        }

        return reqSection.substring(0, indSectionEnd);
    }


}

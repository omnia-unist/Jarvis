package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.data.WordCountEntity;
import com.jarvis.processors.edge.operators.CustomMapOperator;
import com.jarvis.processors.edge.operators.CustomOperator;

// Implements All-SP config for LogAnalytics query
public class AllSpLogAnalyticsQuery extends Workload {

    WordCountEntity m_waterMarkEntry;
    WordCountEntity m_subEpochMarker;

    public AllSpLogAnalyticsQuery(CloudUploader cloudUploader) {
        super();
        m_dataTypesAsStrings = new String[2];
        m_dataTypesAsStrings[0] = "WordCountEntity";
        m_dataTypesAsStrings[1] = "WordCountEntity";

        classesToRegister = new IData[2];
        classesToRegister[0] = new WordCountEntity();
        classesToRegister[1] = new WordCountEntity();

        m_numOperators = 1;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;
        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, true}, cloudUploader);

        m_waterMarkEntry = new WordCountEntity();
        m_waterMarkEntry.setWatermarkMarker();

        m_subEpochMarker = new WordCountEntity();
        m_subEpochMarker.setSubEpochMarker();

        m_customOperators[0] = new CustomMapOperator(0, m_firstCp, 1,
                m_waterMarkEntry, m_subEpochMarker);
        m_customOperators[0].setNextQueue(m_finalCp);
    }
}

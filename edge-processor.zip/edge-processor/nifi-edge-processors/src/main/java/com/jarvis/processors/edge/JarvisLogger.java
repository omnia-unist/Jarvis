package com.jarvis.processors.edge;
import org.apache.nifi.logging.ComponentLog;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicBoolean;

// Logger class
public class JarvisLogger {
    static ComponentLog m_logger;
    static AtomicBoolean initialized = new AtomicBoolean(false);
    public static AtomicBoolean verboseMode = new AtomicBoolean(false);
    public static void initialize(ComponentLog logger) {
        if(!initialized.get()) {
            initialized.set(true);
            m_logger = logger;

            if(Config.DEBUG_MODE.equals("VERBOSE")) {
                verboseMode.set(true);
            }

            m_logger.debug("Debug status in config file is: " + Config.DEBUG_MODE);
            m_logger.debug("Join key status is: " + Config.JOIN_KEY_START);
            m_logger.debug("Join table size is: " + Config.JOIN_TABLE_SIZE);
        }
    }

    public static void debug(String s) {
        if(initialized.get() && verboseMode.get()) {
            SimpleDateFormat formatOnly = new SimpleDateFormat("HH:mm:ss");
            String time = formatOnly.format(Calendar.getInstance().getTime());
            m_logger.debug("[ATUL DEBUG]" + time + " [Thread id: " + Thread.currentThread().getId() + "]: " + s);
        }

    }

    public static void info(String s) {
        if(initialized.get()) {
            SimpleDateFormat formatOnly = new SimpleDateFormat("HH:mm:ss");
            String time = formatOnly.format(Calendar.getInstance().getTime());
            m_logger.info("[ATUL INFO] " + time + " [Thread id: " + Thread.currentThread().getId() + "]: " + s);
        }
    }
}

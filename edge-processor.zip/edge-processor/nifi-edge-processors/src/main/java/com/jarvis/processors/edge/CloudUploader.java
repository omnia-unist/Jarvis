package com.jarvis.processors.edge;

import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.ProcessSession;
import org.apache.nifi.processor.Relationship;
import org.apache.nifi.processor.io.OutputStreamCallback;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

// Class to collect data and serialize it, uploading to stream processor from data source over network
public class CloudUploader {
    Relationship m_MYRELATIONSHIP;
    public CloudUploader(Relationship MY_RELATIONSHIP) {
        m_MYRELATIONSHIP = MY_RELATIONSHIP;
    }
    private byte[] m_payloadContent;
    private AtomicInteger m_numQueriesDone = new AtomicInteger(0);
    private AtomicLong m_currentEpochId = new AtomicLong(0);

    // Accumulates payload by adding input byte array to payload content
    public void addPayload(byte[] epochContent, long epochId) {
        synchronized (MyProcessor.m_sessionFactoryLock) {
            try {
                JarvisLogger.info("[CloudUploader.addPayload] Entered sync block with epoch Id: " +
                        epochId + "," + m_currentEpochId.get());
                while(epochId > m_currentEpochId.get()) {
                    // Wait this thread for all the query instances to complete current epoch
                    MyProcessor.m_sessionFactoryLock.wait();
                }

                if (m_payloadContent == null) {
                    m_payloadContent = epochContent;
                } else {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    outputStream.write(m_payloadContent);
                    outputStream.write(epochContent);

                    m_payloadContent = outputStream.toByteArray();
                }
            } catch (IOException ex) {
                JarvisLogger.info("[CloudUploader.addPayload] ERROR when copying byte array for epoch");
            } catch (InterruptedException ex) {
                JarvisLogger.info("[CloudUploader.addPayload] ERROR when waiting for epoch increment");
            }
        }
    }

    // Sends the accumulated payload for the epoch to stream processor over network
    public void sendToCloud(byte[] windowContent, int epochId) {
        ProcessSession session;
        synchronized (MyProcessor.m_sessionFactoryLock) {
            try {
                JarvisLogger.info("[CloudUploader.sendToCloud] epoch id and current id are: " +
                        epochId + ", " + m_currentEpochId.get() + "," + m_numQueriesDone.get());
                while (epochId > m_currentEpochId.get()) {
                    // Wait this thread
                    MyProcessor.m_sessionFactoryLock.wait();
                }

                m_numQueriesDone.getAndIncrement();
                if (m_numQueriesDone.get() == Config.NUMBER_OF_MULTIQUERY_INSTANCES) {
                    m_numQueriesDone.set(0);
                    m_currentEpochId.getAndIncrement();

                    // Copy content of input array to payload before sending to cloud
                    try {
                        if (m_payloadContent == null) {
                            m_payloadContent = windowContent;
                        } else {
                            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                            JarvisLogger.info("[CloudUploader.sendToCloud] length of current payload is: " +
                                    m_payloadContent.length);
                            outputStream.write(m_payloadContent);
                            outputStream.write(windowContent);
                            m_payloadContent = outputStream.toByteArray();
                        }
                    } catch (IOException ex) {
                        JarvisLogger.info("[CloudUploader.addPayload] ERROR when copying byte array for epoch after final " +
                                "operator is done on epoch");
                    }

                    session = MyProcessor.m_sessionFactory.createSession();
                    try {
                        // Write out to network flowfiles
                        JarvisLogger.info("[CloudUploader.sendToCloud] The size of network queue is " +
                                m_payloadContent.length + ", with epoch ID: " + epochId);
                        if (m_payloadContent.length > 0) {
                            final AtomicReference<FlowFile> flowFile = new AtomicReference<>(session.create());
                            session.putAttribute(flowFile.get(), "edgeId", Config.EDGE_ID);
                            session.putAttribute(flowFile.get(), "epochId", Integer.toString(epochId));
                            flowFile.set(session.write(flowFile.get(), new OutputStreamCallback() {
                                @Override
                                public void process(OutputStream outNetwork) throws IOException {
                                    outNetwork.write(m_payloadContent);
                                }
                            }));

                            session.transfer(flowFile.get(), m_MYRELATIONSHIP);
                        }

                        session.commit();
                    } catch (Exception ex) {
                        session.rollback();
                    }

                    m_payloadContent = null;

                    // Notify all threads in CloudUploader to check if they can proceed
                    MyProcessor.m_sessionFactoryLock.notifyAll();
                } else {
                    addPayload(windowContent, epochId);
                }
            } catch(InterruptedException ex) {
                JarvisLogger.info("[CloudUploader.addPayload] ERROR when waiting for epoch Id to increment");
            }
        }
    }
}

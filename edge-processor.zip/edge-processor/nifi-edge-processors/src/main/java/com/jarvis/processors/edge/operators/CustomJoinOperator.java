package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.IpTorMapping;
import com.jarvis.processors.edge.data.JoinResult;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.Random;

// Implements join operator for used in T2TProbe query
public class CustomJoinOperator extends CustomOperator {
    Integer[] m_numOutRecords = {0};
    IData[] m_staticRightTable;
    IData m_mismatchMarker;
    IData m_waterMarkWithTime;
    JoinResult m_subEpochMarkerWithTime;

    public  CustomJoinOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        createStaticTable();
        m_mismatchMarker = new JoinResult();
        m_mismatchMarker.setJoinMismatchMarker();

        m_waterMarkWithTime = new JoinResult();
        m_waterMarkWithTime.setWatermarkMarker();

        m_subEpochMarkerWithTime = new JoinResult();
        m_subEpochMarkerWithTime.setSeqNum(-435);
        m_subEpochMarkerWithTime.setSubEpochMarker();
    }

    private void createStaticTable() {
        int joinTableSize = Config.JOIN_TABLE_SIZE;
        m_staticRightTable = new IpTorMapping[joinTableSize];
        for(int i = 0; i < joinTableSize; i++) {
            m_staticRightTable[i] = new IpTorMapping();
            m_staticRightTable[i].setJoinKey(Config.JOIN_KEY_START + i);
            m_staticRightTable[i].setJoinValue(Config.JOIN_KEY_START * 2 + i);
        }
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        Observable<IData> right = Observable.
                fromArray(m_staticRightTable);

        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
        join(right,
            aLong -> Observable.never(),
            aLong -> Observable.never(),
            (l, r) -> {
                if(l.getJoinKey().equals(r.getJoinKey())) {
                    return new JoinResult(l.getJoinValue(), r.getJoinValue());
                } else {
                    return m_mismatchMarker;
                }
            }).
        subscribe(
            new Observer<IData>() {
                @Override
                public void onSubscribe(Disposable d) {}

                @Override
                public void onComplete() {
                    if(!m_subEpochComplete.get()) {
                        m_waterMarkWithTime.resetQueueTime();
                        m_waterMarkWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                        m_recentEpochEndTime = System.currentTimeMillis();
                        m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                        JarvisLogger.info("[CustomJoinOperator.setDataflow] Thread ID is: " +
                                Thread.currentThread().getId() + ", epoch duration is " +
                                m_recentEpochDuration + ", number of records=" + m_currentEpochRecordCount +
                                ", watermark seq num is: " + m_waterMarkWithTime.getSeqNum());
                        JarvisLogger.debug("OnComplete occurred");
                        m_nextQueue.putWaterMark(m_waterMarkWithTime);
                    } else {
                        m_subEpochComplete.set(false);
                        JarvisLogger.debug(m_opId + " [CustomJoinOperator.onComplete] subepoch marker set");
                        JarvisLogger.info(m_opId + " [CustomJoinOperator.onComplete] subepoch marker, record count: " + m_currentEpochRecordCount
                        + ", sub epoch seq num: " + m_subEpochMarkerWithTime.getSeqNum());
                        m_nextQueue.put(m_subEpochMarkerWithTime);
                    }
                }

                @Override
                public void onError(Throwable throwable) {
                }

                @Override
                public void onNext(IData data) {
                    try {
                        if(!data.isJoinMismatchMarker()) {
                            JarvisLogger.debug(data.toString());
                            data.resetQueueTime();
                            m_numOutRecords[0]++;
                            m_nextQueue.put(data);
                        }
                    } catch (Exception e) {
                        JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                    }
                }

            }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public void setNextQueue(IControlProxy queue) {
        // No-op since final operator
        m_nextQueue = queue;
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}
package com.jarvis.processors.edge;

import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.operators.CustomOperator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Jarvis runtime implementation
public class Runtime implements Runnable {
    public static final int SIZE_OF_INT = 4;
    public static final int SIZE_OF_FLOAT = 4;

    // Thresholds for determining query congestion/idle states
    public static final double IDLE_TIME_DELTA_RATIO_THRESHOLD = Config.IDLE_TIME_DELTA_THRESHOLD;
    public static final double IDLE_TO_EPOCH_TIME_RATIO_THRESHOLD = Config.IDLE_TO_EPOCH_RATIO_THRESHOLD;
    public static final double DRAINED_RECORDS_FRACTION_THRESHOLD = Config.DRAIN_THRESHOLD;

    IControlProxy[] m_internalCps;
    IControlProxy m_firstCp;
    IControlProxy m_finalCp;

    CustomOperator[] m_customQueryOperators;
    List<Integer> m_sortedEffectiveCpsIdx;
    Integer m_currentBoundaryOp;

    int m_prevClearSubQueryIdx;
    int m_currentFullOpsSubQueryIdx;
    long m_prevIdleTimes = 0;
    long m_currIdleTimes = 0;
    Integer[] cpDrainedDataSizes;
    Integer[] cpEdgeDataSizes;
    Integer[] cpDiscardedDataSizes;
    private RuntimeState m_currentRuntimeState;
    private RuntimeState m_prevRuntimeState;
    boolean finalCpIsSubquery = false;

    double m_probUpdateDelta = 0.1;
    LoadFactorState[] m_loadFactors;
    CongestionState m_prevCongestionState;
    CongestionState m_initialCongestionState;
    private double epsilon = 0.00001;
    private int m_finalQueueIdx;
    private int m_currCongestedDetectionEpochs;
    private int m_currIdleDetectionEpochs;

    private int m_sourcePayloadInBytes;
    private Double[] m_preAdaptInitialLoadFactors;
    private int m_numAdaptationsDone;

    public Runtime() {
        m_prevCongestionState = CongestionState.STABLE;
        m_currentRuntimeState = RuntimeState.STABLE;
        m_prevRuntimeState = RuntimeState.STABLE;
        m_prevClearSubQueryIdx = -1;
        resetDetectionEpochCount();
        m_numAdaptationsDone=0;
    }

    public void setSrcDataSizeInBytes(int srcDataSizeInBytes) {
        m_sourcePayloadInBytes = srcDataSizeInBytes;
    }

    // Set query operators in the query, for obtaining profiling information
    public void setQueryOps(CustomOperator...virtualOperators) {
        List<CustomOperator> customOpsList = new ArrayList<>();
        for(CustomOperator op : virtualOperators) {
            customOpsList.add(op);
        }

        m_customQueryOperators = new CustomOperator[customOpsList.size()];
        m_customQueryOperators = customOpsList.toArray(m_customQueryOperators);

    }

    // Set the control proxies to manage and coordinate their load factors
    public void setCps(IControlProxy firstQueue, IControlProxy lastQueue, IControlProxy[] internalCps) {
        m_firstCp = firstQueue;
        m_finalCp = lastQueue;

        int numControlProxies = internalCps.length + 2;
        m_finalQueueIdx=numControlProxies-1;
        cpDrainedDataSizes = new Integer[numControlProxies];
        cpEdgeDataSizes = new Integer[numControlProxies];
        cpDiscardedDataSizes = new Integer[numControlProxies];
        m_internalCps = internalCps;
        m_loadFactors = new LoadFactorState[numControlProxies-1];
        for (int i = 0; i < numControlProxies-1; i++) {
            m_loadFactors[i] = new LoadFactorState();
        }

        m_preAdaptInitialLoadFactors = new Double[numControlProxies-1];
    }

    private void resetDetectionEpochCount() {
        m_currIdleDetectionEpochs = 0;
        m_currCongestedDetectionEpochs = 0;
    }

    // Runnable function which implements Jarvis runtime state machine
    public void run() {
        CongestionState currentCongestionState = CongestionState.STABLE;
        boolean m_loadFactorsChanged = false;
        boolean firstEpochDone = false;
        int coolDownIterations = 0;
        initializeLoadFactors(CongestionState.START);
        while(true) {
            JarvisLogger.info("[Runtime.run] New run. Runtime current state: " + m_currentRuntimeState + " and prev runtime state:" +
                    m_prevRuntimeState);
            if(!firstEpochDone) {
                m_finalCp.waitForWatermarkWithSeqNum(Config.FIRST_EPOCH_TO_START_RUNTIME);
                firstEpochDone = true;
            }

            // Wait for new epoch after completing one probe cycle and setting new load factors if needed
            m_firstCp.waitForNewEpochAndGetWatermarkIdV2(m_currentRuntimeState);
            JarvisLogger.info("[Runtime.run] Going to profile CPs");
            m_prevCongestionState = currentCongestionState;
            currentCongestionState = probeControlProxies();

            // Override congestion state if needed
            // Reset to previous congestion state if in PROFILE phase
            // Cool down query if just out of adaptation
            if(m_currentRuntimeState == RuntimeState.PROFILE) {
                currentCongestionState = m_prevCongestionState;
            } else if (m_currentRuntimeState == RuntimeState.COOL_DOWN) {
                currentCongestionState = CongestionState.COOL_DOWN;
            }

            JarvisLogger.info("[Runtime.run] Congestion state is: " + currentCongestionState);
            switch (currentCongestionState) {
                case CONGESTED:
                    // Need to reduce compute load
                    if (m_currentRuntimeState == RuntimeState.STABLE) {
                        if(m_numAdaptationsDone < Config.MAX_NUM_ADAPTATIONS) {
                            if (m_currCongestedDetectionEpochs == Config.MAX_DETECTION_EPOCHS) {
                                // Enter profiling phase
                                JarvisLogger.debug("[Runtime.run] Congested state profiling : " + m_currentFullOpsSubQueryIdx);
                                JarvisLogger.info("[Runtime.run] congested state");

                                // Save the load factors for bootstrapping
                                for (int i = 0; i < m_loadFactors.length; i++) {
                                    m_loadFactors[i].setPrevLoadFactorWithCongestion(m_loadFactors[i].getLoadFactorCurrent());
                                }

                                initializeLoadFactors(CongestionState.PROFILE);
                                setCurrRuntimeState(RuntimeState.PROFILE);
                            } else {
                                m_currCongestedDetectionEpochs++;
                            }
                        }
                    } else if(m_currentRuntimeState == RuntimeState.PROFILE) {
                        // Finished profiling and going into adapt phase
                        JarvisLogger.debug("[Runtime.run] Congested state calibrating : " + m_currentFullOpsSubQueryIdx);
                        m_numAdaptationsDone++;
                        calibrateQuery(CongestionState.CONGESTED);
                        setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
                    } else {
                        // Update load factors in adapt phase
                        m_loadFactorsChanged = tryDecreaseLoadFactorsAndAdapt();

                        // Synchronize the completion of an epoch before updating load factors again
                        if (m_loadFactorsChanged) {
                            JarvisLogger.debug("[Runtime.run] Load changed");
                            JarvisLogger.info("[Runtime.run] LOad changed");
                            setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
                        } else {
                            JarvisLogger.debug("[Runtime.run] Load unchanged");
                            setCurrRuntimeState(RuntimeState.COOL_DOWN);
                            resetDetectionEpochCount();
                        }
                    }

                    break;
                case CLEAR:
                    // Need to increase compute load
                    JarvisLogger.debug("[Runtime.run] Clear state");
                    m_prevClearSubQueryIdx = m_currentFullOpsSubQueryIdx;
                    if (m_currentRuntimeState == RuntimeState.STABLE) {
                        if(m_numAdaptationsDone < Config.MAX_NUM_ADAPTATIONS) {
                            if (m_currIdleDetectionEpochs == Config.MAX_DETECTION_EPOCHS) {
                                // Enter profiling phase to trigger adaptation
                                JarvisLogger.debug("[Runtime.run] Clear state profiling : " + m_currentFullOpsSubQueryIdx);
                                JarvisLogger.info("[Runtime.run] Clear state");

                                // Save the load factors for bootstrapping
                                for (int i = 0; i < m_loadFactors.length; i++) {
                                    m_loadFactors[i].setPrevLoadFactorWithClear(m_loadFactors[i].getLoadFactorCurrent());
                                }

                                initializeLoadFactors(CongestionState.PROFILE);
                                setCurrRuntimeState(RuntimeState.PROFILE);
                            } else {
                                m_currIdleDetectionEpochs++;
                            }
                        }
                    } else if(m_currentRuntimeState == RuntimeState.PROFILE) {
                        // Previous phase was profiling, enter adaptation phase
                        m_numAdaptationsDone++;
                        JarvisLogger.debug("[Runtime.run] Clear state calibrating : " + m_currentFullOpsSubQueryIdx);
                        calibrateQuery(CongestionState.CLEAR);
                        setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
                    } else {
                        // Entered adaptation phase
                        // Update load factors
                        m_loadFactorsChanged = tryIncreaseLoadFactorsAndAdapt();

                        // Synchronize the completion of an epoch before updating load factors again
                        if (!m_loadFactorsChanged) {
                            JarvisLogger.debug("[Runtime.run] Load unchanged");
                            setCurrRuntimeState(RuntimeState.COOL_DOWN);
                            resetDetectionEpochCount();
                        } else {
                            JarvisLogger.debug("[Runtime.run] Load changed");
                            JarvisLogger.info("[Runtime.run] Load changed");
                            setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
                        }
                    }

                    break;
                case STABLE:
                    JarvisLogger.debug("[Runtime.run] Stable state");
                    JarvisLogger.info("[Runtime.run] Stable state" +
                            ", load factors are: ");

                    // Enter cool down phase if the Runtime just got out of adaptation phase
                    if (m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
                        setCurrRuntimeState(RuntimeState.COOL_DOWN);
                    } else {
                        setCurrRuntimeState(RuntimeState.STABLE);
                        m_prevIdleTimes = m_currIdleTimes;
                    }

                    resetDetectionEpochCount();
                    break;
                case COOL_DOWN:
                    // Cool down phase after adaptation completes
                    JarvisLogger.info("[Runtime.run] Cool down state");
                    coolDownIterations++;
                    if(coolDownIterations > Config.COOL_DOWN_ITERATIONS) {
                        setCurrRuntimeState(RuntimeState.STABLE);
                        m_prevIdleTimes = m_currIdleTimes;
                        coolDownIterations = 0;
                    } else {
                        setCurrRuntimeState(RuntimeState.COOL_DOWN);
                    }
                    break;
            }

            JarvisLogger.debug("[Runtime.run] Finished updating control knobs, allowing CP0 to continue with next " +
                    "epoch, prev runtime state: " + m_prevRuntimeState + ", current runtimestate: " + m_currentRuntimeState);
        }
    }

    // Set the current Jarvis runtime state
    private void setCurrRuntimeState(RuntimeState state) {
        m_prevRuntimeState = m_currentRuntimeState;
        m_currentRuntimeState = state;
    }

    // Probing function to determine idle or congested state for control proxies
    public CongestionState probeControlProxies() {
        CongestionState state = CongestionState.STABLE;
        double queryCongestedRecordCountRatio = 0;
        long totalIdleTime = 0;
        double avgIdleTimeRatio = 0;
        int id;

        // Set to true so idle time measured always at queue level
        boolean measureIdleAsInAdaptPhase = true;

        // Determine idle time statistics at the query level
        long currIdleTime = 0, epochTime = 0;
        double idleTimeRatio = 0;
        if(measureIdleAsInAdaptPhase) {
            IdleTimeStats firstCpIdleTimeStats = m_firstCp.getRecentAdaptIdleTime();
            IdleTimeStats finalCpIdleTimeStats = m_firstCp.getFinalCpRecentAdaptIdleTime();
            if(firstCpIdleTimeStats.getWaterMark() - finalCpIdleTimeStats.getWaterMark() > 1) {
                currIdleTime = Long.MIN_VALUE;
            } else {
                currIdleTime = firstCpIdleTimeStats.getStartTimer() - finalCpIdleTimeStats.getStartTimer();
            }

            epochTime = m_firstCp.getRecentEpochDuration();
            idleTimeRatio = (double) currIdleTime / (double) epochTime;
            JarvisLogger.info("[Runtime.observeControllerQueues] ADAPT idle time stats details: " + currIdleTime +
                    ", epoch time: " + epochTime + ", ");
        }

        // Determine congestion state using drained data statistics
        for (id = 0; id < m_finalQueueIdx; id++) {
            IControlProxy queue;
            if(id == 0) {
                queue = m_firstCp;
            } else {
                queue = m_internalCps[id-1];
            }

            // Detect clear state
            if(!measureIdleAsInAdaptPhase) {
                currIdleTime = queue.getRecentIdleTime();
                epochTime = queue.getRecentEpochDuration();
                idleTimeRatio = (double) currIdleTime/(double) epochTime;
                JarvisLogger.info("[Runtime.observeControllerQueues] STABLE idle time stats details: " + currIdleTime + ", epoch time: " + epochTime);
            }

            // Detect drained state
            cpDrainedDataSizes[id] = queue.getRecentRecordsDrainedSize();
            cpEdgeDataSizes[id] = (int)queue.getRecentPayloadSizeOnEdge();
            cpDiscardedDataSizes[id] = queue.getRecentRecordsDiscardedSize();

            double drainedRecordsSizeRatio =
                    (double) cpDrainedDataSizes[id]/(double) (cpEdgeDataSizes[0]+cpDiscardedDataSizes[0]+cpDrainedDataSizes[0]);
            JarvisLogger.info("[Runtime.observeControllerQueues] Records drained size in bytes: " +
                    cpDrainedDataSizes[id] + ", records on edge size in bytes: " +
                    cpEdgeDataSizes[id] + ", records discarded size in bytes: " +
                    cpDiscardedDataSizes[id]);
            JarvisLogger.debug("[Runtime.observeControllerQueues] Records drained size: " + cpDrainedDataSizes[id] +
                    " and idle time: " + currIdleTime);
            if(cpDrainedDataSizes[id] > 0) {
                // Detect congested state
                queryCongestedRecordCountRatio += drainedRecordsSizeRatio;
            } else if (!measureIdleAsInAdaptPhase) {
                totalIdleTime += currIdleTime;
                avgIdleTimeRatio += idleTimeRatio;
            }
        }

        m_currIdleTimes = measureIdleAsInAdaptPhase ? currIdleTime : totalIdleTime;
        avgIdleTimeRatio = measureIdleAsInAdaptPhase ? idleTimeRatio : avgIdleTimeRatio/(double)id;
        double avgRecordsDrainedSize = queryCongestedRecordCountRatio/m_finalQueueIdx;
        JarvisLogger.info("[Runtime.observeControllerQueues]idle ratio: " + avgIdleTimeRatio + ", runtime state: " +
                m_currentRuntimeState);
        JarvisLogger.debug("[Runtime.observeControllerQueues] Final records drained metric: " + avgRecordsDrainedSize +
                " and idle time metric: " + avgIdleTimeRatio + ", current idle time: " + m_currIdleTimes);

        if(avgRecordsDrainedSize > DRAINED_RECORDS_FRACTION_THRESHOLD) {
            state = CongestionState.CONGESTED;
            m_prevIdleTimes = 0; // Idle time is reset
        } else if(queryCongestedRecordCountRatio == 0 && avgIdleTimeRatio > IDLE_TO_EPOCH_TIME_RATIO_THRESHOLD &&
                (m_currIdleTimes-m_prevIdleTimes) > IDLE_TIME_DELTA_RATIO_THRESHOLD * m_prevIdleTimes){
            // Check first condition above as well because previous idle time can
            // be negative since its set to current idle time.
            state = CongestionState.CLEAR;
        }

        JarvisLogger.info("[Runtime.observeControllerQueues] Idle time ratio is: " + avgIdleTimeRatio + ", and current idle time: " +
                m_currIdleTimes + ", prev idle times is: " + m_prevIdleTimes + ", drained records is: " + avgRecordsDrainedSize);

        return state;
    }

    // Profile the query before we enter adaptation phase. Identifies operators which result in data reduction,
    // then sorts them based on operator relay ratios. Also computes the execution cost of each operator.
    public void calibrateQuery(CongestionState congestionState) {
        double origDataSizeEdge =  cpEdgeDataSizes[0];
        double opOutputSize = 0;
        double prevOpOutputSize = origDataSizeEdge;
        double prevOverallRelayRatio = 1;

        List<Integer> effectiveCpsIdx = new ArrayList<>();
        List<Double> relayRatios = new ArrayList<>();
        m_sortedEffectiveCpsIdx = new ArrayList<>(); // Doesn't contain the last control proxy as it is updated always in the end

        effectiveCpsIdx.add(0);
        finalCpIsSubquery = false;
        for (int i = 1; i < m_finalQueueIdx; i++) {
            opOutputSize = cpEdgeDataSizes[i] + cpDrainedDataSizes[i] + cpDiscardedDataSizes[i];
            double currOverallRelayRatio = (double) opOutputSize/origDataSizeEdge;
            JarvisLogger.debug("[Runtime.calibrateQuery] O/P size: " + opOutputSize +
                    " orig size: " + origDataSizeEdge + ", discarded size: " + cpDiscardedDataSizes[i] + ", " +
                    "edge data size: " + cpEdgeDataSizes[i]);
            JarvisLogger.info("[Runtime.calibrateQuery] LP solver relay ratio for op: " + i +
                    ", output size:" + opOutputSize + " by adding: " + cpEdgeDataSizes[i] + "," +
                    cpDrainedDataSizes[i] + ", " + cpDiscardedDataSizes[i] +  ", input size: "
                    + cpEdgeDataSizes[i-1] + ", current relay ratio is: " + currOverallRelayRatio + ", prev relay ratio: " +
                    prevOverallRelayRatio);
            if(currOverallRelayRatio <= prevOverallRelayRatio) {
                effectiveCpsIdx.add(i);
                double relayRatioComp = (double)opOutputSize/(double)prevOpOutputSize;
                JarvisLogger.info("[Runtime.calibrateQuery] " + " Query each relay ratio: " + relayRatioComp + " for op: " + i);
                relayRatios.add(relayRatioComp);
                prevOpOutputSize = cpEdgeDataSizes[i];
                prevOverallRelayRatio = currOverallRelayRatio;
            }
        }

        double outputDataSize = m_finalCp.getRecentPayloadSizeOnEdge();
        double finalDataRedRatio = outputDataSize/origDataSizeEdge;
        JarvisLogger.debug("[Runtime.calibrateQuery] Final O/P size: " + outputDataSize);
        JarvisLogger.info("[Runtime.calibrateQuery] final data ratio: " + finalDataRedRatio + ", from: " +
                outputDataSize + ", and " + origDataSizeEdge + ", prev relay ratio: " + prevOverallRelayRatio);
        if(finalDataRedRatio <= prevOverallRelayRatio) {
            effectiveCpsIdx.add(m_finalQueueIdx);
            double relayRatioComp = (double)outputDataSize/(double)prevOpOutputSize;
            JarvisLogger.info("[Runtime.calibrateQuery] LP solver relay ratio for final op: " + relayRatioComp +
                    ", output size: " + outputDataSize + ", input size: " + cpEdgeDataSizes[m_finalQueueIdx-1] + ", orig data size: "
                    + origDataSizeEdge);
            relayRatios.add(relayRatioComp);
            finalCpIsSubquery = true;
        }

        // Compute cost of each operator
        for(int i = 1; i < effectiveCpsIdx.size(); i++) {
            double cost = m_customQueryOperators[effectiveCpsIdx.get(i)-1].getProfileEpochEndTime() -
                    m_customQueryOperators[effectiveCpsIdx.get(i-1)].getProfileEpochStartTime();
            JarvisLogger.info("[Runtime.calibrateQuery] op id of second op is: " + m_customQueryOperators[effectiveCpsIdx.get(i)-1].getOpId() +
                    ", op id of first op is: " + m_customQueryOperators[effectiveCpsIdx.get(i-1)].getOpId());
            JarvisLogger.info("[Runtime.calibrateQuery] Cost of op: " + i + " is " + cost + ", end time: " +
                    m_customQueryOperators[effectiveCpsIdx.get(i)-1].getProfileEpochEndTime() + ", start time: " +
                    m_customQueryOperators[effectiveCpsIdx.get(i-1)].getProfileEpochStartTime());
            long numRecordsEpoch = m_customQueryOperators[effectiveCpsIdx.get(i-1)].getRecentEpochRecordCount();
            JarvisLogger.info("[Runtime.calibrateQuery] Records procesesd: " +
                    numRecordsEpoch);
            JarvisLogger.info("[Runtime.calibrateQuery] cost per record is: " + (double)cost/(double)numRecordsEpoch);
        }

        JarvisLogger.info("[Runtime.calibrateQuery] Recent epoch duration is:" + m_firstCp.getRecentEpochDuration());
        for(int i = 0; i < relayRatios.size(); i++) {
            JarvisLogger.info("[Runtime.calibrateQuery] Relay ratios are: " + relayRatios.get(i));
        }

        for(int i = 0; i < effectiveCpsIdx.size(); i++) {
            JarvisLogger.info("[Runtime.calibrateQuery] Effective ops are: " + effectiveCpsIdx.get(i));
        }

        // Remove last element for sorting on r-value, since last op always comes in end
        relayRatios.remove(relayRatios.size()-1);
        Double[] relayAsArr = new Double[relayRatios.size()];
        relayRatios.toArray(relayAsArr);
        VirtualOpsComparator comparator = new VirtualOpsComparator(relayAsArr);
        Integer[] indexes = comparator.createIndexArray();
        Arrays.sort(indexes, comparator);
        for(int i = 0; i < indexes.length; i++) {
            m_sortedEffectiveCpsIdx.add(effectiveCpsIdx.get(indexes[i]));
        }

        for(int i = 0; i < m_sortedEffectiveCpsIdx.size(); i++) {
            JarvisLogger.info("[Runtime.calibrateQuery] Sorted ops are: " + m_sortedEffectiveCpsIdx.get(i));
        }

        m_initialCongestionState = congestionState;

        // Add the last control proxy in the end, the control proxy to update for load factors is the one
        // before the final though because effectiveCpsIdx starts with index 0 by default
        if(m_initialCongestionState == CongestionState.CLEAR) {
            m_sortedEffectiveCpsIdx.add(effectiveCpsIdx.get(relayRatios.size()));
        } else if(m_initialCongestionState == CongestionState.CONGESTED) {
            m_sortedEffectiveCpsIdx.add(0,effectiveCpsIdx.get(relayRatios.size()));
        }

        initializeLoadFactors(congestionState);
        JarvisLogger.debug("[Runtime.calibrateQuery] current subquery index is " +
                m_currentFullOpsSubQueryIdx);
    }

    private void resetLoadFactorsForProfiling(int idx, double resetVal) {
        m_loadFactors[idx].setLoadFactorCurrent(resetVal);
        setCurrLoadFactorOnCp(idx);
    }

    // Set the current load factors on the input control proxy index
    private void setCurrLoadFactorOnCp(int cpIdx) {
        if(cpIdx == 0) {
            m_firstCp.setProbSendingToEdge(m_loadFactors[0].getLoadFactorCurrent());
        } else {
            m_internalCps[cpIdx-1].setProbSendingToEdge(m_loadFactors[cpIdx].getLoadFactorCurrent());
        }
    }

    // Initializes load factors on all control proxies based on congestion state
    private void initializeLoadFactors(CongestionState state) {
        if (state == CongestionState.START) {
            for(int i = 0; i < m_loadFactors.length; i++) {
                resetLoadFactorsForProfiling(i, Config.m_beginLoadFactors.get(i));
            }
        } else {
            if(Config.LARGE_RESOURCE_CHANGE) {
                // If this is first time we are transitioning to ADAPT from STABLE, and so not in ADAPT yet.
                if (state == CongestionState.PROFILE) {
                    for (int i = 0; i < m_loadFactors.length; i++) {
                        resetLoadFactorsForProfiling(i, 1.0);
                    }
                } else {
                    if (Config.INITIAL_LOAD_FACTOR_LP) {

                    } else {
                        for (int i = 0; i < m_loadFactors.length; i++) {
                            if (Config.INITIAL_LOAD_FACTOR_0) {
                                resetLoadFactorsForProfiling(i, 0.05);
                            } else if (Config.INITIAL_LOAD_FACTOR_1) {
                                resetLoadFactorsForProfiling(i, 1.0);
                            } else if(Config.INITIAL_LOAD_FACTOR_BOOTSTRAP) {
                                if(state == CongestionState.CONGESTED) {
                                    m_loadFactors[i].revertToLoadFactorWithCongestion();
                                } else if(state == CongestionState.CLEAR) {
                                    m_loadFactors[i].revertToLoadFactorWithClear();
                                }

                                setCurrLoadFactorOnCp(i);
                            } else {
                                // custom load factor for each operator
                                resetLoadFactorsForProfiling(i, Config.m_initialLoadFactors.get(i));
                            }
                        }
                    }
                }
            }
        }

        if (state == CongestionState.CONGESTED) {
            m_currentBoundaryOp = m_sortedEffectiveCpsIdx.size() - 1;
        } else if (state == CongestionState.CLEAR) {
            m_currentBoundaryOp = 0;
        }

        // Logs the order of operators based on relay-ratio based priority
        if (m_sortedEffectiveCpsIdx != null) {
            StringBuilder virtualOpsString = new StringBuilder("[");
            for (int i = 0; i < m_sortedEffectiveCpsIdx.size(); i++) {
                virtualOpsString.append(m_sortedEffectiveCpsIdx.get(i));
                virtualOpsString.append(",");
            }

            virtualOpsString.append("]");
            JarvisLogger.info("[Runtime.initializeLoadFactors] custom virtual ops size is: " +
                    m_customQueryOperators.length + ", sorted virtual ops: " + virtualOpsString.toString());
        }
    }

    // Decreases the load factors during adaptation if possible, by performing binary search to reduce
    // query load on the data source. It is stateful across calls, storing the latest control proxy to
    // update load factors for in the current adaptation phase.
    public boolean tryDecreaseLoadFactorsAndAdapt() {
        boolean continueAdaptation = false;
        while(m_currentBoundaryOp >= 0 && m_currentBoundaryOp < m_sortedEffectiveCpsIdx.size()) {
            int cpIndex = m_sortedEffectiveCpsIdx.get(m_currentBoundaryOp);
            double currP = m_loadFactors[cpIndex].getLoadFactorCurrent();
            if(m_initialCongestionState == CongestionState.CONGESTED) {
                // Save the latest configuration corresponding to CONGESTED state
                m_loadFactors[cpIndex].setPrevLoadFactorWithCongestion(currP);
            }

            m_loadFactors[cpIndex].setLoadFactorHigh(currP - m_probUpdateDelta);
            double lowP = m_loadFactors[cpIndex].getLoadFactorLow();
            double highP = m_loadFactors[cpIndex].getLoadFactorHigh();
            if (highP - lowP >= epsilon) {
                m_loadFactors[cpIndex].setLoadFactorCurrent(lowP + ((highP - lowP) / 2));
                setCurrLoadFactorOnCp(cpIndex);
                continueAdaptation = true;
                break;
            } else if (m_initialCongestionState == CongestionState.CLEAR) {
                // Get previous CLEAR state load factors
                JarvisLogger.info("Reverting to last load factor with clear state");
                m_loadFactors[cpIndex].revertToLoadFactorWithClear();
                setCurrLoadFactorOnCp(cpIndex);
                m_currentBoundaryOp++;
                continueAdaptation = tryIncreaseLoadFactorsAndAdapt();
                break;
            } else if(m_initialCongestionState == CongestionState.CONGESTED) {
                m_currentBoundaryOp--;
            }
        }

        return continueAdaptation;
    }

    // Increases the load factors during adaptation if possible, by performing binary search to increase
    // query load on the data source. It is stateful across calls, storing the latest control proxy to
    // update load factors for in the current adaptation phase.
    public boolean tryIncreaseLoadFactorsAndAdapt() {
        boolean continueAdaptation = false;
        while(m_currentBoundaryOp >= 0 && m_currentBoundaryOp < m_sortedEffectiveCpsIdx.size()) {
            int cpIndex = m_sortedEffectiveCpsIdx.get(m_currentBoundaryOp);
            double currP = m_loadFactors[cpIndex].getLoadFactorCurrent();
            if(m_initialCongestionState == CongestionState.CLEAR) {
                // Save the latest configuration corresponding to CLEAR state
                m_loadFactors[cpIndex].setPrevLoadFactorWithClear(currP);
            }

            m_loadFactors[cpIndex].setLoadFactorLow(currP + m_probUpdateDelta);
            double highP = m_loadFactors[cpIndex].getLoadFactorHigh();
            double lowP = m_loadFactors[cpIndex].getLoadFactorLow();
            if (highP - lowP >= epsilon) {
                m_loadFactors[cpIndex].setLoadFactorCurrent(lowP + ((highP - lowP) / 2));
                setCurrLoadFactorOnCp(cpIndex);
                continueAdaptation = true;
                break;
            } else if (m_initialCongestionState == CongestionState.CONGESTED) {
                // Get previous CONGESTED state load factors
                JarvisLogger.info("Reverting to last load factor with congestion state");
                m_loadFactors[cpIndex].revertToLoadFactorWithCongestion();
                setCurrLoadFactorOnCp(cpIndex);
                m_currentBoundaryOp--;
                continueAdaptation = tryDecreaseLoadFactorsAndAdapt();
                break;
            } else if(m_initialCongestionState == CongestionState.CLEAR) {
                m_currentBoundaryOp++;
            }
        }

        return continueAdaptation;
    }
}

package com.jarvis.processors.edge.controlproxy;

import com.jarvis.processors.edge.IdleTimeStats;
import com.jarvis.processors.edge.RuntimeState;
import com.jarvis.processors.edge.data.IData;

// Interface for control proxy
public interface IControlProxy {
    // Put the data item into operator queue
    void put(IData item);

    // Put watermark into operator queue
    void putWaterMark(IData item);

    // Get the data to transfer over network as a byte array
    byte[] getByteArrayOutputStreamContent();

    // Reset the network transfer buffers
    void reset();

    // Block until watermark with seqNum arrives
    void waitForWatermarkWithSeqNum(int seqNum);

    // Used by Jarvis runtime after updating load factors, to wait for the next epoch records to arrive so that the query
    // state can be probed again with the new load factors. Enables coordination between Jarvis runtime and first control
    // proxy
    void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState);

    // Get recent idle time for probing by Jarvis runtime
    long getRecentIdleTime();

    // Get recent drained records for probing by Jarvis runtime
    int getRecentRecordsDrainedSize();

    // Get recent payload size sent to downstream operator on data source, used for probing by Jarvis runtime
    double getRecentPayloadSizeOnEdge();

    // Get recent records discarded, for probing by Jarvis runtime
    int getRecentRecordsDiscardedSize();

    // Get recent epoch duration, for probing by Jarvis runtime
    long getRecentEpochDuration();

    // Set load factor as probSendingToEdge
    void setProbSendingToEdge(double probSendingToEdge);

    // Get idle time for profiling by Jarvis runtime
    IdleTimeStats getIdleTimerVal();

    // Drain operator queue since new epoch arrived
    boolean tryDrainTillWatermark();

    // Enable operator queue to be drained
    void enableDrainQueuesAsap();

    // Disable draining on operator queue
    void disableDrainQueuesAsap();

    // Get idle time during adaptation for profiling by Jarvis runtime
    IdleTimeStats getRecentAdaptIdleTime();

    // Reset idle timer for next epoch
    void resetIdleTimer();

    // Set the Jarvis runtime state as "state"
    void setCurrRuntimeState(RuntimeState state);

    // Reads operator queue records
    IData take();

    // Get idle time of final control porxy
    IdleTimeStats getFinalCpRecentAdaptIdleTime();

    // Used for profiling pipeline
    void printAndResetQueueDebugStats();
}

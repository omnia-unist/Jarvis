package com.jarvis.processors.edge.controlproxy;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.data.IData;
import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Control proxy for the operator queue of first operator in query.
// A lot of the heavy-lifting for adaptation and coordination with Jarvis runtime is done by this control proxy.
public class FirstControlProxy implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Output m_networkOutput;
    Kryo m_kryo;
    CloudUploader m_cloudUploader;
    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
    AtomicBoolean queueDrained = new AtomicBoolean(false);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    AtomicLong m_incomingWmSeqNum = new AtomicLong(-1);
    private final Object watermarkLock = new Object();
    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);

    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);

    // Required for observing dataflow state after changing p_e values
    AtomicBoolean m_loadFactorsUpdatedByRuntimeFlag = new AtomicBoolean(false);
    AtomicBoolean m_monitorWatermarkId = new AtomicBoolean(false);
    private final Object m_newEpochLockV2 = new Object();
    private final Object m_idleTimeStatsLock = new Object();
    AtomicBoolean m_runtimeCanUpdateLoadFactorsV2 = new AtomicBoolean(false);

    // Control proxy variables
    volatile double m_probSendingToEdge;
    AtomicBoolean m_disableSendingToEdge = new AtomicBoolean(false);
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicBoolean m_discardedRecordsToUpload = new AtomicBoolean(false);
    RuntimeState m_currRuntimeState;
    RuntimeState m_prevRuntimeState;
    RuntimeState m_firstCpActiveRuntimeState;
    RuntimeState m_firstCpPrevRuntimeState;
    private int m_currSubEpochSize = 0;
    private int m_recordsPerSubEpoch = Integer.MAX_VALUE;
    private int m_totalNumSubEpochs = 0;
    private AtomicInteger m_totalInputRecords;
    boolean m_beginStreaming = true;

    AtomicInteger m_discardedRecordsCount = new AtomicInteger(0);
    AtomicInteger m_drainedRecordsCount = new AtomicInteger(0);
    AtomicInteger m_edgeRecordsCount = new AtomicInteger(0);

    final Object m_profilePhaseLock = new Object();
    AtomicBoolean m_epochWmArrivedForProfile = new AtomicBoolean(false);

    final Object m_probSendingToEdgeLock = new Object();
    final Object m_runtimeSynchronization = new Object();
    final Object m_currRuntimeStateLock = new Object();

    Random randGen = new Random();

    IdleTimeStats m_finalCpIdleTimeStats;
    IData m_waterMarkEntry;
    IData m_subEpochWatermarkEntry;
    IControlProxy m_outputQueue;
    IControlProxy[] m_internalCps;

    AtomicBoolean m_drainedAllQueues;
    Runtime m_runtime;
    String m_dataTypeAsString;

    AtomicBoolean m_previousTakeWasWm = new AtomicBoolean(false);

    BloomFilter m_bloomFilter;
    AtomicInteger m_latestWatermarkSeqNum = new AtomicInteger(-1);
    public FirstControlProxy(CloudUploader uploader, IData[] classesToRegister,
                             String dataTypeAsString, IControlProxy outputQueue, Runtime runtime,
                             int numSubEpochs, IControlProxy[] internalCps) {
        m_queueId = 0;
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }

        m_kryo.register(Integer.class);
        m_kryo.register(String.class);

        m_dataTypeAsString = dataTypeAsString;
        m_networkOutputStream = new ByteArrayOutputStream();
        m_networkOutput = new Output(m_networkOutputStream);
        m_cloudUploader = uploader;
        m_waterMarkEntry = DataUtils.getWatermarkMarker(dataTypeAsString, false);
        m_subEpochWatermarkEntry = DataUtils.getWatermarkMarker(dataTypeAsString, true);
        m_startEpochTimer.set(System.currentTimeMillis());
        m_drainedAllQueues = new AtomicBoolean(false);
        m_outputQueue = outputQueue;
        m_runtime = runtime;
        m_totalNumSubEpochs = numSubEpochs;
        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
        m_internalCps = internalCps;

        m_currRuntimeState = RuntimeState.STABLE;
        m_prevRuntimeState = RuntimeState.STABLE;
        m_firstCpActiveRuntimeState = RuntimeState.STABLE;
        m_firstCpPrevRuntimeState = RuntimeState.STABLE;
        // We are not considering hot keys in this branch code
        // loadBloomFilters();

        m_probSendingToEdge = Config.PARTITION_CONFIG == PartitioningConfig.ADAPT ? Config.m_beginLoadFactors.get(0)
                : 1.0;
        addMetadataToFlowfile();
    }

    // We are not considering hot keys in this branch code
    private void loadBloomFilters() {
        m_bloomFilter = BloomFilter.create(Funnels.byteArrayFunnel(), 1000);
        BigInteger val = new BigInteger("1032");
        m_bloomFilter.put(val.toByteArray());
        BigInteger val1 = new BigInteger("433");
        JarvisLogger.debug("Bloomg filter: " + m_bloomFilter.mightContain(val1.toByteArray()));
    }

    // Reads the output queue for first operator and sends records to next downstream operator
    public IData take() {
        IData takenVal = null;
        try{
            takenVal = queue.take();
            synchronized (watermarkLock) {
                if (takenVal.isWaterMark()) {
                    waterMarkCountInQueue.decrementAndGet();
                    queueDrained.set(true);

                    // Reset the epoch size to signify end of current epoch processing by operator
                    JarvisLogger.info("[FirstControlProxy.take] Size of recent window processed is: " +
                            m_currentEpochDataSizeSentToEdge + ", with watermark count: " + waterMarkCountInQueue.get());
                    m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
                    m_currentEpochDataSizeSentToEdge = 0;
                    m_previousTakeWasWm.set(true);
                    watermarkLock.notify();
//                }
                } else {
                    // Need to make sure if new epoch being read and in PROFILE phase, need to wait for entire epoch to become
                    // available in queue for sequential processing of an epoch
                    if (m_previousTakeWasWm.get() && m_firstCpActiveRuntimeState == RuntimeState.PROFILE) {
                        synchronized (m_profilePhaseLock) {
                            JarvisLogger.info("[FirstControlProxy.take] Going to wait for watermark in PROFILE phase ");
                            while (!m_epochWmArrivedForProfile.get()) {
                                m_profilePhaseLock.wait();
                            }

                            JarvisLogger.info("[FirstControlProxy.take] Finished waiting for watermark in PROFILE phase");
                            m_epochWmArrivedForProfile.set(false);
                        }

                        m_previousTakeWasWm.set(false);
                    }

                    m_currentEpochDataSizeSentToEdge += takenVal.isSubEpochMarker() ? 0 :
                            takenVal.getPayloadInBytes();
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[FirstControlProxy.take] Exception in dequeueuing " + ex.toString());
            ex.printStackTrace();
        }

        return takenVal;
    }

    // Adds metadata to the top of payload sent to stream processor.
    // Control proxy ID and data type of objects in payload are added, so the flowfile can be read easily and routed
    // on stream processor side
    private void addMetadataToFlowfile() {
        // The first thing we write is the CP ID and data type, so the flowfile can be read easily and routed
        // on stream processor side
        synchronized (watermarkLock) {
            m_kryo.writeObject(m_networkOutput, m_queueId);
            m_kryo.writeObject(m_networkOutput, m_dataTypeAsString);
        }
    }

    // Drains the current operator queue and sends remaining records to stream processor
    // NOTES:
    // 1) put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    // 2) tryDrainTilLWatermark does run on Jarvis Runtime thread during ADAPT phase,
    // but during this time, the put call is blocked waiting for all queues to be drained
    public boolean tryDrainTillWatermark() {
        IData takenVal;
        int recordsDrainedSize = 0;
        boolean watermarkExists = false;
        boolean recordsUploaded = false;

        synchronized (watermarkLock) {
            if(waterMarkCountInQueue.get() > 0 && !queueDrained.get()) {
                while (!watermarkExists && (takenVal = queue.poll()) != null) {
                    // Transfer all queue contents for current epoch to upload to stream processor
                    if (takenVal.isWaterMark()) {
                        watermarkExists = true;
                        try {
                            queue.put(takenVal);
                        } catch (Exception ex) {
                            JarvisLogger.debug("[FirstControlProxy.tryDrainTillWatermark] Couldn't " +
                                    "re-insert watermark");
                            ex.printStackTrace();
                        }

                        JarvisLogger.info("[FirstControlProxy.tryDrainTillWatermark] seen watermark while draining");
                    } else if(takenVal.isSubEpochMarker()) {
                        // Ignore sub-epoch markers when draining to cloud
                        continue;
                    }

                    takenVal.writeSelfToKryo(m_kryo, m_networkOutput);
                    m_drainedRecordsCount.incrementAndGet();
                    recordsDrainedSize += takenVal.getPayloadInBytes();
                }

                // If next operator reads the dequeued watermark before drainer thread could
                if(recordsDrainedSize > 0 && !watermarkExists) {
                    m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
                    recordsDrainedSize += m_waterMarkEntry.getPayloadInBytes();
                    watermarkExists = true;
                }

                JarvisLogger.info(m_queueId + " [FirstControlProxy.tryDrainTillWatermark] Total records ejected in this drain " +
                        "session is " + m_drainedRecordsCount.get() + " and " + "watermark count after draining is " +
                        waterMarkCountInQueue.get() +
                        " and queue size is " + size() + ", records drianed size is: " + recordsDrainedSize);
            }

            queueDrained.set(true);

            // If there were more records than just the watermark that were drained
            if(m_drainedRecordsCount.get() > 1 || m_discardedRecordsToUpload.get()) {
                // We need to add watermark if the kryo payload only contains discarded records
                if(!watermarkExists || m_drainedRecordsCount.get() == 0) {
                    m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
                }

                byte[] windowContent = getByteArrayOutputStreamContent();
                m_cloudUploader.addPayload(windowContent, m_latestWatermarkSeqNum.get());
                recordsUploaded = true;
                reset();
                m_discardedRecordsToUpload.set(false);
                addMetadataToFlowfile();
                JarvisLogger.info("[FirstControlProxy.tryDrainWaterMark] drained for watermark: " + m_latestWatermarkSeqNum.get() +
                        ", with window length: " + windowContent.length);
            }
        }

        int recordsWithoutWm = recordsDrainedSize > 0 && watermarkExists ?
                (recordsDrainedSize-m_waterMarkEntry.getPayloadInBytes()) :
                recordsDrainedSize;
        m_recentEpochRecordsDrainedSize.set(recordsWithoutWm);

        return recordsUploaded;
    }

    // Logs profiling information
    public void printAndResetQueueDebugStats() {
        JarvisLogger.info("[FirstControlProxy.printAndResetQueueDebugStats] Most recent epoch statistics: edge records sent to next op: " +
                (m_edgeRecordsCount.get() - m_drainedRecordsCount.get()) + ", discarded records: " +
                m_discardedRecordsCount.get() + ", drained " + "records: " + m_drainedRecordsCount.get());
        m_edgeRecordsCount.set(0);
        m_discardedRecordsCount.set(0);
        m_drainedRecordsCount.set(0);
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void put(IData item) {
        try {
            if (m_beginStreaming || lastPutWasWatermark.get()) {
                m_beginStreaming = false;
                int nextWatermarkSeqNum = m_latestWatermarkSeqNum.get() + 1;
                JarvisLogger.info(m_queueId + "[FirstControlProxy.put] New epoch entering, whose epoch number" +
                        " i.e. watermark seq num will be: " + nextWatermarkSeqNum);

                synchronized (m_idleTimeStatsLock) {
                    m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
                    m_startEpochTimer.set(System.currentTimeMillis());
                    m_incomingWmSeqNum.set(m_latestWatermarkSeqNum.get() + 1);
                    m_finalCpIdleTimeStats = m_outputQueue.getIdleTimerVal();
                }

                lastPutWasWatermark.set(false);
                tryDrainTillWatermark();
                printAndResetQueueDebugStats();
                JarvisLogger.info(m_queueId + "[FirstControlProxy.put] Enable draining in all internal CPs");
                for (IControlProxy cp :
                        m_internalCps) {
                    cp.enableDrainQueuesAsap();
                }

                m_outputQueue.waitForWatermarkWithSeqNum(m_latestWatermarkSeqNum.get());
                for (IControlProxy cp :
                        m_internalCps) {
                    cp.disableDrainQueuesAsap();
                }

                JarvisLogger.info(m_queueId + " [FirstControlProxy.put] Finished waiting for watermark on O/P queue: "
                        + m_latestWatermarkSeqNum.get() + ", and drained CP queues");
                if(m_latestWatermarkSeqNum.get() > Config.FIRST_EPOCH_TO_START_RUNTIME) {
                    JarvisLogger.info("[FirstControlProxy.put] Waiting for load factors to be updated by runtime");
                    synchronized (m_newEpochLockV2) {
                        m_runtimeCanUpdateLoadFactorsV2.set(true);
                        m_newEpochLockV2.notify();
                    }

                    synchronized (m_runtimeSynchronization) {
                        while (!m_loadFactorsUpdatedByRuntimeFlag.get()) {
                            m_runtimeSynchronization.wait();
                        }

                        JarvisLogger.info(m_queueId + "[FirstControlProxy.put] Load factors updated by runtime");
                        m_loadFactorsUpdatedByRuntimeFlag.set(false);
                    }
                }

                m_firstCpActiveRuntimeState = getCurrRuntimeState();
                updateRuntimeStateForAllCps(m_firstCpActiveRuntimeState);
                JarvisLogger.info("[FirstControlProxy.put] Runtime state for upcoming epoch is:" + m_firstCpActiveRuntimeState + ", " +
                        "and previous runtime state is: " + m_firstCpPrevRuntimeState);

                m_recordsPerSubEpoch = (int) (m_totalInputRecords.get() * getProbSendingToEdge()) / m_totalNumSubEpochs;
                m_currSubEpochSize = 0;
                m_totalInputRecords.set(0);
                JarvisLogger.info("[FirstControlProxy.put] Done waiting for runtime, going to add records to queue. " +
                        "Prob sending to edge is: " + getProbSendingToEdge() + ", and disable" +
                        " sending to edge flag is: " + m_disableSendingToEdge.get() + ", subepoch info:" +
                        "Expected records in subepoch: " + m_recordsPerSubEpoch + ", Total input records is: "
                                + m_totalInputRecords.get());
            }

            double randNum = randGen.nextDouble();
            m_totalInputRecords.getAndIncrement();

            if (!m_disableSendingToEdge.get() && randNum < getProbSendingToEdge()) {
                queue.put(item);
                m_currSubEpochSize++;
                m_edgeRecordsCount.incrementAndGet();
                if(m_currSubEpochSize % m_recordsPerSubEpoch == 0 &&
                    m_currSubEpochSize < (m_recordsPerSubEpoch * m_totalNumSubEpochs)) {
                    queue.put(m_subEpochWatermarkEntry);
                }
            } else {
                // Discard the record to cloud
                synchronized (watermarkLock) {
                    item.writeSelfToKryo(m_kryo, m_networkOutput);
                    m_currEpochRecordsDiscardedSize.addAndGet(item.getPayloadInBytes());
                    m_discardedRecordsToUpload.set(true);
                    m_discardedRecordsCount.incrementAndGet();
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void putWaterMark(IData watermark) {
        try {
            synchronized (watermarkLock) {
                while(waterMarkCountInQueue.get() > 0) {
                    watermarkLock.wait();
                }

                m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
                queue.put(watermark);
                waterMarkCountInQueue.incrementAndGet();
                queueDrained.set(false);
                m_latestWatermarkSeqNum.set(watermark.getSeqNum());
                JarvisLogger.info("[FirstControlProxy.putWaterMark] Watermark seen with seq num: " + watermark.getSeqNum()
                        + ", and watermark count in queue: " + waterMarkCountInQueue.get());
                lastPutWasWatermark.set(true);
            }

            if(m_firstCpActiveRuntimeState == RuntimeState.PROFILE) {
                synchronized (m_profilePhaseLock) {
                    m_epochWmArrivedForProfile.set(true);
                    m_profilePhaseLock.notify();
                }

                JarvisLogger.info("[FirstControlProxy.putWaterMark] Notified that watermark arrived for profile phase");
            }

        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Used by Jarvis runtime after updating load factors, to wait for the next epoch records to arrive so that the query
    // state can be probed again with the new load factors. Enables coordination between Jarvis runtime and first control
    // proxy
    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
        JarvisLogger.info("FirstControlProxy.waitForNewEpochAndGetWatermarkIdV2] Runtime notifying FirstControlProxy of load factor updates and waiting" +
                "to process next epoch with curr runtime state: " + m_currRuntimeState + ", and prev runtime state: " +
                m_prevRuntimeState);
        setCurrRuntimeState(currRuntimeState);
        try {
            if(m_latestWatermarkSeqNum.get() > Config.FIRST_EPOCH_TO_START_RUNTIME) {
                synchronized (m_runtimeSynchronization) {
                    m_loadFactorsUpdatedByRuntimeFlag.set(true);
                    m_runtimeSynchronization.notify();
                }
            }

            synchronized (m_newEpochLockV2) {
                while (!m_runtimeCanUpdateLoadFactorsV2.get()) {
                    m_newEpochLockV2.wait();
                }

                m_runtimeCanUpdateLoadFactorsV2.set(false);
            }

            JarvisLogger.info("[FirstControlProxy.waitForNewEpochAndGetWatermarkIdV2] Runtime can update load factors for new epoch now");
        } catch (Exception ex) {
            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkIdV2] Failed to get seq num: "
                    + ex.toString());
            ex.printStackTrace();
        }
    }

    public IdleTimeStats getFinalCpRecentAdaptIdleTime() {
        IdleTimeStats finalCpStats;
        synchronized (m_idleTimeStatsLock) {
            finalCpStats = m_finalCpIdleTimeStats;
        }

        return finalCpStats;
    }

    public int size() {
        return queue.size();
    }

    public byte[] getByteArrayOutputStreamContent() {
        try {
            m_networkOutput.flush();
            m_networkOutputStream.flush();
        } catch (Exception ex) {
            JarvisLogger.debug("[FirstControlProxy.getByteArrayOutputStreamContent] Error while clearing queue wrapper: " + ex.toString());
            ex.printStackTrace();
        }

        return m_networkOutputStream.toByteArray();
    }

    public void reset() {
        m_networkOutputStream.reset();
        m_networkOutput.reset();
    }

    public void clear() {
        queue.clear();
        try {
            m_networkOutputStream.flush();
            m_networkOutput.flush();
            m_networkOutputStream.reset();
            m_networkOutput.reset();
        } catch (Exception ex) {
            JarvisLogger.debug("[FirstControlProxy.clear] Error while clearing queue wrapper: " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Gets the idle time for determining query idle state
    public IdleTimeStats getRecentAdaptIdleTime() {
        long wm, startTime;
        synchronized (m_idleTimeStatsLock) {
            wm = m_incomingWmSeqNum.get();
            startTime = m_startEpochTimer.get();
        }
        return new IdleTimeStats(startTime, wm);
    }

    public void resetIdleTimer() {
        m_startIdleTimer.set(Long.MAX_VALUE);
    }

    private RuntimeState getCurrRuntimeState() {
        RuntimeState state;
        synchronized (m_currRuntimeStateLock) {
            state = m_currRuntimeState;
        }

        return state;
    }

    // Used to update Jarvis runtime state for all control proxies during adaptation
    private void updateRuntimeStateForAllCps(RuntimeState capturedJarvisRuntimeState) {
        synchronized (m_currRuntimeStateLock) {
            m_firstCpPrevRuntimeState = m_prevRuntimeState;
            m_firstCpActiveRuntimeState = capturedJarvisRuntimeState;
            for (IControlProxy cp :
                    m_internalCps) {
                cp.setCurrRuntimeState(m_firstCpActiveRuntimeState);
            }
        }
    }

    // Only the Jarvis Runtime updates the current runtime state of FirstControlProxy
    public void setCurrRuntimeState(RuntimeState state) {
        synchronized (m_currRuntimeStateLock) { // This lock is redundant
            m_prevRuntimeState = m_currRuntimeState;
            m_currRuntimeState = state;
        }
    }

    // Set load factor as probSendingToEdge
    public void setProbSendingToEdge(double probSendingToEdge) {
        synchronized (m_probSendingToEdgeLock) {
            JarvisLogger.info("[FirstContorlProxy.setProbSendingToEdge] New load factor: " + probSendingToEdge);
            m_probSendingToEdge = probSendingToEdge;
        }
    }

    // Get the current load factor
    public double getProbSendingToEdge() {
        double probReturnVal;
        synchronized (m_probSendingToEdgeLock) {
            probReturnVal = m_probSendingToEdge;
        }

        return probReturnVal;
    }

    public int getRecentRecordsDrainedSize() {
        int drainedRec = m_recentEpochRecordsDrainedSize.get();
        return drainedRec;
    }

    public int getRecentRecordsDiscardedSize() {
        return m_prevEpochRecordsDiscardedSize.get();
    }

    public void enableDrainQueuesAsap() {
        throw new UnsupportedOperationException("[FirstControlProxy.enableDrainQueuesAsap] First control proxy shouldn't need to set " +
                "flag to drain queues immediately");
    }

    public void disableDrainQueuesAsap() {
        throw new UnsupportedOperationException("[FirstControlProxy.disableDrainQueuesAsap] First control proxy shouldn't need to unset " +
                "flag to drain queues immediately");
    }

    public long getRecentIdleTime() {
        long idleTime = m_recentIdleTimeInMs.get();
        m_recentIdleTimeInMs.set(0);
        return idleTime;
    }

    // Gets epoch duration to determine fraction of idle time in current processing epoch
    public long getRecentEpochDuration() {
        long recentEpochTime;
        synchronized (m_idleTimeStatsLock) {
            recentEpochTime = m_recentEpochTimeInMs.get();
        }

        return recentEpochTime;
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }

    public void waitForWatermarkWithSeqNum(int seqNum) {
        // No op
        throw new UnsupportedOperationException();
    }

    public IdleTimeStats getIdleTimerVal() {
        // No op
        throw new UnsupportedOperationException();
    }
}

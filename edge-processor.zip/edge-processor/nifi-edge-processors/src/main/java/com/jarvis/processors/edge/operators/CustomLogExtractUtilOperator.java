package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.JarvisLogger;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.LogAnalyticUtilInfo;
import com.jarvis.processors.edge.data.IData;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import org.apache.commons.math3.util.Precision;

// Operator to parse logs and extract tenant job information from the logs
public class CustomLogExtractUtilOperator extends CustomOperator {
    LogAnalyticUtilInfo m_waterMarkEntry;
    LogAnalyticUtilInfo m_subEpochMarker;

    public CustomLogExtractUtilOperator(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntry = new LogAnalyticUtilInfo();
        m_waterMarkEntry.setWatermarkMarker();
        
        m_subEpochMarker = new LogAnalyticUtilInfo();
        m_subEpochMarker.setSubEpochMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                map(v -> {
                    String[] extractedTokens = v.toString().split(":=");
                    String srcCluster = extractedTokens[2];
                    String device = extractedTokens[3].split(" ")[0];
                    int util = Integer.parseInt(
                            extractedTokens[4].trim().replace("%",""));
                    return new LogAnalyticUtilInfo(srcCluster.trim(), device,
                            Precision.round((float) util, -1), 1);
                }).
                subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        if(!m_subEpochComplete.get()) {
                            m_waterMarkEntry.resetQueueTime();
                            m_waterMarkEntry.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                            m_recentEpochEndTime = System.currentTimeMillis();
                            m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                            JarvisLogger.info("[CustomLogExtractUtilOperator.onComplete] LP Solver op id: " + m_opId
                                    + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount
                                    + ", watermark: " + m_waterMarkSeqNum.get());
                            m_nextQueue.putWaterMark(m_waterMarkEntry);
                        } else {
                            m_subEpochComplete.set(false);
                            m_nextQueue.put(m_subEpochMarker);
                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            if(randGen.nextDouble() <= m_reductionRatio) {
                                data.resetQueueTime();
                                m_numOutRecords[0]++;
                                m_nextQueue.put(data);
                            }
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}


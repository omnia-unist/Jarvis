package com.jarvis.processors.edge.controlproxy;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.data.IData;
import org.apache.nifi.processor.Relationship;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

// Intermediate control proxy  to manage the queue buffers of intermediate operators in the query pipeline
public class ControlProxy implements IControlProxy {
    int m_queueId;
    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
    ByteArrayOutputStream m_networkOutputStream;
    Output m_networkOutput;
    Kryo m_kryo;
    CloudUploader m_cloudUploader;
    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
    AtomicBoolean queueDrained = new AtomicBoolean(false);
    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
    Object watermarkLock = new Object();
    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);
    AtomicLong m_recentWmSeqNum = new AtomicLong(0);

    // Required for observing dataflow state after changing p_e values
    AtomicBoolean m_monitorNewEpochAfterLoadChange = new AtomicBoolean(false);
    Object m_runtimeStateLock = new Object();

    // Control proxy variables
    volatile double m_probSendingToEdge;
    public volatile double m_prevEpochDataSizeSentToEdge = 0;
    private double m_currentEpochDataSizeSentToEdge = 0;
    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
    AtomicBoolean m_discardedRecordsToUpload = new AtomicBoolean(false);
    RuntimeState m_currRuntimeState;
    private AtomicInteger m_totalInputRecords;

    Object probSendingToEdgeLock = new Object();

    Random randGen = new Random();

    IData m_waterMarkEntry;
    IData m_subEpochWatermarkEntry;
    IControlProxy m_outputQueue;

    AtomicBoolean m_drainedAllQueues;
    AtomicBoolean m_drainQueuesAsap = new AtomicBoolean(false);
    AtomicBoolean m_previousTakeWasWm = new AtomicBoolean(false);
    AtomicBoolean m_epochWmArrivedForProfile = new AtomicBoolean(false);
    Object m_profilePhaseLock = new Object();

    AtomicInteger m_edgeRecordsCount = new AtomicInteger(0);
    AtomicInteger m_discardedRecordsCount = new AtomicInteger(0);
    AtomicInteger m_drainedRecordsCount = new AtomicInteger(0);

    String m_dataTypeAsString;
    boolean m_postStatefulOperator;
    BloomFilter m_bloomFilter;

    public ControlProxy(int queueId, IData[] classesToRegister,
                        String dataTypeAsString, CloudUploader uploader,
                        boolean postStatefulOperator) {
        m_queueId = queueId;
        m_kryo = new Kryo();
        for (IData classToRegister :
                classesToRegister) {
            m_kryo.register(classToRegister.getClass());
        }
        m_kryo.register(Integer.class);
        m_kryo.register(String.class);

        m_postStatefulOperator = postStatefulOperator;
        m_networkOutputStream = new ByteArrayOutputStream();
        m_networkOutput = new Output(m_networkOutputStream);
        m_cloudUploader = uploader;
        m_waterMarkEntry = DataUtils.getWatermarkMarker(dataTypeAsString, false);
        m_subEpochWatermarkEntry = DataUtils.getWatermarkMarker(dataTypeAsString, true);
        m_startEpochTimer.set(System.currentTimeMillis());
        m_drainedAllQueues = new AtomicBoolean(false);
        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
        m_dataTypeAsString = dataTypeAsString;
        m_probSendingToEdge = Config.PARTITION_CONFIG == PartitioningConfig.ADAPT ?
                Config.m_beginLoadFactors.get(m_queueId) : 1.0;
        m_currRuntimeState = RuntimeState.STABLE;
        synchronized(watermarkLock) {
            addMetadataToFlowfile();
        }
    }

    // Unsupported code: used for prioritizing processing of hot keys on data source which
    // Jarvis does not currently support yet.
    private void loadBloomFilters() {
        m_bloomFilter = BloomFilter.create(Funnels.byteArrayFunnel(), 1000);
        BigInteger val = new BigInteger("1032");
        m_bloomFilter.put(val.toByteArray());
        BigInteger val1 = new BigInteger("433");
        JarvisLogger.debug("Bloomg filter: " + m_bloomFilter.mightContain(val1.toByteArray()));
    }

    // Reads the operator queue and sends records to next downstream operator
    public IData take() {
        IData takenVal = null;
        try{
            takenVal = queue.take();
            synchronized (watermarkLock) {
                if (takenVal.isWaterMark()) {
                    waterMarkCountInQueue.decrementAndGet();
                    queueDrained.set(true);

                    // Reset the epoch size to signify end of current epoch processing by operator
                    JarvisLogger.info(m_queueId + " [ControlProxy.take] Size of records in epoch processed on edge: " +
                            m_currentEpochDataSizeSentToEdge + ", number of records: " +
                            (double) m_currentEpochDataSizeSentToEdge / (double) takenVal.getPayloadInBytes() + ", number of wms: "
                            + waterMarkCountInQueue.get() + ", watermakr ID: " +
                            takenVal.getSeqNum() + ", is subepoch marker? : " + takenVal.isSubEpochMarker());
                    m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
                    m_currentEpochDataSizeSentToEdge = 0;
                    m_previousTakeWasWm.set(true);
                    watermarkLock.notify();
//                }
                } else {
                    // Need to make sure if new epoch being read and in PROFILE phase, need to wait for entire epoch to become
                    // available in queue for sequential processing of an epoch
                    if (m_previousTakeWasWm.get() && getCurrRuntimeState() == RuntimeState.PROFILE) {
                        synchronized (m_profilePhaseLock) {
                            JarvisLogger.info(m_queueId + " [ControlProxy.take] Going to wait for watermark in PROFILE phase ");
                            while (!m_epochWmArrivedForProfile.get()) {
                                m_profilePhaseLock.wait();
                            }

                            JarvisLogger.info(m_queueId + " [ControlProxy.take] Finished waiting for watermark in PROFILE phase");
                            m_epochWmArrivedForProfile.set(false);
                        }

                        m_previousTakeWasWm.set(false);
                    }

                    m_currentEpochDataSizeSentToEdge += takenVal.isSubEpochMarker() ? 0 :
                            takenVal.getPayloadInBytes();
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[SyncQueue.take] Exception in dequeueuing " + ex.toString());
            ex.printStackTrace();
        }

        return takenVal;
    }

    // Drains the current operator queue and sends remaining records to stream processor
    // NOTES:
    // 1) put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    // 2) tryDrainTilLWatermark does run on Jarvis Runtime thread during ADAPT phase,
    // but during this time, the put call is blocked waiting for all queues to be drained
    public boolean tryDrainTillWatermark() {
        long start = System.currentTimeMillis();
        IData takenVal;
        int recordsDrainedSize = 0;
        boolean watermarkExists = false;
        boolean recordsUploaded = false;

        synchronized (watermarkLock) {
            if(waterMarkCountInQueue.get() > 0 && !queueDrained.get()) {
                JarvisLogger.info(m_queueId + " [ControlProxy.tryDrainTillWatermark] Watermark count for take is " +
                        waterMarkCountInQueue.get() + ", Queue size is " + size());
                while (!watermarkExists && (takenVal = queue.poll()) != null) {
                    // Transfer all queue contents for current window to stream processor upload
                    if (takenVal.isWaterMark()) {
                        watermarkExists = true;
                        try {
                            // Its fine to put the watermark back in the queue because in:
                            // Stable phase: only one thread will do put, putWatermark and tryDrainTilLWatermark
                            // Adapt phase: FirstControlProxy can also call tryDrainTillWatermark but will only
                            // execute it if an epoch's watermark is in queue, and while an epoch's watermark is still
                            // in internal queues, that means the watermark has not reached final queue. And only one
                            // epoch can be processed at a time by the whole query, so no new elements will be added
                            // to the queue when watermark is processed in tryDrainTillWatermark
                            // When entering ADAPT phase from STABLE: (1) it could be processing an epoch (in which case
                            // its like in ADAPT phase), (2) it could be finished processing all epochs (in which case also
                            // its like ADAPT), (3) it could be in middle of processing an epoch, while another has arrived
                            // so transition can happen during processing of current epoch (current epoch gets drained by
                            // FirstControlProxy, and new epoch won't be added to queue, instead drained OR ControlProxy
                            // drains queue and then new epoch won't be added to queue), or transition
                            // can happen after current epoch processed (in which case it starts getting drained),
                            // or it can happen when new epoch arrived (in which case its like earlier case)
                            // (4) its empty and new epoch has arrived (like case (3) last part)
                            // MAIN THING is to consider when FirstControlProxy drains, and put/putWatermark is being processed.
                            queue.put(takenVal);
                        } catch (Exception ex) {
                            JarvisLogger.debug("[SyncQueueWrapper.tryDrainTillWatermark] Couldn't " +
                                    "re-insert watermark");
                            ex.printStackTrace();
                        }

                    } else if(takenVal.isSubEpochMarker()) {
                        // Ignore sub-epoch markers when draining to cloud
                        continue;
                    }

                    takenVal.writeSelfToKryo(m_kryo, m_networkOutput);
                    m_drainedRecordsCount.incrementAndGet();
                    recordsDrainedSize += takenVal.getPayloadInBytes();
                }

                // If next operator dequeued watermark before drainer thread could finish
                if(recordsDrainedSize > 0 && !watermarkExists) {
                    m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
                    recordsDrainedSize += m_waterMarkEntry.getPayloadInBytes();
                    m_drainedRecordsCount.incrementAndGet();
                }

                JarvisLogger.info(m_queueId + " [ControlProxy.tryDrainWaterMark] records drained: " + recordsDrainedSize);
            }

            queueDrained.set(true);

            // We don't need to worry about discarded records as it is handled separately in tryUploadDiscardedRecords.
            // Discarded records are written in the same kryo object as the drained records
            if(m_drainedRecordsCount.get() >= 1) {
                byte[] windowContent = getByteArrayOutputStreamContent();
                m_cloudUploader.addPayload(windowContent, m_recentWmSeqNum.get());
                recordsUploaded = true;
                reset();

                m_discardedRecordsToUpload.set(false);
                addMetadataToFlowfile();
                JarvisLogger.info(m_queueId + " [ControlProxy.tryDrainTillWatermark] " +
                        "Uploaded drained/discarded records with watermark ID: " + m_recentWmSeqNum.get());
            }
        }

        int recordsWithoutWm = recordsDrainedSize > 0 ?
                (recordsDrainedSize-m_waterMarkEntry.getPayloadInBytes()) :
                recordsDrainedSize;
        m_recentEpochRecordsDrainedSize.set(recordsWithoutWm);

        return recordsUploaded;
    }

    // Discarded records are written to the same payload object as drained records
    private void tryUploadDiscardedRecords() {
        if(m_discardedRecordsToUpload.get()) {
            synchronized (watermarkLock) {
                m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
                byte[] windowContent = getByteArrayOutputStreamContent();
                m_cloudUploader.addPayload(windowContent, m_recentWmSeqNum.get());
                reset();
                m_discardedRecordsToUpload.set(false);
                addMetadataToFlowfile();
            }
        }
    }

    // Adds metadata to the top of payload sent to stream processor.
    // Control proxy ID and data type of objects in payload are added, so the flowfile can be read easily and routed
    // on stream processor side
    private void addMetadataToFlowfile() {
        int nextCpQueue = m_queueId;
        if(m_postStatefulOperator) {
            nextCpQueue--;
        }

        m_kryo.writeObject(m_networkOutput, nextCpQueue);
        m_kryo.writeObject(m_networkOutput, m_dataTypeAsString);
    }

    // Used for profiling the queues
    public void printAndResetQueueDebugStats() {
        JarvisLogger.info("[ControlProxy.printAndResetQueueDebugStats] Most recent epoch statistics: " +
                "edge records sent to next op: " + (m_edgeRecordsCount.get() - m_drainedRecordsCount.get()) +
                ", discarded records: " + m_discardedRecordsCount.get() + ", drained " + "records: " +
                m_drainedRecordsCount.get());
        m_edgeRecordsCount.set(0);
        m_discardedRecordsCount.set(0);
        m_drainedRecordsCount.set(0);
    }

    // Adds records into the operator queue. API for upstream operator to send processed records to next operator
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void put(IData item) {
        try {
            if(lastPutWasWatermark.get()) {
                JarvisLogger.info(m_queueId + " [ControlProxy.put] New epoch entering in queue " + m_queueId + ", with potential" +
                        " seq num:" + (m_recentWmSeqNum.get() + 1));

                m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
                m_startEpochTimer.set(System.currentTimeMillis());
                printAndResetQueueDebugStats();
                lastPutWasWatermark.set(false);
                m_totalInputRecords.set(0);
                JarvisLogger.info(m_queueId + " [ControlProxy.put] queueId:" + m_queueId +
                        ", adding records of new epoch with prob sending to edge is: " + m_probSendingToEdge);
            }

            double randNum = randGen.nextDouble();
            m_totalInputRecords.getAndIncrement();
            if (randNum < getProbSendingToEdge()) {
                queue.put(item);
                m_edgeRecordsCount.incrementAndGet();
            } else {
                synchronized (watermarkLock) {
                    // Discard the record to cloud
                    item.writeSelfToKryo(m_kryo, m_networkOutput);
                    m_currEpochRecordsDiscardedSize.addAndGet(item.getPayloadInBytes());
                    m_discardedRecordsCount.incrementAndGet();
                    m_discardedRecordsToUpload.set(true);
                }
            }
        } catch (Exception ex) {
            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Adds watermark to denote end of epoch for the next downstream operator.
    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
    public void putWaterMark(IData watermark) {
        try {
            synchronized (watermarkLock) {
                while(waterMarkCountInQueue.get() > 0) {
                    watermarkLock.wait();
                }

                m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
                queue.put(watermark);
                lastPutWasWatermark.set(true);
                waterMarkCountInQueue.incrementAndGet();
                queueDrained.set(false);
                m_recentWmSeqNum.set(watermark.getSeqNum());
                if(m_drainQueuesAsap.get()) {
                    // This means the query is in ADAPT phase and needs to drain asap since watermark arrived
                    if(!tryDrainTillWatermark()) {
                        tryUploadDiscardedRecords();
                    }
                } else {
                    tryUploadDiscardedRecords();
                }

                JarvisLogger.info(m_queueId + " [ControlProxy.putWaterMark] Watermark count in putWaterMark " +
                        waterMarkCountInQueue.get() + " and " + ", watermark seq num: " + watermark.getSeqNum());
            }

            if(getCurrRuntimeState() == RuntimeState.PROFILE) {
                synchronized (m_profilePhaseLock) {
                    m_epochWmArrivedForProfile.set(true);
                    m_profilePhaseLock.notify();
                }

                JarvisLogger.info(m_queueId + " [ControlProxy.putWaterMark] Notified that watermark is here in profile phase");
            }
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
            ex.printStackTrace();
        }
    }

    public IdleTimeStats getFinalCpRecentAdaptIdleTime() {
        throw new UnsupportedOperationException("Internal CP cannot get final CP stats");
    }

    public int size() {
        return queue.size();
    }

    // Clearing payload object for network transfer from data source
    public byte[] getByteArrayOutputStreamContent() {
        try {
            m_networkOutput.flush();
            m_networkOutputStream.flush();
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
            ex.printStackTrace();
        }

        return m_networkOutputStream.toByteArray();
    }

    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
        throw new UnsupportedOperationException("Runtime doesn't wait on final CP");
    }

    public void reset() {
        m_networkOutputStream.reset();
        m_networkOutput.reset();
    }

    // Clears queue and payload object for network transfer from data source
    public void clear() {
        queue.clear();
        try {
            m_networkOutputStream.flush();
            m_networkOutput.flush();
            m_networkOutputStream.reset();
            m_networkOutput.reset();
        } catch (Exception ex) {
            JarvisLogger.debug("[MY DEBUG]Error while clearing queue wrapper: " + ex.toString());
            ex.printStackTrace();
        }
    }

    public IdleTimeStats getRecentAdaptIdleTime() {
        IdleTimeStats stats = new IdleTimeStats(m_startEpochTimer.get(), m_recentWmSeqNum.get());
        return stats;
    }

    public void resetIdleTimer() {
        m_startIdleTimer.set(Long.MAX_VALUE);
    }

    // Sets the Jarvis runtiem state for adaptation
    public void setCurrRuntimeState(RuntimeState state) {
        synchronized (m_runtimeStateLock) {
            m_currRuntimeState = state;
            if (m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
                resetIdleTimer();
            }
        }
    }

    // Reads Jarvis runtiem state
    public RuntimeState getCurrRuntimeState() {
        RuntimeState state;
        synchronized (m_runtimeStateLock) {
            state = m_currRuntimeState;
        }

        return state;
    }

    // Set load factors
    public void setProbSendingToEdge(double probSendingToEdge) {
        synchronized (probSendingToEdgeLock) {
            JarvisLogger.info(m_queueId + " [ControlProxy.setProbSendingToEdge] " + " queueId: " + m_queueId +
                    ", New load factor: " + probSendingToEdge);
            m_probSendingToEdge = probSendingToEdge;
        }
    }

    // Reads current load factors
    public double getProbSendingToEdge() {
        double probReturnVal;
        synchronized (probSendingToEdgeLock) {
            probReturnVal = m_probSendingToEdge;
        }

        return probReturnVal;
    }

    public int getRecentRecordsDrainedSize() {
        int drainedRec = m_recentEpochRecordsDrainedSize.get();
        return drainedRec;
    }

    public int getRecentRecordsDiscardedSize() {
        return m_prevEpochRecordsDiscardedSize.get();
    }

    // Enables first control proxy to set intermediate control proxies for draining
    public void enableDrainQueuesAsap() {
        synchronized(watermarkLock) {
            // try draining, if not tell CP to drain ASAP and leave
            if(!tryDrainTillWatermark()) {
                m_drainQueuesAsap.set(true);
            }
        }
    }

    // First control proxy can disable intermediate control proxies for draining
    public void disableDrainQueuesAsap() {
        synchronized (watermarkLock) {
            JarvisLogger.info(m_queueId + " [ControlProxy.disableDrainQueuesAsap] Disabled drain queues for: " + m_queueId);
            m_drainQueuesAsap.set(false);
        }
    }

    // Enables Jarvis runtime to get idle time information for probing
    public long getRecentIdleTime() {
        long idleTime = m_recentIdleTimeInMs.get();
        m_recentIdleTimeInMs.set(0);
        return idleTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochTimeInMs.get();
    }

    public double getRecentPayloadSizeOnEdge() {
        double payloadSize = m_prevEpochDataSizeSentToEdge;
        return payloadSize;
    }

    public void waitForWatermarkWithSeqNum(int seqNum) {
        // No op
        throw new UnsupportedOperationException();
    }

    public IdleTimeStats getIdleTimerVal() {
        // No op
        throw new UnsupportedOperationException();
    }
}

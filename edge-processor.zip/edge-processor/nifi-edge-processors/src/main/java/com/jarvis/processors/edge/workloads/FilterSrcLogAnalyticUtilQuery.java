package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.WordCountEntity;
import com.jarvis.processors.edge.operators.CustomLogAnalyticFilterOperator;
import com.jarvis.processors.edge.operators.CustomLogAnalyticsGroupby;
import com.jarvis.processors.edge.operators.CustomOperator;

// Implements Filter-Src config for LogAnalytic query
public class FilterSrcLogAnalyticUtilQuery extends Workload {

    public FilterSrcLogAnalyticUtilQuery(CloudUploader cloudUploader) {
        super();

        classesToRegister = new IData[3];
        classesToRegister[0] = new WordCountEntity();
        classesToRegister[1] = new WordCountEntity();
        classesToRegister[2] = new WordCountEntity();
        m_dataTypesAsStrings = new String[3];
        m_dataTypesAsStrings[0] = "WordCountEntity";
        m_dataTypesAsStrings[1] = "WordCountEntity";
        m_dataTypesAsStrings[2] = "WordCountEntity";

        m_numOperators = 2;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, true}, cloudUploader);

        m_customOperators[0] = new CustomLogAnalyticFilterOperator(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_finalCp);

        m_customOperators[1] = new CustomLogAnalyticsGroupby(1, m_internalCps[0]);
        m_customOperators[1].setNextQueue(m_finalCp);
    }
}

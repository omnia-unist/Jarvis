package com.jarvis.processors.edge;

import java.util.Comparator;

// Used to compare operators based on their relay-ratios, enables sorting them based on
// relay-ratio based priority
public class VirtualOpsComparator implements Comparator<Integer> {
    private final Double[] m_array;

    public VirtualOpsComparator(Double[] array)
    {
        this.m_array = array;
    }

    public Integer[] createIndexArray()
    {
        Integer[] indexes = new Integer[m_array.length];
        for (int i = 0; i < m_array.length; i++)
        {
            indexes[i] = i; // Autoboxing
        }

        return indexes;
    }

    @Override
    public int compare(Integer index1, Integer index2)
    {
        // Autounbox from Integer to int to use as array indexes
        return m_array[index1].compareTo(m_array[index2]);
    }
}

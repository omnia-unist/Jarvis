package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.edge.Runtime;

// Stores count information for each ToR ID, used in T2TProbe query
public class ToRCountProbe implements IData {
    private int m_torId;
    private int m_count;
    private int m_seqNum;
    private long m_timeQueued;

    public void setTorId(int torId) {
        m_torId = torId;
    }

    public int getTorId() {
        return m_torId;
    }

    public void setCount(int count) {
        m_count = count;
    }

    public int getCount() {
        return m_count;
    }

    public int getSeqNum() {
        return m_seqNum;
    }

    public int getPayloadInBytes() {
        return (2 * Runtime.SIZE_OF_INT);
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for ToRCountProbe class");
    }

    public String getGroupingKey(boolean all) {
        throw new UnsupportedOperationException("getGroupingKey String not supported for ToRCountProbe class");
    }

    public void setSeqNum(int seqNum) {
        m_seqNum = seqNum;
    }

    public void resetQueueTime() {
        m_timeQueued = System.currentTimeMillis();
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - m_timeQueued);
    }

    public boolean isWaterMark() {
        return (this.m_torId == Integer.MIN_VALUE);
    }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, this);
    }

    public IData getEntity() {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getGroupingKey() {
        return m_torId;
    }

    public Integer getGroupingValue() {
        return m_count;
    }

    public void setWatermarkMarker() {
        m_torId = Integer.MIN_VALUE;
    }

    public void setGroupingKey(int key) {
        m_torId = key;
    }

    public void setEntity(IData data) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinKey() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setJoinKey(int key) {
        throw new UnsupportedOperationException();
    }

    public void setJoinValue(int value) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinValue() {
        // No op
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return m_seqNum + "," + m_torId + "," + m_count;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }

    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }

    public boolean isSubEpochMarker() {
        return (this.m_torId == Integer.MAX_VALUE);
    }

    public void setSubEpochMarker() {
        this.m_torId = Integer.MAX_VALUE;
    }

    public Integer getFilterPredVal() { return m_torId; }
}

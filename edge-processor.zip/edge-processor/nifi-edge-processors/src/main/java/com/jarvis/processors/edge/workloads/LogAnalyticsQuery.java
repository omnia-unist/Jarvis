package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.*;
import com.jarvis.processors.edge.operators.*;

// Implements LogAnalytics query
public class LogAnalyticsQuery extends Workload {

    public LogAnalyticsQuery(CloudUploader cloudUploader) {
        super();

        classesToRegister = new IData[4];
        classesToRegister[0] = new WordCountEntity();
        classesToRegister[1] = new WordCountEntity();
        classesToRegister[2] = new LogAnalyticUtilInfo();
        classesToRegister[3] = new LogAnalyticUtilHistCount();
        m_dataTypesAsStrings = new String[4];
        m_dataTypesAsStrings[0] = "WordCountEntity";
        m_dataTypesAsStrings[1] = "WordCountEntity";
        m_dataTypesAsStrings[2] = "LogAnalyticUtilInfo";
        m_dataTypesAsStrings[3] = "LogAnalyticUtilHistCount";

        m_numOperators = 3;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, false, true}, cloudUploader);

        m_customOperators[0] = new CustomLogAnalyticFilterOperator(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_internalCps[0]);

        m_customOperators[1] = new CustomLogExtractUtilOperator(1, m_internalCps[0]);
        m_customOperators[1].setNextQueue(m_internalCps[1]);

        m_customOperators[2] = new CustomLogAnalyticsGroupby(2, m_internalCps[1]);
        m_customOperators[2].setNextQueue(m_finalCp);
    }
}

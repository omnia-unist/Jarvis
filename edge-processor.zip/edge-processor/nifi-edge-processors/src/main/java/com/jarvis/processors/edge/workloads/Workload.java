package com.jarvis.processors.edge.workloads;

import com.esotericsoftware.kryo.Kryo;
import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.PartitioningConfig;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.controlproxy.*;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.operators.CustomOperator;
import org.apache.nifi.processor.Relationship;

import java.security.InvalidParameterException;

import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP;

// Abstract class to implement each of the query workloads
public abstract class Workload {
    // Number of query operators
    int m_numOperators;

    // CustomOperator instance for each operator
    CustomOperator[] m_customOperators;

    // Per-operator thread
    Thread[] m_operatorThreads;

    // Jarvis runtime thread
    Thread m_jarvisRuntimeThread;

    // Jarvis runtime instance
    Runtime m_jarvisRuntime;

    // List of internal control proxies
    IControlProxy[] m_internalCps;

    // Final control proxy
    IControlProxy m_finalCp;

    // First control proxy
    IControlProxy m_firstCp;

    // Number of sub-epochs
    int m_numSubEpochs;

    // Stores data types of intermediate data of query operators
    String[] m_dataTypesAsStrings;

    // Data types to register for Kryo object
    IData[] classesToRegister;

    // Uploader object for network data transfer
    CloudUploader m_cloudUploader;

    // Starts workload after initializing workload object and parameters
    public void beginWorkload(int srcDataSizeInBytes) {
        for (int i = 0; i < m_numOperators; i++) {
            m_operatorThreads[i] = new Thread(m_customOperators[i]);
            m_operatorThreads[i].start();
        }

        if(Config.PARTITION_CONFIG == PartitioningConfig.ADAPT) {
            m_jarvisRuntime.setQueryOps(m_customOperators);
            m_jarvisRuntime.setSrcDataSizeInBytes(srcDataSizeInBytes);
            m_jarvisRuntimeThread = new Thread(m_jarvisRuntime);
            m_jarvisRuntimeThread.start();
        }
    }

    // Sets the queues and Jarvis runtime to execute the workload
    // Argument contains the post stateful op flag for final and internal CPs
    protected void setQueuesAndRuntime(boolean[] postStatefulOperatorFlags, CloudUploader cloudUploader) {
        m_cloudUploader = cloudUploader;
        if(m_dataTypesAsStrings.length != m_numOperators + 1) {
            throw new UnsupportedOperationException("[Workload.setQueuesAndRuntime] data type for each queue is not " +
                    "provided: ");
        }
        if(Config.TO_DRAIN) {
            if(Config.PARTITION_CONFIG == PartitioningConfig.ADAPT) {
                m_jarvisRuntime = new Runtime();
            }

            m_finalCp = new FinalControlProxy(m_numOperators, classesToRegister,
                    m_dataTypesAsStrings[m_dataTypesAsStrings.length - 1], m_cloudUploader,
                    postStatefulOperatorFlags[postStatefulOperatorFlags.length-1]);
            for(int i = 0; i < m_internalCps.length; i++) {
                m_internalCps[i] = new ControlProxy(i + 1, classesToRegister, m_dataTypesAsStrings[i + 1],
                        m_cloudUploader, postStatefulOperatorFlags[i]);
            }

            m_firstCp = new FirstControlProxy(m_cloudUploader, classesToRegister, m_dataTypesAsStrings[0],
                    m_finalCp, m_jarvisRuntime,
                    m_numSubEpochs, m_internalCps);
            if(Config.PARTITION_CONFIG == PartitioningConfig.ADAPT) {
                m_jarvisRuntime.setCps(m_firstCp, m_finalCp, m_internalCps);
            }
        } else {
            m_finalCp = new FinalControlProxyNoAdapt(m_numOperators, classesToRegister,
                    m_dataTypesAsStrings[m_dataTypesAsStrings.length - 1], m_cloudUploader,
                    postStatefulOperatorFlags[postStatefulOperatorFlags.length-1]);
            for(int i = 0; i < m_internalCps.length; i++) {
                m_internalCps[i] = new ControlProxyNoAdapt(i + 1, classesToRegister);
            }

            m_firstCp = new FirstControlProxyNoAdapt(classesToRegister,
                    m_finalCp, m_internalCps);
        }
    }

    // Gets first control proxy
    public IControlProxy getFirstCp() {
        return m_firstCp;
    }
}

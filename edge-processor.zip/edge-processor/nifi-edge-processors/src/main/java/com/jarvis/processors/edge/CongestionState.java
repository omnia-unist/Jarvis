package com.jarvis.processors.edge;

// Enum to store congestion state for the query
public enum CongestionState {
    CONGESTED,
    CLEAR,
    STABLE,
    PROFILE,
    START,
    COOL_DOWN,
}

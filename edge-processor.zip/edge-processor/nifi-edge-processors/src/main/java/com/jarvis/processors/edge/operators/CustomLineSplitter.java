package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.data.WordCountEntity;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// Used to split lines in log based queries, and then perform count-based aggregation
public class CustomLineSplitter extends CustomOperator {

    WordCountEntity m_waterMarkEntry;
    WordCountEntity m_subEpochMarker;
    private final String WHITE_SPACE = "[\\p{Punct}\\s]+";
    private final Map<String, Integer> wordCountMap = new ConcurrentHashMap<>();

    public CustomLineSplitter(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntry = new WordCountEntity();
        m_waterMarkEntry.setWatermarkMarker();

        m_subEpochMarker = new WordCountEntity();
        m_subEpochMarker.setSubEpochMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
            map(v -> { return v; }).
            subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        // Send every word count into next queue after first sorting it
                        for (String wordKey :
                                wordCountMap.keySet()) {
                            int wordKeyCount = wordCountMap.get(wordKey);
                            if(wordKeyCount >= 3) {
                                WordCountEntity wordCountEntity = new WordCountEntity(
                                        wordKey,
                                        wordKeyCount);
                                m_nextQueue.put(wordCountEntity);
                            }
                        }

                        wordCountMap.clear();
                        if(!m_subEpochComplete.get()) {
                            m_waterMarkEntry.resetQueueTime();
                            JarvisLogger.info(m_opId + " [CustomLineSplitter.onComplete] created watermark: " +
                                    m_waterMarkSeqNum.get());
                            m_waterMarkEntry.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                            m_recentEpochEndTime = System.currentTimeMillis();
                            m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                            JarvisLogger.info("[CustomLineSplitter.onComplete] Thread ID is: " +
                                    Thread.currentThread().getId() + ", epoch duration is: " +
                                    m_recentEpochDuration + ", record count: " + m_currentEpochRecordCount);
                            m_nextQueue.putWaterMark(m_waterMarkEntry);
                        } else {
                            m_subEpochComplete.set(false);
                            m_nextQueue.put(m_subEpochMarker);
                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            if(randGen.nextDouble() <= m_reductionRatio) {
                                data.resetQueueTime();
                                List<String> wordsAsStrings = Stream.of(data.toString().toLowerCase().
                                        replace('k', 'i').
                                        split(WHITE_SPACE)).
                                        filter(word -> (word.length() > 2 && !word.contains("\\s+BNB\\s+"))).
                                        collect(Collectors.toList());
                                wordsAsStrings.forEach( word -> wordCountMap.compute(word,
                                        (key, value) -> value == null ? 1 : value+1));
                                m_numOutRecords[0]++;
                            }
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
            );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}


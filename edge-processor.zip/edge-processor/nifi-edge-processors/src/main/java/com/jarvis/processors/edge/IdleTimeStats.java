package com.jarvis.processors.edge;

// Stores idle time statistics for query, used by Jarvis runtime
public class IdleTimeStats {
    private long m_startTimer;
    private long m_waterMark;

    public IdleTimeStats(long startTimer, long wm) {
        m_startTimer = startTimer;
        m_waterMark = wm;
    }

    public long getStartTimer() {
        return m_startTimer;
    }

    public  long getWaterMark() {
        return m_waterMark;
    }

}

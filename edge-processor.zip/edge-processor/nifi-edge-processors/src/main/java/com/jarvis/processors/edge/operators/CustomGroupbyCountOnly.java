package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.JarvisLogger;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.SrcClusterStatsKryo;
import com.jarvis.processors.edge.data.ToRCountProbe;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Custom operator that performs count based aggregation, used in T2TProbe query
public class CustomGroupbyCountOnly extends  CustomOperator {
    ToRCountProbe m_waterMarkEntryWithTime;
    ToRCountProbe m_subEpochMarkerWithTime;
    private final Map<Integer, List<IData>> groupedTable = new ConcurrentHashMap<>();

    public CustomGroupbyCountOnly(int opId, IControlProxy currentQueue) {
        super(opId, currentQueue, 1);
        m_waterMarkEntryWithTime = new ToRCountProbe();
        m_waterMarkEntryWithTime.setWatermarkMarker();

        m_subEpochMarkerWithTime = new ToRCountProbe();
        m_subEpochMarkerWithTime.setSubEpochMarker();
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
            subscribe(new Observer<IData>() {
                @Override
                public void onSubscribe(Disposable d) {}

                @Override
                public void onComplete() {
                    // Send every entity count into next queue after first sorting it
                    for (Integer groupKey :
                            groupedTable.keySet()) {
                        int count = groupedTable.get(groupKey).size();
                        ToRCountProbe toRCountProbe = new ToRCountProbe();
                        toRCountProbe.setTorId(groupKey);
                        toRCountProbe.setCount(count);

                        m_nextQueue.put(toRCountProbe);
                    }

                    groupedTable.clear();
                    if(!m_subEpochComplete.get()) {
                        m_waterMarkEntryWithTime.resetQueueTime();
                        JarvisLogger.info(m_opId + " [CustomGroupbyNonRxJava.onComplete] created watermark: " +
                                m_waterMarkSeqNum.get());
                        m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                        m_recentEpochEndTime = System.currentTimeMillis();
                        m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                        JarvisLogger.info("[CustomGroupbyNonRxJavaV1.onComplete] Thread ID is: " +
                                Thread.currentThread().getId() +
                                ", epoch duration is: " + m_recentEpochDuration +
                                ", number of records=" + m_currentEpochRecordCount +
                                ", watermark seq num is: " + m_waterMarkEntryWithTime.getSeqNum());
                        m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                    } else {
                        m_subEpochComplete.set(false);
                        m_nextQueue.put(m_subEpochMarkerWithTime);
                    }
                }

                @Override
                public void onError(Throwable throwable) {
                }

                @Override
                public void onNext(IData data) {
                    try {
                        data.resetQueueTime();
                        int groupingKey = data.getGroupingKey();
                        if(groupedTable.containsKey(groupingKey)) {
                            groupedTable.get(groupingKey).add(data);
                        } else {
                            groupedTable.put(groupingKey, new ArrayList<>());
                            groupedTable.get(groupingKey).add(data);
                        }

                        m_numOutRecords[0]++;
                    } catch (Exception e) {
                        JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                    }
                }

            }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public Integer[] getOutputRecCount() {
        return m_numOutRecords;
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }

}

package com.jarvis.processors.edge.data;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.edge.Runtime;

// Stores the histogram count for each bucket, defined by the dimensions of (tenant name, job latency, cpu util, memory util)
// in LogAnalytics query
public class LogAnalyticUtilHistCount implements IData {
    // Stores the job info dimensions used for bucketing as a single string for aggregation
    private String m_jobInfoSummary;

    // Stores count of items in the bucket defined by dimensions of (tenant name, job latency, cpu util, memory util)
    private int m_count;
    private int m_seqNum;
    private long m_timeQueued;

    public void setCount(int count) { m_count = count; }

    public void setSrcCluster(String srcCluster) {
        m_jobInfoSummary = srcCluster;
    }

    public int getSeqNum() {
        return m_seqNum;
    }

    public int getPayloadInBytes() {
        return (2 * Runtime.SIZE_OF_INT) + m_jobInfoSummary.getBytes().length;
    }

    public void setSeqNum(int seqNum) {
        m_seqNum = seqNum;
    }

    public void resetQueueTime() {
        m_timeQueued = System.currentTimeMillis();
    }

    public String getGroupingKey(boolean all) {
        return m_jobInfoSummary;
    }

    public void convertToLowerCase() {
        throw new UnsupportedOperationException("convertToLowerCase not supported for SrcClusterStatsKryo class");
    }

    public long getQueueTime() {
        return (System.currentTimeMillis() - m_timeQueued);
    }

    public boolean isWaterMark() {
        return (this.m_jobInfoSummary.equals("watermark"));
    }

    public void writeSelfToKryo(Kryo kryo, Output output) {
        kryo.writeObject(output, this);
    }

    public IData getEntity() {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getGroupingKey() {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public Integer getGroupingValue() {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public void setWatermarkMarker() {
        m_jobInfoSummary = "watermark";
    }

    public boolean isSubEpochMarker() {
        return (this.m_jobInfoSummary.equals("subepochMarker"));
    }

    public void setSubEpochMarker() {
        this.m_jobInfoSummary = "subepochMarker";
    }

    public void setGroupingKey(int key) {
        throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount");
    }

    public int getCount() {
        return m_count;
    }

    public void setEntity(IData data) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinKey() {
        // No op
        throw new UnsupportedOperationException();
    }

    public void setJoinKey(int key) {
        throw new UnsupportedOperationException();
    }

    public void setJoinValue(int value) {
        // No op
        throw new UnsupportedOperationException();
    }

    public Integer getJoinValue() {
        // No op
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return m_seqNum + "," + m_jobInfoSummary + "," + m_count;
    }

    public boolean isJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }


    public void setJoinMismatchMarker() {
        // No op
        throw new UnsupportedOperationException("SrcClusterStatsKryo doesn't have join marker");
    }


    public Integer getFilterPredVal() { throw new UnsupportedOperationException("Not supported for LogAnalyticUtilHistCount"); }
}

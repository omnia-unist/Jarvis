//package com.jarvis.processors.edge.controlproxy;
//
//import com.esotericsoftware.kryo.Kryo;
//import com.esotericsoftware.kryo.io.Output;
//import com.google.common.hash.BloomFilter;
//import com.google.common.hash.Funnels;
//import com.jarvis.processors.edge.CloudUploader;
//import com.jarvis.processors.edge.JarvisLogger;
//import com.jarvis.processors.edge.Runtime;
//import com.jarvis.processors.edge.RuntimeState;
//import com.jarvis.processors.edge.data.IData;
//import org.apache.nifi.processor.Relationship;
//
//import java.io.ByteArrayOutputStream;
//import java.math.BigInteger;
//import java.util.Random;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.concurrent.atomic.AtomicInteger;
//import java.util.concurrent.atomic.AtomicLong;
//
//public class FirstControlProxyV1 implements IControlProxy {
//    int m_queueId;
//    LinkedBlockingQueue<IData> queue = new LinkedBlockingQueue<>();
////    LinkedBlockingQueue<T> m_networkQueue = new LinkedBlockingQueue<>();
//    ByteArrayOutputStream m_networkOutputStream;
//    Output m_networkOutput;
//    Kryo m_kryo;
//    int m_threshold;
//    CloudUploader m_cloudUploader;
//    AtomicInteger waterMarkCountInQueue = new AtomicInteger(0);
//    AtomicBoolean queueDrained = new AtomicBoolean(false);
//    AtomicBoolean lastPutWasWatermark = new AtomicBoolean(false);
//    AtomicBoolean m_drainageJustFinished = new AtomicBoolean(false);
//    Object watermarkLock = new Object();
//    private AtomicLong m_startIdleTimer = new AtomicLong(Long.MAX_VALUE);
//    private AtomicLong m_startEpochTimer = new AtomicLong(Long.MAX_VALUE);
//    AtomicLong m_recentIdleTimeInMs = new AtomicLong(0);
//    AtomicLong m_recentEpochTimeInMs = new AtomicLong(0);
//
//    AtomicBoolean triggerDrainageCommandRuntime = new AtomicBoolean(false);
//
//    // Required for observing dataflow state after changing p_e values
//    AtomicBoolean m_loadFactorsUpdatedByRuntimeFlag = new AtomicBoolean(false);
//    AtomicBoolean m_monitorWatermarkId = new AtomicBoolean(false);
//    Object m_newEpochLock = new Object();
//    Object m_newEpochLockV2 = new Object();
////    AtomicInteger m_runtimeCanUpdateLoadFactors = new AtomicInteger(-1);
//    AtomicBoolean m_runtimeCanUpdateLoadFactors = new AtomicBoolean(false);
//    AtomicBoolean m_runtimeCanUpdateLoadFactorsV2 = new AtomicBoolean(false);
//
//    // Control proxy variables
//    volatile double m_probSendingToEdge = 1;
//    AtomicBoolean m_disableSendingToEdge = new AtomicBoolean(false);
//    public volatile double m_prevEpochDataSizeSentToEdge = 0;
//    private double m_currentEpochDataSizeSentToEdge = 0;
//    AtomicInteger m_recentEpochRecordsDrainedSize = new AtomicInteger(0);
//    AtomicInteger m_currEpochRecordsDiscardedSize = new AtomicInteger(0);
//    AtomicInteger m_prevEpochRecordsDiscardedSize = new AtomicInteger(0);
//    RuntimeState m_currRuntimeState;
//    RuntimeState m_prevRuntimeState;
//    private int m_currSubEpochSize = 0;
//    private int m_recordsPerSubEpoch = Integer.MAX_VALUE;
//    private AtomicInteger m_totalSubEpochsCount = new AtomicInteger(0);
//    private int m_totalNumSubEpochs = 0;
//    private int m_currSubEpochsCount = 0;
//    private AtomicInteger m_totalInputRecords;
//    boolean m_beginStreaming = true;
//
//    Object m_probSendingToEdgeLock = new Object();
//    Object m_runtimeSynchronization = new Object();
//    Object m_currRuntimeStateLock = new Object();
//
//    Random randGen = new Random();
//
//    IData m_waterMarkEntry;
//    IData m_subEpochWatermarkEntry;
////    IQueue[] m_controlProxies;
//    IControlProxy m_outputQueue;
//    IControlProxy[] m_internalCps;
//
//    AtomicBoolean m_drainedAllQueues;
//    AtomicBoolean m_drainQueueForAdapt = new AtomicBoolean(false);
//
//    Runtime m_runtime;
//
//    BloomFilter m_bloomFilter;
////    private EpochProcessingState m_epochProcessingState;
//    AtomicInteger m_latestWatermarkSeqNum = new AtomicInteger(-1);
//    AtomicInteger m_latestEpochEntered = new AtomicInteger(-1);
//    public FirstControlProxyV1(int threshold, Kryo kryo, Relationship MY_RELATIONSHIP, IData watermarkEntry,
//                               IData subWatermarkEntry, FinalControlProxy outputQueue, Runtime runtime,
//                               int numSubEpochs, IControlProxy[] internalCps) {
//        m_queueId = 0;
//        m_threshold = threshold;
////        m_kryo = new Kryo();
//        m_kryo = kryo;
//        m_networkOutputStream = new ByteArrayOutputStream();
//        m_networkOutput = new Output(m_networkOutputStream);
//        m_cloudUploader = new CloudUploader(MY_RELATIONSHIP);
//        m_waterMarkEntry = watermarkEntry;
//        m_subEpochWatermarkEntry = subWatermarkEntry;
//        m_startEpochTimer.set(System.currentTimeMillis());
//        m_drainedAllQueues = new AtomicBoolean(false);
//        m_outputQueue = outputQueue;
//        m_runtime = runtime;
//        m_totalNumSubEpochs = numSubEpochs;
//        m_totalInputRecords = new AtomicInteger(Integer.MAX_VALUE);
////        m_epochProcessingState = EpochProcessingState.NORMAL;
//        m_internalCps = internalCps;
//        m_currRuntimeState = RuntimeState.STABLE;
//        m_prevRuntimeState = RuntimeState.STABLE;
//        // We are not considering hot keys in this branch code
//        // loadBloomFilters();
//    }
//
////    // Used to determine whether the epochs should start being processing using sub-epochs or not
////    private enum EpochProcessingState {
////        NORMAL,
////        SUB_EPOCH
////    }
//
//    private void loadBloomFilters() {
//        m_bloomFilter = BloomFilter.create(Funnels.byteArrayFunnel(), 1000);
//        BigInteger val = new BigInteger("1032");
//        m_bloomFilter.put(val.toByteArray());
//        BigInteger val1 = new BigInteger("433");
//        JarvisLogger.debug("Bloomg filter: " + m_bloomFilter.mightContain(val1.toByteArray()));
//    }
//
////    public void setControlProxies(IQueue...controlProxies) {
////        m_controlProxies = controlProxies;
////    }
//
//    public IData take() {
//        IData takenVal = null;
//        try{
//
////            if(m_fullDrainModeEnabled.get()) {
////                tryDrainTillWatermark();
////            }
//
//            takenVal = queue.take();
//            if (takenVal.isWaterMark()) {
//                synchronized (watermarkLock) {
//                    waterMarkCountInQueue.decrementAndGet();
//                    queueDrained.set(true);
//                    if(queue.size() == 0 && m_currRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//                        m_startIdleTimer.set(System.currentTimeMillis());
//                        JarvisLogger.debug(m_queueId + " [FirstControlProxy.take] start timer is " +
//                                m_startIdleTimer.get());
//                    }
//
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.take] After reading outside of lock, " +
//                            "watermark size in take is " + waterMarkCountInQueue.get());
//
//                    // Reset the window size to signify end of current window processing by operator
//                    m_prevEpochDataSizeSentToEdge = m_currentEpochDataSizeSentToEdge;
//                    m_currentEpochDataSizeSentToEdge = 0;
////                   m_startIdleTimer.compareAndSet(Long.MAX_VALUE, System.currentTimeMillis());
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.take] Size of recent window processed is " +
//                            m_prevEpochDataSizeSentToEdge);
//                    watermarkLock.notify();
//                }
//            } else {
//                m_currentEpochDataSizeSentToEdge += takenVal.isSubEpochMarker() ? 0 :
//                        takenVal.getPayloadInBytes();
//            }
//
//        } catch (Exception ex) {
//            JarvisLogger.debug("[FirstControlProxy.take] Exception in dequeueuing " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return takenVal;
//    }
//
//    // TODO: Run with thread pool instead of creating new thread
//    // TODO: Evaluate with async drainage too
//    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
//    // Note that tryDrainTilLWatermark does run on Jarvis Runtime thread during ADAPT phase,
//    // but during this time, the put call is blocked waiting for all queues to be drained
//    public boolean tryDrainTillWatermark() {
//        long start = System.currentTimeMillis();
//        IData takenVal;
//        int numRecords = 0;
//        int recordsDrainedSize = 0;
//        boolean watermarkFound = false;
//
//        // Additional condition: && !m_drainBlocked.get()
//        if((waterMarkCountInQueue.get() > 0 || m_drainQueueForAdapt.get())
//                && !queueDrained.get()) {
//            synchronized (watermarkLock) {
//                // Additional condition: && !m_drainBlocked.get()
//                if((waterMarkCountInQueue.get() > 0  || m_drainQueueForAdapt.get())
//                        && !queueDrained.get()) {
//                    JarvisLogger.debug(m_queueId + "[FirstControlProxy.tryDrainTillWatermark] Watermark count for take is " +
//                            waterMarkCountInQueue.get() + ", Queue size is " + size());
//                    while (!watermarkFound && (takenVal = queue.poll()) != null) {
//                        // Transfer all queue contents for current window to cloud upload
//                        if (takenVal.isWaterMark()) {
//                            watermarkFound = true;
//                            try {
//                                queue.put(takenVal);
//                            } catch (Exception ex) {
//                                JarvisLogger.debug("[FirstControlProxy.tryDrainTillWatermark] Couldn't " +
//                                        "re-insert watermark");
//                                ex.printStackTrace();
//                            }
//
////                            m_startIdleTimer.compareAndSet(Long.MAX_VALUE, System.currentTimeMillis());
//                        } else if(takenVal.isSubEpochMarker()) {
//                            // Ignore sub-epoch markers when draining to cloud
//                            continue;
//                        }
//
//                        takenVal.writeSelfToKryo(m_kryo, m_networkOutput);
//                        numRecords++;
//                        recordsDrainedSize += takenVal.getPayloadInBytes();
//                    }
//
//                    // If next op reader dequeued watermark before drainer thread could
//                    if(recordsDrainedSize > 0 && !watermarkFound) {
//                        m_waterMarkEntry.writeSelfToKryo(m_kryo, m_networkOutput);
//                    }
//
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.tryDrainTillWatermark] Total records ejected in this drain " +
//                            "session is " + numRecords + " and " + "watermark count for take is " +
//                            waterMarkCountInQueue.get() +
//                            " and queue size is " + size() + ", records drianed size is: " + recordsDrainedSize);
//                }
//
//                queueDrained.set(true);
//                m_drainQueueForAdapt.set(false);
//            }
//
//            // If there was more than just the watermark
//            if(numRecords > 1) {
//                byte[] windowContent = getByteArrayOutputStreamContent();
//                m_cloudUploader.sendToCloud(windowContent);
//                reset();
//            }
//        }
//
//        int recordsWithoutWm = watermarkFound ?
//                (recordsDrainedSize-m_waterMarkEntry.getPayloadInBytes()) :
//                recordsDrainedSize;
//        m_recentEpochRecordsDrainedSize.set(recordsWithoutWm);
//        return true;
//    }
//
//
//    // TODO: evaluate synchronous vs. asynchronous design, don't use locks here if possible
//    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
//    public void put(IData item) {
//        try {
//            if (m_beginStreaming || lastPutWasWatermark.get()) {
//                int nextWatermarkSeqNum = m_latestWatermarkSeqNum.get() + 1;
//                JarvisLogger.info(m_queueId + "[FirstControlProxy.put] New epoch entering, whose epoch number" +
//                        " i.e. watermark seq num will be: " + nextWatermarkSeqNum);
//                JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Queue size on put " + size() +
//                        ", records drianed size: "
//                        + m_recentEpochRecordsDrainedSize.get());
//
//                m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
//                m_startEpochTimer.set(System.currentTimeMillis());
//
//                lastPutWasWatermark.set(false);
//                tryDrainTillWatermark();
//
//                // When we enter ADAPT for first time, we don't want to double update load factors?
//                if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    synchronized (m_newEpochLockV2) {
//                        m_runtimeCanUpdateLoadFactorsV2.set(true);
//                        m_newEpochLockV2.notify();
//                    }
//
//                    JarvisLogger.debug("[FirstControlProxy.put] trying to drain first cp queue, runtimestate: " + m_currRuntimeState);
//                    m_recentIdleTimeInMs.set(System.currentTimeMillis() - m_startIdleTimer.get());
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] start timer: " + m_startIdleTimer.get()
//                            + ", " + "recent idle time: " + m_recentIdleTimeInMs.get());
//                    m_startIdleTimer.set(Long.MAX_VALUE);
//                } else if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    JarvisLogger.debug("Setting internal CPs to be in adapt phase, enabling draining asap");
//                    JarvisLogger.info(m_queueId + "[FirstControlProxy.put] In adapt phase, setting all internal CPs to adapt");
//                    for (IControlProxy cp :
//                            m_internalCps) {
//                        cp.setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
//                        cp.enableDrainQueuesAsap();
////                        cp.enableDrainQueuesAsap();
//                    }
//
////                    if(m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    JarvisLogger.debug("[FirstControlProxy.put] going to wait for watermark with seq num: " + m_latestWatermarkSeqNum.get() +
//                            ", repeating watermark sequence is ok because we need to clear up the ");
//                    // Waiting again for watermark Id which runtime already waited for, is okbecause we need
//                    // to clear up all the queues
//                    m_outputQueue.waitForWatermarkWithSeqNum(m_latestWatermarkSeqNum.get());
//                    JarvisLogger.info(m_queueId + " [FirstControlProxy.put] Finished waiting for watermark on O/P queue: " + m_latestWatermarkSeqNum.get());
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Finished waiting for watermark. Now Disable draining on all internal Cps");
//                    for (IControlProxy cp :
//                            m_internalCps) {
//                        cp.disableDrainQueuesAsap();
////                        cp.enableDrainQueuesAsap();
//                    }
//
//                    if(m_prevRuntimeState!=RuntimeState.STABLE) {
//                        synchronized (m_newEpochLockV2) {
//                            m_runtimeCanUpdateLoadFactorsV2.set(true);
//                            m_newEpochLockV2.notify();
//                        }
//
//                        JarvisLogger.debug("[FirstControlProxy.put] waiting on runtime to update load factors by checking flag " +
//                                "m_loadFactorsUpdatedByRuntimeFlag, prevRuntimeState: " + m_prevRuntimeState + ", currRuntimeState:" +
//                                m_currRuntimeState);
//                        synchronized (m_runtimeSynchronization) {
//                            while (!m_loadFactorsUpdatedByRuntimeFlag.get()) {
//                                m_runtimeSynchronization.wait();
//                            }
//
//                            JarvisLogger.info(m_queueId + "[FirstControlProxy.put] Load factors updated by runtime");
//                            m_loadFactorsUpdatedByRuntimeFlag.set(false);
//                        }
//                    }
//
//                    if(m_currRuntimeState == RuntimeState.STABLE) {
//                        JarvisLogger.debug("[FirstControlProxy.put] Set current runtime state to stable on all internal Cps");
//                        for (IControlProxy cp :
//                                m_internalCps) {
//                            cp.setCurrRuntimeState(m_currRuntimeState);
//                        }
//                    } else {
//                        JarvisLogger.debug("[FirstControlProxy.put] Number of subepochs is " + m_currSubEpochsCount +
//                                ", and size is " + m_currSubEpochSize);
//                        m_recordsPerSubEpoch = (int) (m_totalInputRecords.get() * m_probSendingToEdge) / m_totalNumSubEpochs;
//                        m_currSubEpochSize = 0;
//                        m_currSubEpochsCount = 0;
//                        JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Expected records in subepoch: " +
//                                m_recordsPerSubEpoch + ", Total input records is: " + m_totalInputRecords.get());
//                    }
//                }
//
//                setCurrRuntimeState(m_currRuntimeState);
//                m_totalInputRecords.set(0);
//                JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Done waiting for Runtime. Going to add " +
//                        "records to queue. ");
//            }
//
//            if(false || lastPutWasWatermark.get()) {
//                int nextWatermarkSeqNum = m_latestWatermarkSeqNum.get() + 1;
//                JarvisLogger.info(m_queueId + "[FirstControlProxy.put] New epoch entering, whose epoch number" +
//                        " i.e. watermark seq num will be: " + nextWatermarkSeqNum);
//                JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Queue size on put " + size() +
//                        ", records drianed size: "
//                        + m_recentEpochRecordsDrainedSize.get());
//
//                m_recentEpochTimeInMs.set(System.currentTimeMillis() - m_startEpochTimer.get());
//                m_startEpochTimer.set(System.currentTimeMillis());
//
//                lastPutWasWatermark.set(false);
////                boolean runtimeChangedLoadFactors = false;
//
////                synchronized (m_runtimeSynchronization) {
////                    runtimeChangedLoadFactors = m_loadFactorsUpdatedByRuntimeFlag.get();
////                }
//
////                if (runtimeChangedLoadFactors) {
//
////                    m_monitorWatermarkId.set(true);
////                    m_epochProcessingState= EpochProcessingState.SUB_EPOCH;
//                    // So the next put on first control proxy will drain all queues first
//                    // Only the first control proxy needs to know about being in ADAPT_NOPROBING phase
////                    setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
//
////                    JarvisLogger.debug("[FirstControlProxy.put] runtime synthronization epoch prepare flag from " +
////                            "runtime is true, setting rest of Cps to adapt");
////                    for (IControlProxy cp :
////                            m_internalCps) {
////                        cp.setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
////                        cp.enableDrainQueuesAsap();
//////                        cp.enableDrainQueuesAsap();
////                    }
////                }
//
////                boolean runtimeWaiting = false;
////                if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
////                    synchronized (m_newEpochLock) {
////                        runtimeWaiting = !m_runtimeCanUpdateLoadFactors.get();
////                    }
////
////                }
//
//                if (m_currRuntimeState == RuntimeState.ADAPT_NOPROBING || m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    JarvisLogger.info(m_queueId + " [FirstControlProxy.put] current runtime state: " + m_currRuntimeState
//                            + ", prev runtime state: " + m_prevRuntimeState);
//                    if(m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                        JarvisLogger.debug("[FirstControlProxy.put] setting m_runtimeCanUpdateLoadFactors to true so runtime thread " +
//                                "is unblocked and can observe Cps. " +
//                                "Current state: " + m_currRuntimeState + ", prev runtime state: " + m_prevRuntimeState);
//                        synchronized (m_newEpochLock) {
////                            m_runtimeCanUpdateLoadFactors.set(m_latestWatermarkSeqNum);
//                            JarvisLogger.info(m_queueId + "[FirstControlProxy.put] Releasing runtime thread to update " +
//                                    "load factors and going to wait till its updated");
//                            m_runtimeCanUpdateLoadFactors.set(true);
//                            m_newEpochLock.notify();
//                        }
//                    }
//
////                      setCurrRuntimeState(m_runtime.waitUntilAllPreviousEpochsProcessed());
////                      setCurrRuntimeState(m_runtime.waitUntilRuntimeUpdatesLoadFactors());
//
//                    // Wait for runtime to upload load factors and returns control to FirstControlProxy
//                    JarvisLogger.debug("[FirstControlProxy.put] waiting on runtime to update load factors by checking flag " +
//                            "m_loadFactorsUpdatedByRuntimeFlag, prevRuntimeState: " + m_prevRuntimeState + ", currRuntimeState:" +
//                            m_currRuntimeState);
//                    synchronized (m_runtimeSynchronization) {
//                        while (!m_loadFactorsUpdatedByRuntimeFlag.get()) {
//                            m_runtimeSynchronization.wait();
//                        }
//
//                        JarvisLogger.info(m_queueId + "[FirstControlProxy.put] Load factors updated by runtime");
//                        m_loadFactorsUpdatedByRuntimeFlag.set(false);
//                    }
//                }
//
////                JarvisLogger.debug("[FirstControlProxy.put] trying to drain first cp queue");
////                tryDrainTillWatermark();
////                JarvisLogger.debug("[FirstControlProxy.put] completed drain of first cp queue");
//
////                if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING || m_loadFactorsUpdatedByRuntimeFlag.get()) {
//                if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    tryDrainTillWatermark();
//                    JarvisLogger.debug("Setting internal CPs to be in adapt phase, enabling draining asap");
//                    JarvisLogger.info(m_queueId + "[FirstControlProxy.put] In adapt phase, setting all internal CPs to adapt");
//                    for (IControlProxy cp :
//                            m_internalCps) {
//                        cp.setCurrRuntimeState(RuntimeState.ADAPT_NOPROBING);
//                        cp.enableDrainQueuesAsap();
////                        cp.enableDrainQueuesAsap();
//                    }
//
////                    if(m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                    JarvisLogger.debug("[FirstControlProxy.put] going to wait for watermark with seq num: " + m_latestWatermarkSeqNum.get() +
//                            ", repeating watermark sequence is ok because we need to clear up the ");
//                    // Waiting again for watermark Id which runtime already waited for, is okbecause we need
//                    // to clear up all the queues
//                    m_outputQueue.waitForWatermarkWithSeqNum(m_latestWatermarkSeqNum.get());
//                    JarvisLogger.info(m_queueId + " [FirstControlProxy.put] Finished waiting for watermark on O/P queue: " + m_latestWatermarkSeqNum.get());
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Finished waiting for watermark. Now Disable draining on all internal Cps");
//                    for (IControlProxy cp :
//                            m_internalCps) {
//                        cp.disableDrainQueuesAsap();
////                        cp.enableDrainQueuesAsap();
//                    }
//
//                    // New epoch is ready to be sent at this point
////                    JarvisLogger.debug("[FirstControlProxy.put] getting runtime synchronization lock again for setting to false");
////                    synchronized (m_runtimeSynchronization) {
////                        m_prepareNewEpochAfterLoadChange.set(false);
////                    }
//
////                    if (m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
////                        JarvisLogger.debug("[FirstControlProxy.put] getting epoch lock to notify about runtime updating load");
////                        synchronized (m_newEpochLock) {
//////                            m_runtimeCanUpdateLoadFactors.set(m_latestWatermarkSeqNum);
////                            m_runtimeCanUpdateLoadFactors.set(true);
////                            m_newEpochLock.notify();
////                        }
////
//////                      setCurrRuntimeState(m_runtime.waitUntilAllPreviousEpochsProcessed());
//////                      setCurrRuntimeState(m_runtime.waitUntilRuntimeUpdatesLoadFactors());
////
////                        // Wait for runtime to upload load factors and returns control to FirstControlProxy
////                        JarvisLogger.debug("[FirstControlProxy.put] getting runtime synrhonization to wait for epoch after load change");
////                        synchronized (m_runtimeSynchronization) {
////                            while (!m_loadFactorsUpdatedByRuntimeFlag.get()) {
////                                m_runtimeSynchronization.wait();
////                            }
////
//////                            m_loadFactorsUpdatedByRuntimeFlag.set(false);
////                        }
////                    }
//
////                    if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
////                    } else if (m_prevRuntimeState == RuntimeState.STABLE) {
////                        // Send adapt marker to subsequent operators to change to ADAPT_NOPROBING state
////                        // Instead of immediately converting all operators to move to ADAPT_NOPROBING state,
////                        // sending them on the stream makes sure the previous epoch data is drained as normally
////                        // would, and only the next epoch onwards is drained in ADAPT_NOPROBING phase
////                        PingMeshKryo adaptMarker = new PingMeshKryo();
////                        adaptMarker.setAdaptBeginMarker();
////                        PingMeshKryoWithTime adaptMarkerWithTime = new PingMeshKryoWithTime();
////                        adaptMarkerWithTime.setEntity(adaptMarker);
////                        queue.put(adaptMarkerWithTime);
////                        m_outputQueue.waitForWatermarkWithSeqNum(m_latestWatermarkSeqNum);
////                    }
//
//                    // reset sub-epoch parameters
//                    JarvisLogger.debug("[FirstControlProxy.put] Number of subepochs is " + m_currSubEpochsCount +
//                            ", and size is " + m_currSubEpochSize);
//                    m_recordsPerSubEpoch = (int) (m_totalInputRecords.get() * m_probSendingToEdge) / m_totalNumSubEpochs;
//                    m_currSubEpochSize = 0;
//                    m_currSubEpochsCount = 0;
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Expected records in subepoch: " +
//                            m_recordsPerSubEpoch + ", Total input records is: " + m_totalInputRecords.get());
////                    } else {
////                        for (IControlProxy cp :
////                                m_internalCps) {
////                            cp.setCurrRuntimeState(m_currRuntimeState);
//////                        cp.enableDrainQueuesAsap();
////                        }
//
////                        synchronized (m_runtimeSynchronization) {
////                            m_prepareNewEpochAfterLoadChange.set(false);
////                        }
////                    }
//                } else if(m_currRuntimeState != RuntimeState.ADAPT_NOPROBING) {
//
//                    JarvisLogger.info(m_queueId + " [FirstControlProxy.put] In stable phase, with prev runtime state: " + m_prevRuntimeState);
//                    if(m_prevRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                        JarvisLogger.debug("[FirstControlProxy.put] Set current runtime state to stable on all internal Cps");
//                        for (IControlProxy cp :
//                                m_internalCps) {
//                            cp.setCurrRuntimeState(m_currRuntimeState);
////                        cp.enableDrainQueuesAsap();
//                        }
//                    }
//
//                    JarvisLogger.debug("[FirstControlProxy.put] trying to drain first cp queue, runtimestate: " + m_currRuntimeState);
//                    tryDrainTillWatermark();
//                    m_recentIdleTimeInMs.set(System.currentTimeMillis() - m_startIdleTimer.get());
//                    JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] start timer: " + m_startIdleTimer.get()
//                            + ", " + "recent idle time: " + m_recentIdleTimeInMs.get());
//                    m_startIdleTimer.set(Long.MAX_VALUE);
//                }
//
//                setCurrRuntimeState(m_currRuntimeState);
//                m_totalInputRecords.set(0);
//                JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Done waiting for Runtime. Going to add " +
//                        "records to queue. ");
//            }
//
//            double randNum = randGen.nextDouble();
//            m_totalInputRecords.getAndIncrement();
//
//            synchronized (m_probSendingToEdgeLock) {
//                if (!m_disableSendingToEdge.get() && randNum < m_probSendingToEdge) {
//                    queue.put(item);
//                    if(m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                        m_currSubEpochSize++;
//                        if(m_currSubEpochSize % m_recordsPerSubEpoch == 0 &&
//                            m_currSubEpochSize < (m_recordsPerSubEpoch * m_totalNumSubEpochs)) {
//                            queue.put(m_subEpochWatermarkEntry);
//                            m_currSubEpochsCount++;
////                            JarvisLogger.debug(m_queueId + " [FirstControlProxy.put] Added subepoch marker to " +
////                                    "close epoch #" +
////                                    m_currSubEpochsCount + ", and subepoch size: " + m_currSubEpochSize);
//                        }
//                    }
//                } else {
//                    // Discard the record to cloud
//                    item.writeSelfToKryo(m_kryo, m_networkOutput);
//                    m_currEpochRecordsDiscardedSize.addAndGet(item.getPayloadInBytes());
//                }
//            }
//        } catch (Exception ex) {
//            JarvisLogger.debug(m_queueId + " [MY DEBUG] Exception in queueuing " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    // put, putWaterMark and tryDrainTillWatermark have to run on a single thread
//    public void putWaterMark(IData watermark) {
//        try {
//            m_latestWatermarkSeqNum.set(watermark.getSeqNum());
////            if(m_monitorWatermarkId.get()) {
////                m_monitorNewEpochAfterLoadChange.set(false);
////                m_monitorWatermarkId.set(false);
//
////                synchronized (m_newEpochLock) {
////                    m_epochIdAfterLoadFactorsChanged.set(watermark.getSeqNum());
////                    m_newEpochLock.notify();
////                }
////            }
//
//            synchronized (watermarkLock) {
//                while(waterMarkCountInQueue.get() > 0) {
//                    watermarkLock.wait();
//                }
//
//                waterMarkCountInQueue.incrementAndGet();
//                queue.put(watermark);
//                queueDrained.set(false);
//                m_prevEpochRecordsDiscardedSize.set(m_currEpochRecordsDiscardedSize.getAndSet(0));
//                JarvisLogger.debug(m_queueId + " [FirstControlProxy.putWaterMark] Watermark count in putWaterMark " +
//                        waterMarkCountInQueue.get() + " and " + " size is " + size() + ", watermark seq num: " +
//                        watermark.getSeqNum());
//                JarvisLogger.info(m_queueId + " [FirstControlProxy.put] Watermark seen with seq num: " + watermark.getSeqNum());
//            }
//
//
////            m_networkQueue.put(watermark);
////            PingMeshKryo waterMarkEntryKryoOnly = ((PingMeshKryoWithTime)watermark).getEntity();
////            m_kryo.writeObject(m_networkOutput, waterMarkEntryKryoOnly);
////            m_cloudUploader.sendToCloud();
//            lastPutWasWatermark.set(true);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[MY DEBUG] Exception in watermarking " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    public void waitForNewEpochAndGetWatermarkIdV2(RuntimeState currRuntimeState) {
//        int seqNum=0;
//        setCurrRuntimeState(currRuntimeState);
//        JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Previous runtime state: " + m_prevRuntimeState +
//                ", current runtime state:" + m_currRuntimeState);
//        try {
//            synchronized (m_newEpochLockV2) {
////              while (m_runtimeCanUpdateLoadFactors.get() == -1) {
//                while (!m_runtimeCanUpdateLoadFactorsV2.get()) {
//                    // The second condition would not be required
//                    //                while(m_recentSeqNum.get() == -1 ||
//                    //                        (m_currRuntimeState == RuntimeState.ADAPT_NOPROBING &&
//                    //                                !m_drainedAllQueues.get())) {
//                    m_newEpochLockV2.wait();
//                }
//
//                m_runtimeCanUpdateLoadFactorsV2.set(false);
//            }
//
////            synchronized (m_runtimeSynchronization) {
////                m_loadFactorsUpdatedByRuntimeFlag.set(false);
////            }
//
////            seqNum = m_runtimeCanUpdateLoadFactors.getAndSet(-1);
//            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Runtime thread, Seq num is : " + seqNum);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Failed to get seq num: "
//                    + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    public int waitForNewEpochAndGetWatermarkId(RuntimeState currRuntimeState) {
////        int seqNum = -1;
//        int seqNum=0;
//        setCurrRuntimeState(currRuntimeState);
//        JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Previous runtime state: " + m_prevRuntimeState +
//                ", current runtime state:" + m_currRuntimeState);
//        try {
//            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] runtime jarvis got runtime synchronization flag waiting for new epoch");
//            synchronized (m_runtimeSynchronization) {
//                m_loadFactorsUpdatedByRuntimeFlag.set(true);
//                m_runtimeSynchronization.notify();
//            }
//
//            if (currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//                JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] runtime got epoch lock to wait on whether it can update load factors");
//                synchronized (m_newEpochLock) {
////                while (m_runtimeCanUpdateLoadFactors.get() == -1) {
//                    while (!m_runtimeCanUpdateLoadFactors.get()) {
//                        // The second condition would not be required
////                while(m_recentSeqNum.get() == -1 ||
////                        (m_currRuntimeState == RuntimeState.ADAPT_NOPROBING &&
////                                !m_drainedAllQueues.get())) {
//                        m_newEpochLock.wait();
//                    }
//
//                    m_runtimeCanUpdateLoadFactors.set(false);
//                }
//
//                seqNum = m_latestWatermarkSeqNum.get();
//            } else {
//                seqNum = m_latestWatermarkSeqNum.get() + 1;
//            }
//
////            synchronized (m_runtimeSynchronization) {
////                m_loadFactorsUpdatedByRuntimeFlag.set(false);
////            }
//
////            seqNum = m_runtimeCanUpdateLoadFactors.getAndSet(-1);
//            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Runtime thread, Seq num is : " + seqNum);
//        } catch (Exception ex) {
//            JarvisLogger.debug("[FirstControlProxy.waitForNewEpochAndGetWatermarkId] Failed to get seq num: "
//                    + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return seqNum;
//    }
//
//    public int size() {
//        return queue.size();
//    }
//
//    public byte[] getByteArrayOutputStreamContent() {
//        try {
//            m_networkOutput.flush();
//            m_networkOutputStream.flush();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[FirstControlProxy.getByteArrayOutputStreamContent] Error while clearing queue wrapper: " + ex.toString());
//            ex.printStackTrace();
//        }
//
//        return m_networkOutputStream.toByteArray();
//    }
//
//    public void reset() {
//        m_networkOutputStream.reset();
//        m_networkOutput.reset();
//    }
//
//    public void clear() {
//        queue.clear();
//        try {
//            m_networkOutputStream.flush();
//            m_networkOutput.flush();
//            m_networkOutputStream.reset();
//            m_networkOutput.reset();
//        } catch (Exception ex) {
//            JarvisLogger.debug("[FirstControlProxy.clear] Error while clearing queue wrapper: " + ex.toString());
//            ex.printStackTrace();
//        }
//    }
//
//    // Runtime related functions
//    public void disableSendingToEdge() {
//        m_disableSendingToEdge.set(true);
//        setProbSendingToEdge(0);
//    }
//
//    public void enableSendingToEdgeFlagOnly() {
//        m_disableSendingToEdge.set(false);
//    }
//
//    public void enableSendingToEdge() {
//        enableSendingToEdgeFlagOnly();
//        setProbSendingToEdge(1);
//    }
//
//    private void waitForRuntimeAfterLoadChange() {
//
//    }
//
//    public void setSelfObserve() {
//        m_loadFactorsUpdatedByRuntimeFlag.set(true);
//    }
//
//    public long getRecentAdaptIdleTime() {
//        return m_startEpochTimer.get();
//    }
//
//    public void resetIdleTimer() {
//        m_startIdleTimer.set(Long.MAX_VALUE);
//    }
//
//    // Only the Jarvis Runtime updates the current runtime state of FirstControlProxy
//    public void setCurrRuntimeState(RuntimeState state) {
//        synchronized (m_currRuntimeStateLock) { // This lock is redundant
//            m_prevRuntimeState = m_currRuntimeState;
//            m_currRuntimeState = state;
//        }
////        if (state == RuntimeState.STABLE) {
////            m_epochProcessingState = EpochProcessingState.NORMAL;
////        }
//    }
//
//    public void setProbSendingToEdge(double probSendingToEdge) {
//        synchronized (m_probSendingToEdgeLock) {
//            m_probSendingToEdge = probSendingToEdge;
//        }
//    }
//
//    public double getProbSendingToEdge() {
//        double probReturnVal;
//        synchronized (m_probSendingToEdgeLock) {
//            probReturnVal = m_probSendingToEdge;
//        }
//
//        return probReturnVal;
//    }
//
//    public int getRecentRecordsDrainedSize() {
//        int drainedRec = m_recentEpochRecordsDrainedSize.get();
//        m_recentEpochRecordsDrainedSize.set(0);
//        return drainedRec;
//    }
//
//    public int getRecentRecordsDiscardedSize() {
//        return m_prevEpochRecordsDiscardedSize.get();
//    }
//
//    public void enableDrainQueuesAsap() {
//        throw new UnsupportedOperationException("[FirstControlProxy.enableDrainQueuesAsap] First control proxy shouldn't need to set " +
//                "flag to drain queues immediately");
//    }
//
//    public void disableDrainQueuesAsap() {
//        throw new UnsupportedOperationException("[FirstControlProxy.disableDrainQueuesAsap] First control proxy shouldn't need to unset " +
//                "flag to drain queues immediately");
//    }
//
//    public long getRecentIdleTime() {
//        if(m_queueId!=0 && m_currRuntimeState == RuntimeState.ADAPT_NOPROBING) {
//            throw new UnsupportedOperationException("[FirstControlProxy.getRecentIdleTime] Can't get recent idle time for CP which is not the first CP");
//        }
//
//        long idleTime = m_recentIdleTimeInMs.get();
//        m_recentIdleTimeInMs.set(0);
//        return idleTime;
//    }
//
//    public long getRecentEpochDuration() {
//        return m_recentEpochTimeInMs.get();
//    }
//
//    public double getRecentPayloadSizeOnEdge() {
//        double payloadSize = m_prevEpochDataSizeSentToEdge;
//        m_prevEpochDataSizeSentToEdge = 0;
//        return payloadSize;
//    }
//
//    public void waitForWatermarkWithSeqNum(int seqNum) {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public void unseeWatermark() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//
//    public long getIdleTimerVal() {
//        // No op
//        throw new UnsupportedOperationException();
//    }
//}

package com.jarvis.processors.edge.operators;

import com.jarvis.processors.edge.*;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

// Map operator used to implement custom transforms on input records
public class CustomMapOperator extends CustomOperator {

    IData m_waterMarkEntryWithTime;
    IData m_subEpochMarkerWithTime;

    public CustomMapOperator(int opId, IControlProxy currentQueue, double reductionRatio,
                             IData watermark, IData subepochMarker) {
        super(opId, currentQueue, reductionRatio);
        m_waterMarkEntryWithTime = watermark;
        m_subEpochMarkerWithTime = subepochMarker;
    }

    public void setNextQueue(IControlProxy queue) {
        m_nextQueue = queue;
    }

    public void setDataflow() {
        Long startDataflowBuild = System.currentTimeMillis();
        m_subject = io.reactivex.subjects.PublishSubject.create();
        m_subject.
                map(v -> {
                    return v;
                }).
                subscribe(
                new Observer<IData>() {
                    @Override
                    public void onSubscribe(Disposable d) {}

                    @Override
                    public void onComplete() {
                        if(!m_subEpochComplete.get()) {
                            m_waterMarkEntryWithTime.resetQueueTime();
                            m_waterMarkEntryWithTime.setSeqNum(m_waterMarkSeqNum.getAndIncrement());
                            m_recentEpochEndTime = System.currentTimeMillis();
                            m_recentEpochDuration = m_recentEpochEndTime - m_startEpoch;
                            JarvisLogger.info("[CustomMapOperator.onComplete] LP Solver op id: " + m_opId
                                    + ", epoch duration is: " + m_recentEpochDuration + ", records: " + m_currentEpochRecordCount);
                            m_nextQueue.putWaterMark(m_waterMarkEntryWithTime);
                        } else {
                            m_subEpochComplete.set(false);
                            m_nextQueue.put(m_subEpochMarkerWithTime);
                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                    }

                    @Override
                    public void onNext(IData data) {
                        try {
                            if(randGen.nextDouble() <= m_reductionRatio) {
                                data.resetQueueTime();
                                m_numOutRecords[0]++;
                                m_nextQueue.put(data);
                            }
                        } catch (Exception e) {
                            JarvisLogger.debug("Couldn't write to output stream : " + e.toString());
                        }
                    }

                }
        );

        m_dataflowBuildDur=(System.currentTimeMillis() - startDataflowBuild);
    }

    public double getProfileEpochStartTime() {
        return m_startEpoch;
    }

    public double getProfileEpochEndTime() {
        return m_recentEpochEndTime;
    }

    public long getRecentEpochDuration() {
        return m_recentEpochDuration;
    }
}


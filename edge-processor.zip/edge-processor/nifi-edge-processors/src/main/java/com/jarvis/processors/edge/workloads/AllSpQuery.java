package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.operators.CustomMapOperator;
import com.jarvis.processors.edge.operators.CustomOperator;

// Implements All-SP query for S2SProbe
public class AllSpQuery extends Workload {

    PingMeshKryoWithTime m_waterMarkEntryWithTime;
    PingMeshKryoWithTime m_subEpochMarkerWithTime;

    public AllSpQuery(CloudUploader cloudUploader) {
        super();
        m_dataTypesAsStrings = new String[2];
        m_dataTypesAsStrings[0] = "PingMeshKryo";
        m_dataTypesAsStrings[1] = "PingMeshKryo";

        classesToRegister = new IData[2];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();

        m_numOperators = 1;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;
        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, true}, cloudUploader);

        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
        PingMeshKryo waterMarkEntry = new PingMeshKryo();
        waterMarkEntry.setWatermarkMarker();
        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);

        m_subEpochMarkerWithTime = new PingMeshKryoWithTime();
        PingMeshKryo subEpochMarker = new PingMeshKryo();
        subEpochMarker.setSubEpochMarker();
        m_subEpochMarkerWithTime.setEntity(subEpochMarker);

        m_customOperators[0] = new CustomMapOperator(0, m_firstCp, 1,
                m_waterMarkEntryWithTime, m_subEpochMarkerWithTime);
        m_customOperators[0].setNextQueue(m_finalCp);
    }
}

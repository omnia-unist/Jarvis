package com.jarvis.processors.edge;

// Stores the partitioning config to execute
public enum PartitioningConfig {
    ALL_SP,
    ADAPT,
    
    // Other partitionings are handled by NoAdapt flag
    NO_ADAPT
}

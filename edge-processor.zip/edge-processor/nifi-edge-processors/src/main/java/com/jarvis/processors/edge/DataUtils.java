package com.jarvis.processors.edge;

import com.jarvis.processors.edge.data.*;

// Utility class for data items
public class DataUtils {

    // Generates watermark of a given data item type
    public static IData getWatermarkMarker(String dataType, boolean subEpochMarker) {
        IData watermark = null;
        switch (dataType) {
            case "PingMeshKryo":
                PingMeshKryo watermarkEntity = new PingMeshKryo();
                watermark = new PingMeshKryoWithTime();
                watermark.setEntity(watermarkEntity);
                break;
            case "WordCountEntity":
                watermark = new WordCountEntity();
                break;
            case "JoinResult":
                watermark = new JoinResult();
                break;
            case "SrcClusterStatsKryo":
                watermark = new SrcClusterStatsKryo();
                break;
            case "ToRCountProbe":
                watermark = new ToRCountProbe();
                break;
            case "LogAnalyticUtilInfo":
                watermark = new LogAnalyticUtilInfo();
                break;
            default:
                throw new UnsupportedOperationException("No data type for generating watermark/subepoch marker for " +
                        dataType + ", with subepoch marker flag: " + subEpochMarker);
        }

        if(subEpochMarker) {
            watermark.setSubEpochMarker();
        } else {
            watermark.setWatermarkMarker();
        }

        return watermark;
    }
}

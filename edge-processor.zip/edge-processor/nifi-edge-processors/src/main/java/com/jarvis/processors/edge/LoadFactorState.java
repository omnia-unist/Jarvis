package com.jarvis.processors.edge;

// Manages load factors and stores load factor state for a control proxy,
// to be used by Jarvis runtime during adaptation
public class LoadFactorState {
    private double m_loadFactorLow;
    private double m_loadFactorHigh;
    private double m_loadFactorCurrent;
    private double m_prevLoadFactorWithClear;
    private double m_prevLoadFactorWithCongestion;

    LoadFactorState() {
        m_loadFactorHigh = 1;
        m_loadFactorLow = 0;
        m_loadFactorCurrent = 1;
        m_prevLoadFactorWithClear = m_loadFactorCurrent;
        m_prevLoadFactorWithCongestion = 1;
    }

    // Resets load factors for a control proxy to defaults
    public void reset(double resetVal) {
        m_loadFactorHigh = 1;
        m_loadFactorLow = 0;
        m_loadFactorCurrent = resetVal;
        m_prevLoadFactorWithClear = 0.05;
        m_prevLoadFactorWithCongestion = 1;
    }

    // Get minimum load factor within unexplored range of load factors, during adaptation
    public double getLoadFactorLow() {
        return m_loadFactorLow;
    }

    // Get maximum load factor within unexplored range of load factors, during adaptation
    public double getLoadFactorHigh() {
        return m_loadFactorHigh;
    }

    // Get the currently set load factor
    public double getLoadFactorCurrent() {
        return m_loadFactorCurrent;
    }

    // Get the load factor when control proxy was in idle state
    public double getPrevLoadFactorWithClear() {
        return m_prevLoadFactorWithClear;
    }

    // Get load factor when control proxy was congested
    public double getPrevLoadFactorWithCongestion() {
        return m_prevLoadFactorWithCongestion;
    }

    // Set the minimum for unexplored range of load factors
    public void setLoadFactorLow(double probLow) {
        m_loadFactorLow = probLow;
    }

    // Set the maximum for unexplored range of load factors
    public void setLoadFactorHigh(double probHigh) {
        m_loadFactorHigh = probHigh;
    }

    // Set the current load factor
    public void setLoadFactorCurrent(double probCurrent) {
        m_loadFactorCurrent = probCurrent;
    }

    // Set the load factor when control proxy was last in idle state
    public void setPrevLoadFactorWithClear(double probCurrent) {
        m_prevLoadFactorWithClear = probCurrent;
    }

    // Set the load factor to the value when control proxy was last in idle state
    public void revertToLoadFactorWithClear() {
        setLoadFactorCurrent(getPrevLoadFactorWithClear());
    }

    // Set the load factor for when control proxy was last in congested state
    public void setPrevLoadFactorWithCongestion(double probCurrent) {
        m_prevLoadFactorWithCongestion = probCurrent;
    }

    // Set the load factor to the value when control proxy was last in idle state
    public void revertToLoadFactorWithCongestion() {
        setLoadFactorCurrent(getPrevLoadFactorWithCongestion());
    }
}

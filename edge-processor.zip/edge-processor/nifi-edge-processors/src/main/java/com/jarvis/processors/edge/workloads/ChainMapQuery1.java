package com.jarvis.processors.edge.workloads;

import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.controlproxy.*;
import com.jarvis.processors.edge.data.IData;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.operators.CustomMapOperator;
import com.jarvis.processors.edge.operators.CustomOperator;

import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP;
import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP_1;

// Chains one or more map operators
public class ChainMapQuery1 extends Workload {

    IData m_waterMarkEntryWithTime;
    IData m_subEpochMarkerWithTime;

    public ChainMapQuery1(CloudUploader cloudUploader) {
        super();
        m_dataTypesAsStrings = new String[3];
        m_dataTypesAsStrings[0] = "PingMeshKryo";
        m_dataTypesAsStrings[1] = "PingMeshKryo";
        m_dataTypesAsStrings[2] = "PingMeshKryo";

        classesToRegister = new IData[2];
        classesToRegister[0] = new PingMeshKryo();
        classesToRegister[1] = new PingMeshKryoWithTime();

        m_numOperators = 2;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;
        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, false}, cloudUploader);

        m_waterMarkEntryWithTime = new PingMeshKryoWithTime();
        PingMeshKryo waterMarkEntry = new PingMeshKryo();
        waterMarkEntry.setWatermarkMarker();
        m_waterMarkEntryWithTime.setEntity(waterMarkEntry);

        m_subEpochMarkerWithTime = new PingMeshKryoWithTime();
        PingMeshKryo subEpochMarker = new PingMeshKryo();
        subEpochMarker.setSubEpochMarker();
        m_subEpochMarkerWithTime.setEntity(subEpochMarker);

        m_customOperators[0] = new CustomMapOperator(0, m_firstCp, 1,
                m_waterMarkEntryWithTime, m_subEpochMarkerWithTime);
        m_customOperators[0].setNextQueue(m_internalCps[0]);

        m_customOperators[1] = new CustomMapOperator(1, m_internalCps[0], 1,
                m_waterMarkEntryWithTime, m_subEpochMarkerWithTime);
        m_customOperators[1].setNextQueue(m_finalCp);
    }
}

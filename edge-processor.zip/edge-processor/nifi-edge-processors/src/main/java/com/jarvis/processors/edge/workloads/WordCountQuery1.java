package com.jarvis.processors.edge.workloads;

import com.esotericsoftware.kryo.Kryo;
import com.jarvis.processors.edge.CloudUploader;
import com.jarvis.processors.edge.Config;
import com.jarvis.processors.edge.Runtime;
import com.jarvis.processors.edge.controlproxy.ControlProxy;
import com.jarvis.processors.edge.controlproxy.FinalControlProxy;
import com.jarvis.processors.edge.controlproxy.FirstControlProxy;
import com.jarvis.processors.edge.controlproxy.IControlProxy;
import com.jarvis.processors.edge.data.*;
import com.jarvis.processors.edge.operators.CustomFilterOperator;
import com.jarvis.processors.edge.operators.CustomFullGroupbyOperator;
import com.jarvis.processors.edge.operators.CustomLineSplitter;
import com.jarvis.processors.edge.operators.CustomOperator;
import com.sun.corba.se.spi.orbutil.threadpool.Work;

import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP;
import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP_1;

// Performs word count query
public class WordCountQuery1 extends Workload {

    public WordCountQuery1(CloudUploader cloudUploader) {
        super();

        classesToRegister = new IData[1];
        classesToRegister[0] = new WordCountEntity();
        m_dataTypesAsStrings = new String[2];
        m_dataTypesAsStrings[0] = "WordCountEntity";
        m_dataTypesAsStrings[1] = "WordCountEntity";

        m_numOperators = 1;
        m_numSubEpochs = Config.NUM_SUBEPOCHS;

        m_customOperators = new CustomOperator[m_numOperators];

        m_operatorThreads = new Thread[m_numOperators];
        m_internalCps = new IControlProxy[m_numOperators-1];

        setQueuesAndRuntime(new boolean[] {false, true}, cloudUploader);

        m_customOperators[0] = new CustomLineSplitter(0, m_firstCp);
        m_customOperators[0].setNextQueue(m_finalCp);
    }


}

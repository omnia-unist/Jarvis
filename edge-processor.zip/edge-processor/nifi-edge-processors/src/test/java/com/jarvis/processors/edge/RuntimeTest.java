package com.jarvis.processors.edge;

import com.esotericsoftware.kryo.Kryo;
import com.jarvis.processors.edge.controlproxy.FinalControlProxy;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.PingMeshKryoWithTime;
import com.jarvis.processors.edge.data.SrcClusterStatsKryo;
import org.junit.Test;

import static com.jarvis.processors.edge.MyProcessor.MY_RELATIONSHIP;

public class RuntimeTest {

    @Test
    public void test1() throws Exception {
//        PingMeshKryo dummyWaterMark = new PingMeshKryo();
//        dummyWaterMark.setWatermarkMarker(Integer.MIN_VALUE);
//        PingMeshKryoWithTime dummyWaterMarkWithTime = new PingMeshKryoWithTime();
//        dummyWaterMarkWithTime.setEntity(dummyWaterMark);
//
//        Kryo m_kryo = new Kryo();
//        m_kryo.register(PingMeshKryo.class);
//        m_kryo.register(PingMeshKryoWithTime.class);
//        m_kryo.register(Integer.class);
//        m_kryo.register(SrcClusterStatsKryo.class);
//        String queueThresholdConfig = "15000000";
//        FinalControlProxy m_exitQueue = new FinalControlProxy(m_kryo, MY_RELATIONSHIP);
//        Runtime jarvisRuntime = new Runtime();
//        ControllerQueue m_operatorQueue = new ControllerQueue(1, Integer.parseInt(queueThresholdConfig), m_kryo,
//                MY_RELATIONSHIP_1, dummyWaterMarkWithTime, m_exitQueue, jarvisRuntime);
//        jarvisRuntime.setCps(m_exitQueue, m_operatorQueue);
//        m_operatorQueue.initializeKryo(new PingMeshKryoWithTime(), new PingMeshKryo());


        // Start runtime in the end

//        Thread runtimeThread = new Thread(jarvisRuntime);
//        runtimeThread.start();
    }
}
package com.jarvis.processors.edge;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.jarvis.processors.edge.data.PingMeshKryo;
import com.jarvis.processors.edge.data.WordCountEntity;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Utility functions for testing
public class Utils {

    // Deserializes the WordCountEntity objects from Kryo file
    public static List<WordCountEntity> readWordCountKryoFile(String inputFile, String outputFile, boolean intPresent) {
        List<WordCountEntity> wordCountsRead = new ArrayList<>();
        try {
            Kryo kryo = new Kryo();
            kryo.register(WordCountEntity.class);
            kryo.register(Integer.class);
            Input input = new Input(new FileInputStream(inputFile));
            System.out.println("Writing output to : " + outputFile);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));
            if(intPresent) {
                Integer readRec = kryo.readObject(input, Integer.class);
            }

            WordCountEntity object2 = kryo.readObject(input, WordCountEntity.class);
            wordCountsRead.add(object2);
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, WordCountEntity.class);
                    wordCountsRead.add(object2);
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }

        return wordCountsRead;
    }

    // Serializes PingMesh records to Kryo objects
    public static void convertPingMeshCsvToKryo(String csvFileName, String outFileName) {
        Kryo kryo = new Kryo();
        kryo.register(PingMeshKryo.class);
        kryo.register(Integer.class);
        File file = new File(csvFileName);
        try {
            Output output = new Output(new FileOutputStream(outFileName));
            BufferedReader br = new BufferedReader(new FileReader(file));
            List<PingMeshKryo> recordsList = new ArrayList<>();
            String st;
            while ((st = br.readLine()) != null) {
                if(st.contains("#")) {
                    continue;
                }
                String[] cols = st.split(",");
                PingMeshKryo pingMeshKryo = new PingMeshKryo();
                pingMeshKryo.m_constantCol = Integer.parseInt(cols[0]);
                pingMeshKryo.m_event_time = Integer.parseInt(cols[1]);
                pingMeshKryo.m_src_cluster = Integer.parseInt(cols[2]);
                pingMeshKryo.m_src_ip = Integer.parseInt(cols[3]);
                pingMeshKryo.m_src_port = Integer.parseInt(cols[4]);
                pingMeshKryo.m_dest_cluster = Integer.parseInt(cols[5]);
                pingMeshKryo.m_dest_ip = Integer.parseInt(cols[6]);
                pingMeshKryo.m_dest_port = Integer.parseInt(cols[7]);
                pingMeshKryo.m_seq_num = Integer.parseInt(cols[8]);
                pingMeshKryo.m_rtt = Integer.parseInt(cols[9]);
                pingMeshKryo.m_errcode = Integer.parseInt(cols[10]);
                pingMeshKryo.m_result_type = Integer.parseInt(cols[11]);
                pingMeshKryo.m_level = Integer.parseInt(cols[12]);
                pingMeshKryo.m_msglen = Integer.parseInt(cols[13]);
                pingMeshKryo.m_count = 1;
                recordsList.add(pingMeshKryo);
            }

            System.out.println("Size during writing is " + recordsList.size());
            kryo.writeObject(output, "PingMeshKryo");
            kryo.writeObject(output, recordsList.size());
            for (PingMeshKryo record :
                    recordsList) {
                kryo.writeObject(output, record);
            }

            output.close();
        } catch (Exception ex) {
            System.err.println("File not found " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Serializes WordCountEntity data items to Kryo objects
    public static void convertWordCountFileToKryo(String fileName, String outFileName) {
        Kryo kryo = new Kryo();
        kryo.register(String.class);
        kryo.register(Integer.class);
        File file = new File(fileName);
        try {
            Output output = new Output(new FileOutputStream(outFileName));
            BufferedReader br = new BufferedReader(new FileReader(file));
            List<String> recordsList = new ArrayList<>();
            String st;
            while ((st = br.readLine()) != null) {
                WordCountEntity wordCountEntity = new WordCountEntity();
                wordCountEntity.m_stringEntity = st;
                wordCountEntity.m_count = 1;
                recordsList.add(wordCountEntity.m_stringEntity);
            }

            System.out.println("Size during writing is " + recordsList.size());
            kryo.writeObject(output, "WordCountEntity");
            kryo.writeObject(output, recordsList.size());
            for (String record :
                    recordsList) {
                kryo.writeObject(output, record);
            }

            output.close();
        } catch (Exception ex) {
            System.err.println("File not found " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Stores the summary statistics of rtt values obtained after aggregation
    public static class RttSummary {
        double m_avgRtt;
        double m_minRtt;
        double m_maxRtt;

        public RttSummary(double max, double min, double avg) {
            m_avgRtt = avg;
            m_minRtt = min;
            m_maxRtt = max;
        }

        @Override
        public boolean equals(Object summary) {
            double epsilon = 0.0001;
            boolean areEqual = false;
            if(summary == this) {
                areEqual = true;
            }

            if(summary instanceof RttSummary) {
                RttSummary sumaryObj = (RttSummary) summary;
                areEqual = ((m_avgRtt-sumaryObj.m_avgRtt) <= epsilon) &&
                        ((m_maxRtt-sumaryObj.m_maxRtt) <= epsilon) &&
                        ((m_minRtt-sumaryObj.m_minRtt) <= epsilon);
            }

            return areEqual;
        }
    }

    // Deserialize PingMesh data items from Kryo objects file
    public static void readPingMeshKryoFile(String inputFile, String outputFile) {
        try {
            Kryo kryo = new Kryo();
            kryo.register(PingMeshKryo.class);
            kryo.register(Integer.class);
            kryo.register(String.class);
            Input input = new Input(new FileInputStream(inputFile));
            System.out.println("Writing output to : " + outputFile);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(outputFile));
            Integer cpId = kryo.readObject(input, Integer.class);
            String dataType = kryo.readObject(input, String.class);
            System.out.println("Integer at beginning is: " + cpId);
            System.out.println(cpId+","+dataType);

            PingMeshKryo object2 = kryo.readObject(input, PingMeshKryo.class);
            writer.write(object2.toString()+"\n");
            while(object2 != null) {
                try {
                    object2 = kryo.readObject(input, PingMeshKryo.class);
                    writer.write(object2.toString()+"\n");
                } catch(Exception ex) {
                    System.err.println("Under1 flow error " + ex.toString());
                    break;
                }
            }

            writer.close();
            input.close();
        } catch (Exception ex) {
            System.err.println("Kyro deserialize did not work " + ex.toString());
            ex.printStackTrace();
        }
    }
}

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jarvis.processors.edge;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.jarvis.processors.edge.data.*;
import org.apache.nifi.util.MockFlowFile;
import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jarvis.processors.edge.MyProcessor.*;

// Implements unit tests and integration tests for processing of input stream across
// data source and stream processor
public class MyProcessorTest {

    private TestRunner testRunner;

    @Before
    public void init() {
        testRunner = TestRunners.newTestRunner(MyProcessor.class);
    }

    // Tests a chain of map operators
    @Test
    public void testProcessor() {
        String inputFileName = "xxa-1000records.allintify";
        String outFileNameKryo = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            int shortSleep = 500;
            int mediumSleep = 1500;
            int longSleep = 1500;
            testRunner.setProperty(MY_PROPERTY, "chainMapAdaptQuery1.cfg");
            while(flowFileCount < 50) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                if(flowFileCount <= 20) {
                    Thread.sleep(longSleep);
                } else if(flowFileCount < 20) {
                    Thread.sleep(shortSleep);
                } else {
                    Thread.sleep(mediumSleep);
                }

                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            System.out.println("Size of MY_RELATIONSHIP is " + results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            System.out.println("Size of MY_RELATIONSHIP_1 is " + results1.size());

            System.out.println("Checking out attribute values on flowfile");
            for (MockFlowFile flowFile :
                    results1) {
                System.out.println(flowFile.getAttribute("cpId"));
                System.out.println(flowFile.getAttribute("dataType"));
            }

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);

            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            PingMeshKryo object2 = m_kryo.readObject(kryoInput, PingMeshKryo.class);
            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, PingMeshKryo.class);

                    read++;
                }
            } catch (Exception ex) {
                System.out.println("Done reading");
            }

            System.out.println("Edge processing record count: " + read);
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Tests the deserialization of PingMesh data
    @Test
    public void TestOutputFilesIntegrationTest() {
        Utils.readPingMeshKryoFile("/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/edgeDrained3",
                "temp");
    }

    // Tests the S2SProbe with filtering out non-anomalous records (filtering is effective)
    @Test
    public void testPingMeshQuery1FilterEq0() {
        String inputFileName = "xxa-1000records.allintify";
        String expectedOutputFileName = "filter-grouping-output-xxa1000-filter-eq-0";
        String outFileNameKryo = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "pingmeshQuery1.cfg");
            while(flowFileCount < 1) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(2000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(1, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);
            m_kryo.register(String.class);
            m_kryo.register(Integer.class);
            m_kryo.register(SrcClusterStatsKryo.class);

            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            int cpId = m_kryo.readObject(kryoInput, Integer.class);

            // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
            Assert.assertEquals(1, cpId);
            String dataType = m_kryo.readObject(kryoInput, String.class);
            Assert.assertEquals("SrcClusterStatsKryo", dataType);

            // Read expected output
            File expectedOutFile = new File(expectedOutputFileName);
            BufferedReader br = new BufferedReader(new FileReader(expectedOutFile));

            Map<String, Utils.RttSummary> expectedOutputMap = new HashMap<>();
            String st;
            while ((st = br.readLine()) != null) {
                if(!st.contains("#")) {
                    String[] vals = st.split(",");
                    expectedOutputMap.put(vals[0], new Utils.RttSummary(
                            Double.parseDouble(vals[1]),
                            Double.parseDouble(vals[2]),
                            Double.parseDouble(vals[3].trim())
                    ));
                }
            }

            SrcClusterStatsKryo srcWaterMark = new SrcClusterStatsKryo();
            srcWaterMark.setWatermarkMarker();
            expectedOutputMap.put(Integer.toString(srcWaterMark.getSrcCluster()),
                    new Utils.RttSummary(0.0, 0.0, 0.0));

            SrcClusterStatsKryo object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
            Utils.RttSummary summaryObject2 = new Utils.RttSummary(object2.getMaxRtt(),
                                                        object2.getMinRtt(),
                                                        object2.getAvgRtt());

            Assert.assertEquals(expectedOutputMap.get(Integer.toString(object2.getSrcCluster())),
                    summaryObject2);

            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
                    summaryObject2 = new Utils.RttSummary(object2.getMaxRtt(),
                            object2.getMinRtt(),
                            object2.getAvgRtt());

                    Assert.assertEquals(expectedOutputMap.get(Integer.toString(object2.getSrcCluster())),
                            summaryObject2);

                    read++;
                }

                Assert.assertEquals(expectedOutputMap.size(), read);
            } catch (Exception ex) {
                System.out.println("Done reading");
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for S2SProbe with ineffective filtering due to filtering out of anomalous records
    @Test
    public void testPingMeshQuery1FilterNotEq0() {
        String inputFileName = "xxa-1000records.allintify";
        String expectedOutputFileName = "filter-grouping-output-xxa1000-filter-not-eq-0";
        String outFileNameKryo = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "pingmeshQuery1FilterNotEq0.cfg");
            while(flowFileCount < 1) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(2000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(1, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);
            m_kryo.register(String.class);
            m_kryo.register(Integer.class);
            m_kryo.register(SrcClusterStatsKryo.class);

            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            int cpId = m_kryo.readObject(kryoInput, Integer.class);

            // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
            Assert.assertEquals(1, cpId);
            String dataType = m_kryo.readObject(kryoInput, String.class);
            Assert.assertEquals("SrcClusterStatsKryo", dataType);

            // Read expected output
            File expectedOutFile = new File(expectedOutputFileName);
            BufferedReader br = new BufferedReader(new FileReader(expectedOutFile));

            Map<String, Utils.RttSummary> expectedOutputMap = new HashMap<>();
            String st;
            while ((st = br.readLine()) != null) {
                if(!st.contains("#")) {
                    String[] vals = st.split(",");
                    expectedOutputMap.put(vals[0], new Utils.RttSummary(
                            Double.parseDouble(vals[1]),
                            Double.parseDouble(vals[2]),
                            Double.parseDouble(vals[3].trim())
                    ));
                }
            }

            SrcClusterStatsKryo srcWaterMark = new SrcClusterStatsKryo();
            srcWaterMark.setWatermarkMarker();
            expectedOutputMap.put(Integer.toString(srcWaterMark.getSrcCluster()),
                    new Utils.RttSummary(0.0, 0.0, 0.0));

            SrcClusterStatsKryo object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
            Utils.RttSummary summaryObject2 = new Utils.RttSummary(object2.getMaxRtt(),
                    object2.getMinRtt(),
                    object2.getAvgRtt());

            Assert.assertEquals(expectedOutputMap.get(Integer.toString(object2.getSrcCluster())),
                    summaryObject2);

            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
                    summaryObject2 = new Utils.RttSummary(object2.getMaxRtt(),
                            object2.getMinRtt(),
                            object2.getAvgRtt());

                    Assert.assertEquals(expectedOutputMap.get(Integer.toString(object2.getSrcCluster())),
                            summaryObject2);

                    read++;
                }

                Assert.assertEquals(expectedOutputMap.size(), read);
            } catch (Exception ex) {
                System.out.println("Done reading");
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Integration test between data source and stream processor for multiple queries
    @Test
    public void TestIntegrationMultiQueries() {
        String outFileNameKryo = "testInput/xxa-mod-srccluster-grpby-0.1grpcount.allintify.kryo.v3";
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
        testRunner.setProperty(MY_PROPERTY, "multiQueryPingmeshQuery.cfg");
            while(flowFileCount < 10) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(1000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(15000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(10, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());
            System.out.print("Drained flowfile count: " + results1.size());

            /////////// Write output to file for testing with cloud processor///////////
            String outFlowFileFolder = "/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/";
            String drainedFileNamePrefix = outFlowFileFolder + "cloud-processor/nifi-cloud-processors/testInput/multiS2sProbeDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix = outFlowFileFolder + "cloud-processor/nifi-cloud-processors/testInput/multiS2sProbeCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for S2SProbe with integration between data source and stream processor
    @Test
    public void TestIntegration() {
        String outFileNameKryo = "testInput/xxa-mod-srccluster-grpby-0.1grpcount.allintify.kryo.v3";
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "pingmeshQuery1Adapt.cfg");
            while(flowFileCount < 10) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(200);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(15000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(10, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());
            System.out.print("Drained flowfile count: " + results1.size());

            /////////// Write output to file for testing with cloud processor///////////
            String outFlowFileFolder = "/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/";
            String drainedFileNamePrefix = outFlowFileFolder + "cloud-processor/nifi-cloud-processors/testInput/s2sProbeDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix = outFlowFileFolder + "cloud-processor/nifi-cloud-processors/testInput/s2sProbeCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test Join operator for profiling
    @Test
    public void testJoinQuery1Adapt() {
        String inputFileName = "xxa-1000records.allintify";
        String outFileNameKryo = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "joinQuery1Adapt.cfg");
            while(flowFileCount < 20) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(500);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(flowFileCount, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);
            m_kryo.register(String.class);
            m_kryo.register(Integer.class);
            m_kryo.register(JoinResult.class);

            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            int cpId = m_kryo.readObject(kryoInput, Integer.class);

            // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
            Assert.assertEquals(-1, cpId);
            String dataType = m_kryo.readObject(kryoInput, String.class);
            Assert.assertEquals("JoinResult", dataType);
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test S2SProbe with no adaptation enabled
    @Test
    public void testPingMeshQuery1NoAdapt() {
        String inputFileName = "xxa-1000records.allintify";
        String expectedOutputFileName = "filter-grouping-output-xxa1000-filter-eq-0";
        String outFileNameKryo = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "pingmeshQuery1NoAdapt.cfg");
            while(flowFileCount < 20) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(5000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(20, results.size());

            List<SrcClusterStatsKryo> t_list = new ArrayList<>();
            HashMap<Integer, Integer> groupingKeyCounts = new HashMap<>();
            for(int i = 0; i < 1; i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(1));
                Kryo m_kryo = new Kryo();
                m_kryo.register(PingMeshKryo.class);
                m_kryo.register(String.class);
                m_kryo.register(Integer.class);
                m_kryo.register(SrcClusterStatsKryo.class);
                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);

                // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
                Assert.assertEquals(1, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                Assert.assertEquals("SrcClusterStatsKryo", dataType);
                SrcClusterStatsKryo object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
                t_list.add(object2);
                int currGrpingKey = object2.getGroupingKey();
                if(groupingKeyCounts.containsKey(currGrpingKey)) {
                    int currCount = groupingKeyCounts.get(currGrpingKey);
                    groupingKeyCounts.put(object2.getGroupingKey(), currCount+1);
                } else {
                    groupingKeyCounts.put(object2.getGroupingKey(), 1);
                }

                try {
                    while (object2 != null) {
                        object2 = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
                        t_list.add(object2);
                        currGrpingKey = object2.getGroupingKey();
                        if(groupingKeyCounts.containsKey(currGrpingKey)) {
                            int currCount = groupingKeyCounts.get(currGrpingKey);
                            groupingKeyCounts.put(object2.getGroupingKey(), currCount+1);
                        } else {
                            groupingKeyCounts.put(object2.getGroupingKey(), 1);
                        }
                    }
                } catch (Exception ex) {
                    System.out.println("Done reading");
                }

                for (Integer key :
                        groupingKeyCounts.keySet()) {
                    if (groupingKeyCounts.get(key) > 1) {
                        System.out.println("Key: " + key + ", val: " + groupingKeyCounts.get(key));
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test to serialize WordCountEntity data items to Kryo objects
    @Test
    public void testConvertWordCountQueryToKryo() {
        String inputFileName = "WikiQAWithUtil.tsv";
        String kryoFileName = inputFileName + ".kryo.v3";
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
    }

    // Test word count query using WordCountEntity, without adaptation
    @Test
    public void testWordCountQuery1() {
        String inputFileName = "wordCountTest.txt";
        String kryoFileName = inputFileName + ".kryo";

        // Convert to kryo file
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
        File flowfileInp = new File(kryoFileName);
        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "wordCountNoAdapt.cfg");
            int totalNumFlowFiles = 2;
            while(flowFileCount < totalNumFlowFiles) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(1000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(10000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/allSrcLogAnalyticsCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                    fos.flush();
                }
            }

            System.out.println(results.size() + ", MY relation 1: " + results1.size());
            Assert.assertEquals(results.size(), totalNumFlowFiles);
            Assert.assertEquals(results1.size(), 0);

            Map<String, Integer> expectedWordCount = new HashMap<String, Integer>() {{
               put("word1", 7);
               put("word2", 7);
                put("word3", 7);
                put("word4", 6);
                put("word5", 6);
                put("word6", 6);
                put("word7", 4);
                put("word8", 4);
                put("word9", 4);
                put("word10", 4);
                put("word11", 3);
                put("word12", 3);
                put("watermark", 1);
            }};

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            Kryo m_kryo = new Kryo();
            m_kryo.register(WordCountEntity.class);
            m_kryo.register(Integer.class);
            m_kryo.register(String.class);
            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            Integer cpId = m_kryo.readObject(kryoInput, Integer.class);
            Assert.assertEquals((int)0, (int) cpId);
            String dataType = m_kryo.readObject(kryoInput, String.class);
            Assert.assertEquals("WordCountEntity", dataType);

            WordCountEntity object2 = m_kryo.readObject(kryoInput, WordCountEntity.class);
            System.out.println(object2.m_stringEntity + "," +
                    expectedWordCount.get(object2.m_stringEntity));
            Assert.assertEquals(expectedWordCount.get(object2.m_stringEntity), (Integer) object2.m_count);
            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, WordCountEntity.class);
                    System.out.println(object2.m_stringEntity + "," +
                            expectedWordCount.get(object2.m_stringEntity));
                    Assert.assertEquals(expectedWordCount.get(object2.m_stringEntity), (Integer) object2.m_count);
                    read++;
                }
            } catch (Exception ex) {
                System.out.println("Done reading");
            }

            Assert.assertEquals(13, read);
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test LogAnalytics query with adaptation
    @Test
    public void testLogAnalyticUtilQueryAdapt() {
        String inputFileName = "wordCountTest.txt";
        String kryoFileName = inputFileName + ".kryo";

        // Convert to kryo file
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
        File flowfileInp = new File(kryoFileName);
        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "logAnalyticsUtilAdapt.cfg");
            while(flowFileCount < 4) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(500);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(10000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/dnnLogUtilAdaptCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                    fos.flush();
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test Filter-Src partition configuration using LogAnalytics query, with no adaptation
    @Test
    public void testFilterSrcLogAnalyticUtilQuery() {
        String inputFileName = "wordCountTest.txt";
        String kryoFileName = inputFileName + ".kryo";

        // Convert to kryo file
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
        File flowfileInp = new File(kryoFileName);
        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "filterSrcLogAnalyticsUtilQuery.cfg");
            while(flowFileCount < 3) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(500);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(10000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/filterSrcLogAnalyticsUtilCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                    fos.flush();
                }
            }

            Assert.assertEquals(0, results1.size());
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for word count query with no adaptation
    @Test
    public void testWordCountQuery1SingleFlowfileDataRed() {
        String inputFileName = "WikiQA.tsv";
        String kryoFileName = inputFileName + ".kryo";
        // Convert to kryo file
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
        File flowfileInp = new File(kryoFileName);
        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "wordCountNoAdaptWikiQA.cfg");
            while(flowFileCount < 1) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(1000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(2000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            System.out.println("MY relation: " + results.size() + ", MY relation 1: " + results1.size());

            byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
            try (FileOutputStream fos = new FileOutputStream("temp")) {
                fos.write(outputEdge);
            } catch (Exception ex) {
                System.err.println("ERROR writing to file");
            }

            Kryo m_kryo = new Kryo();
            m_kryo.register(WordCountEntity.class);
            m_kryo.register(Integer.class);
            m_kryo.register(String.class);
            ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
            Input kryoInput = new Input(outputEdgeStream);
            Integer cpId = m_kryo.readObject(kryoInput, Integer.class);
            Assert.assertEquals((int)0, (int) cpId);
            String dataType = m_kryo.readObject(kryoInput, String.class);
            Assert.assertEquals("WordCountEntity", dataType);

            WordCountEntity object2 = m_kryo.readObject(kryoInput, WordCountEntity.class);
            System.out.println(object2.m_stringEntity);
            int read = 1;
            try {
                while (object2 != null) {
                    object2 = m_kryo.readObject(kryoInput, WordCountEntity.class);
                    System.out.println(object2.m_stringEntity + " => " + object2.m_count);
                    read++;
                }
            } catch (Exception ex) {
                System.out.println("Done reading");
            }

        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test word count query integration with stream processor
    @Test
    public void testWordCountQuery1Integration() {
        String inputFileName = "WikiQA.tsv";
        String kryoFileName = inputFileName + ".kryo";
        // Convert to kryo file
        Utils.convertWordCountFileToKryo(inputFileName, kryoFileName);
        File flowfileInp = new File(kryoFileName);
        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "wordCount.cfg");
            while(flowFileCount < 10) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(1000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(5000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            System.out.println("MY relation: " + results.size() + ", MY relation 1: " + results1.size());

            String drainedFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/wordCountDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/wordCountCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test S2SProbe query integration with Filter-Src and no adaptation
    @Test
    public void TestIntegrationS2SProbeFilterSrc() {
        String outFileNameKryo = "testInput/xxa-mod-srccluster-grpby-0.1grpcount.allintify.kryo.v2";
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "pingmeshQuery1HalfSrcNoAdapt.cfg");
            while(flowFileCount < 20) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(200);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(20, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());
            System.out.print("Drained flowfile count: " + results1.size());

            String drainedFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/edgeDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/edgeCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test All-SP configuration of S2SProbe
    @Test
    public void TestAllSpIntegration() {
        String outFileNameKryo = "testInput/xxa-mod-srccluster-grpby-0.1grpcount.allintify.kryo.v3";
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "allSpNoAdaptPingmeshQuery1.cfg");
            while(flowFileCount < 10) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(200);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(10, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());
            System.out.print("Drained flowfile count: " + results1.size());

            String drainedFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/allSpDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/allSpCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for All-SP configuration of LogAnalytic query
    @Test
    public void TestAllSpLogAnalyticIntegration() {
        String outFileNameKryo = "WikiQAWithUtil.tsv.kryo.v3";
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "allSpNoAdaptLogAnalyticUtilQuery.cfg");
            while(flowFileCount < 3) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(200);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(3, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            String drainedFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/allSpLogAnalyticsDrained";
            for(int i = 0; i < results1.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(i));
                try (FileOutputStream fos = new FileOutputStream(drainedFileNamePrefix + i)) {
                    fos.write(outputEdge);
                }
            }

            String outFileNamePrefix="/home/athuls89/Desktop/OSL/msr/calcite/myprocessor/cloud-processor/nifi-cloud-processors/testInput/allSpLogAnalyticsCompleted";
            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(i));
                String result = new String(outputEdge);
                Kryo kryoTest = new Kryo();
                kryoTest.register(Integer.class);
                kryoTest.register(String.class);
                kryoTest.register(WordCountEntity.class);
                Input inputTest = new Input(outputEdge);
                int val = kryoTest.readObject(inputTest, Integer.class);
                String type = kryoTest.readObject(inputTest, String.class);
                WordCountEntity t1 = kryoTest.readObject(inputTest, WordCountEntity.class);
                try {
                    while (t1 != null) {
                        t1 = kryoTest.readObject(inputTest, WordCountEntity.class);
                    }
                } catch (Exception ex) {

                }
                try (FileOutputStream fos = new FileOutputStream(outFileNamePrefix + i)) {
                    fos.write(outputEdge);
                    fos.flush();
                }
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for chaining of map operators
    @Test
    public void TestChainMapOperators() {
        String inputFileName = "xxa-1000records.allintify";
        String inputFileKryoName = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, inputFileKryoName);
        File flowfileInp = new File(inputFileKryoName);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            int totalInputFlowfiles = 2;
            testRunner.setProperty(MY_PROPERTY, "chainMapQuery1.cfg");
            while(flowFileCount < totalInputFlowfiles) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(500);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            // Read expected output
            List<PingMeshKryo> expectedEntities = new ArrayList<>();
            List<PingMeshKryo> actualEntitites = new ArrayList<>();
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);
            m_kryo.register(String.class);
            m_kryo.register(Integer.class);
            int numExpectedLinesPerInputFlowFile = 1;

            try {
                Input input = new Input(new FileInputStream(inputFileKryoName));
                String dataType = m_kryo.readObject(input, String.class);
                Assert.assertEquals("PingMeshKryo", dataType);
                Integer readRec = m_kryo.readObject(input, Integer.class);
                Assert.assertEquals(1000, (int) readRec);
                PingMeshKryo object2 = m_kryo.readObject(input, PingMeshKryo.class);
                while (object2 != null) {
                    expectedEntities.add(object2);
                    object2 = m_kryo.readObject(input, PingMeshKryo.class);
                    numExpectedLinesPerInputFlowFile++;
                }
            } catch (Exception ex) {
                System.out.println("Buffer underflow");
            }

            List<MockFlowFile> allResults = new ArrayList<>();
            allResults.addAll(results);
            allResults.addAll(results1);

            int actualLineCount = 0;
            int watermarkCnt = 0;
            System.out.println("Total numnber of flowfiles: " + allResults.size());

            for (int flowfileCnt = 0; flowfileCnt < results.size(); flowfileCnt++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(flowfileCnt));
                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);
                Assert.assertEquals(-1, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                Assert.assertEquals("PingMeshKryo", dataType);

                PingMeshKryo linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                try {
                    while (linePingMesh != null) {
                        if (linePingMesh.isWaterMark()) {
                            watermarkCnt++;
                        } else {
                            actualLineCount++;
                            boolean found = false;
                            actualEntitites.add(linePingMesh);
                            for(int i = 0; i < expectedEntities.size(); i++) {
                                if (expectedEntities.get(i).equals(linePingMesh)) {
                                    found = true;
                                }
                            }

                            Assert.assertEquals(true, found);
                        }

                        linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                    }
                } catch (Exception ex) {
                    System.out.print("Buffer underflow");
                }
            }

            System.out.println("Results1 size is: " + results1.size());
            int countDebug=0;
            for (int flowfileCnt = 0; flowfileCnt < results1.size(); flowfileCnt++) {
                countDebug = 0;
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(flowfileCnt));


                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);
                Assert.assertEquals(flowfileCnt == 0 ? 0 : 1, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                System.out.println(dataType);
                Assert.assertEquals("PingMeshKryo", dataType);

                PingMeshKryo linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                countDebug++;
                try {
                    while (linePingMesh != null) {
                        if (linePingMesh.isWaterMark()) {
                            watermarkCnt++;
                        } else {
                            actualLineCount++;
                            boolean found = false;
                            actualEntitites.add(linePingMesh);
                            for(int i = 0; i < expectedEntities.size(); i++) {
                                if (expectedEntities.get(i).equals(linePingMesh)) {
                                    found = true;
                                }
                            }

                            Assert.assertEquals(true, found);
                        }

                        linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                        countDebug++;
                    }
                } catch (Exception ex) {
                    System.out.print("Buffer underflow");
                }

                System.out.println("Count debug is : " + countDebug);
            }

            Assert.assertEquals(watermarkCnt, allResults.size());
            System.out.println(numExpectedLinesPerInputFlowFile + "," + totalInputFlowfiles + "," +
                    actualLineCount);
            Assert.assertEquals(numExpectedLinesPerInputFlowFile * totalInputFlowfiles,
                    actualLineCount);
            
            // Add test for actual entities vs expected
            for (PingMeshKryo expectedEntity :
                    expectedEntities) {
                boolean found = false;
                for (PingMeshKryo actualEntity :
                        actualEntitites) {
                    if(expectedEntity.equals(actualEntity)) {
                        found = true;
                    }
                }

                Assert.assertEquals(true, found);
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for query with chaining of map operators, with adaptation enabled in config
    @Test
    public void TestChainMapAdaptOperators() {
        String inputFileName = "xxa-1000records.allintify";
        String inputFileKryoName = "xxa-1000records.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, inputFileKryoName);
        File flowfileInp = new File(inputFileKryoName);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            int totalInputFlowfiles = 2;
            testRunner.setProperty(MY_PROPERTY, "chainMapQuery1.cfg");
            while(flowFileCount < totalInputFlowfiles) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(500);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);

            // Read expected output
            List<PingMeshKryo> expectedEntities = new ArrayList<>();
            Kryo m_kryo = new Kryo();
            m_kryo.register(PingMeshKryo.class);
            m_kryo.register(String.class);
            m_kryo.register(Integer.class);
            int numExpectedLinesPerInputFlowFile = 1;

            try {
                Input input = new Input(new FileInputStream(inputFileKryoName));
                String dataType = m_kryo.readObject(input, String.class);
                Assert.assertEquals("PingMeshKryo", dataType);
                Integer readRec = m_kryo.readObject(input, Integer.class);
                Assert.assertEquals(1000, (int) readRec);
                PingMeshKryo object2 = m_kryo.readObject(input, PingMeshKryo.class);
                while (object2 != null) {
                    expectedEntities.add(object2);
                    object2 = m_kryo.readObject(input, PingMeshKryo.class);
                    numExpectedLinesPerInputFlowFile++;
                }
            } catch (Exception ex) {
                System.out.println("Buffer underflow");
            }

            List<MockFlowFile> allResults = new ArrayList<>();
            allResults.addAll(results);
            allResults.addAll(results1);

            int actualLineCount = 0;
            int watermarkCnt = 0;
            System.out.println("Total numnber of flowfiles: " + allResults.size());
            int countDebug=0;
            for (int flowfileCnt = 0; flowfileCnt < results.size(); flowfileCnt++) {
                countDebug = 0;
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(flowfileCnt));


                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);
                Assert.assertEquals(-1, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                Assert.assertEquals("PingMeshKryo", dataType);

                PingMeshKryo linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                countDebug++;
                try {
                    while (linePingMesh != null) {
                        if (linePingMesh.isWaterMark()) {
                            watermarkCnt++;
                        } else {
                            actualLineCount++;
                            boolean found = false;
                            for(int i = 0; i < expectedEntities.size(); i++) {
                                if (expectedEntities.get(i).equals(linePingMesh)) {
                                    found = true;
                                }
                            }

                            Assert.assertEquals(true, found);
                        }

                        linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                        countDebug++;
                    }
                } catch (Exception ex) {
                    System.out.print("Buffer underflow");
                }

                System.out.println("Count debug is : " + countDebug + ", actual line count:" + actualLineCount);
            }
            System.out.println("Watermarks in results list: " + watermarkCnt);

            System.out.println("Results1 size is: " + results1.size());
            for (int flowfileCnt = 0; flowfileCnt < results1.size(); flowfileCnt++) {
                countDebug = 0;
                byte[] outputEdge = testRunner.getContentAsByteArray(results1.get(flowfileCnt));


                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);
                Assert.assertEquals(flowfileCnt == 0 ? 0 : 1, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                System.out.println(dataType);
                Assert.assertEquals("PingMeshKryo", dataType);

                PingMeshKryo linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                countDebug++;
                try {
                    while (linePingMesh != null) {
                        if (linePingMesh.isWaterMark()) {
                            watermarkCnt++;
                        } else {
                            actualLineCount++;
                            boolean found = false;
                            for(int i = 0; i < expectedEntities.size(); i++) {
                                if (expectedEntities.get(i).equals(linePingMesh)) {
                                    found = true;
                                }
                            }

                            Assert.assertEquals(true, found);
                        }

                        linePingMesh = m_kryo.readObject(kryoInput, PingMeshKryo.class);
                        countDebug++;
                    }
                } catch (Exception ex) {
                    System.out.print("Buffer underflow");
                }

                System.out.println("Count debug is : " + countDebug + ", actual line count:" + actualLineCount);
            }

            Assert.assertEquals(watermarkCnt, allResults.size());
            System.out.println(numExpectedLinesPerInputFlowFile + "," + totalInputFlowfiles + "," +
                    actualLineCount);
            Assert.assertEquals(numExpectedLinesPerInputFlowFile * totalInputFlowfiles,
                    actualLineCount);
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for T2TProbe query with complete summary statistics of rtt values
    @Test
    public void TestTorIpQueryStatsSummary() {
        String inputFileName = "xxa-1000records.TorIpQuery.allintify";
        String outFileNameKryo = "xxa-1000records.TorIpQuery.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "torIpQueryStatsSummary.cfg");
            int totalFlowFiles = 1;
            while(flowFileCount < totalFlowFiles) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(2000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(5000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(totalFlowFiles, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
                Kryo m_kryo = new Kryo();
                m_kryo.register(PingMeshKryo.class);
                m_kryo.register(String.class);
                m_kryo.register(Integer.class);
                m_kryo.register(SrcClusterStatsKryo.class);

                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);

                // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
                Assert.assertEquals(2, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                Assert.assertEquals("SrcClusterStatsKryo", dataType);

                List<IData> outputClasses = new ArrayList<>();
                try {
                    SrcClusterStatsKryo readObj = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);
                    outputClasses.add(readObj);
                    while (readObj != null) {
                        readObj = m_kryo.readObject(kryoInput, SrcClusterStatsKryo.class);

                        outputClasses.add(readObj);
                    }
                } catch (Exception ex) {
                    System.out.println("Finished reading kryo data");
                }

                Assert.assertEquals(4, outputClasses.size());
                float delta = (float) 0.0001;
                for (IData entry :
                        outputClasses) {
                    SrcClusterStatsKryo srcClusterStatsKryo = (SrcClusterStatsKryo) entry;

                    // Note that 20, 21 and 22 are ToR IPs, we reuse SrcClusterStatsKryo for doing grouping on ToR IDs
                    if(srcClusterStatsKryo.getSrcCluster() == 20) {
                        Assert.assertEquals((float) 11.0, srcClusterStatsKryo.getAvgRtt(), delta);
                        Assert.assertEquals((float) 10.0, srcClusterStatsKryo.getMinRtt(), delta);
                        Assert.assertEquals((float) 12.0, srcClusterStatsKryo.getMaxRtt(), delta);
                    } else if(srcClusterStatsKryo.getSrcCluster() == 21) {
                        Assert.assertEquals((float) 15.5, srcClusterStatsKryo.getAvgRtt(), delta);
                        Assert.assertEquals((float) 11.0, srcClusterStatsKryo.getMinRtt(), delta);
                        Assert.assertEquals((float) 20.0, srcClusterStatsKryo.getMaxRtt(), delta);
                    } else if(srcClusterStatsKryo.getSrcCluster() == 22) {
                        Assert.assertEquals((float) 77.333336, srcClusterStatsKryo.getAvgRtt(), delta);
                        Assert.assertEquals((float) 12.0, srcClusterStatsKryo.getMinRtt(), delta);
                        Assert.assertEquals((float) 120.0, srcClusterStatsKryo.getMaxRtt(), delta);
                    }
                }

                System.out.println("Size of output list is: " + outputClasses.size());
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }

    // Test for T2TProbe query with only count probe statistics as output of aggregation
    @Test
    public void testTorIpQueryCountProbe() {
        String inputFileName = "xxa-1000records.TorIpQuery.allintify";
        String outFileNameKryo = "xxa-1000records.TorIpQuery.allintify.kryo.test";
        Utils.convertPingMeshCsvToKryo(inputFileName, outFileNameKryo);
        File flowfileInp = new File(outFileNameKryo);

        try {
            InputStream in = null;
            int flowFileCount = 0;
            testRunner.setProperty(MY_PROPERTY, "torIpQueryCountProbe.cfg");
            int totalFlowFiles = 1;
            while(flowFileCount < totalFlowFiles) {
                in = new FileInputStream(flowfileInp);
                testRunner.enqueue(in);
                testRunner.run(1);
                Thread.sleep(2000);
                testRunner.assertQueueEmpty();
                flowFileCount++;
            }

            Thread.sleep(3000);

            List<MockFlowFile> results = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP);
            Assert.assertEquals(totalFlowFiles, results.size());

            List<MockFlowFile> results1 = testRunner.getFlowFilesForRelationship(MY_RELATIONSHIP_1);
            Assert.assertEquals(0, results1.size());

            for(int i = 0; i < results.size(); i++) {
                byte[] outputEdge = testRunner.getContentAsByteArray(results.get(0));
                Kryo m_kryo = new Kryo();
                m_kryo.register(PingMeshKryo.class);
                m_kryo.register(String.class);
                m_kryo.register(Integer.class);
                m_kryo.register(ToRCountProbe.class);

                ByteArrayInputStream outputEdgeStream = new ByteArrayInputStream(outputEdge);
                Input kryoInput = new Input(outputEdgeStream);
                int cpId = m_kryo.readObject(kryoInput, Integer.class);

                // The last control proxy is after a Groupby (stateful operator), so cpId needs to be 1
                Assert.assertEquals(2, cpId);
                String dataType = m_kryo.readObject(kryoInput, String.class);
                Assert.assertEquals("ToRCountProbe", dataType);

                List<IData> outputClasses = new ArrayList<>();
                try {
                    ToRCountProbe readObj = m_kryo.readObject(kryoInput, ToRCountProbe.class);
                    outputClasses.add(readObj);
                    while (readObj != null) {
                        readObj = m_kryo.readObject(kryoInput, ToRCountProbe.class);

                        outputClasses.add(readObj);
                    }
                } catch (Exception ex) {
                    System.out.println("Finished reading kryo data");
                }

                // 1 extra output class for watermark
                Assert.assertEquals(4, outputClasses.size());
                for (IData entry :
                        outputClasses) {
                    ToRCountProbe toRCountProbe = (ToRCountProbe) entry;

                    // Note that 20, 21 and 22 are ToR IPs, we reuse SrcClusterStatsKryo for doing grouping on ToR IDs
                    if(toRCountProbe.getTorId() == 20) {
                        Assert.assertEquals(3, toRCountProbe.getCount());
                    } else if(toRCountProbe.getTorId() == 21) {
                        Assert.assertEquals(2, toRCountProbe.getCount());
                    } else if(toRCountProbe.getTorId() == 22) {
                        Assert.assertEquals(3, toRCountProbe.getCount());
                    }
                }

                System.out.println("Size of output list is: " + outputClasses.size());
            }
        } catch (Exception ex) {
            System.out.println("Couldn't read flowfile input " + ex.toString());
            ex.printStackTrace();
        }
    }
}
